#!/bin/bash
#
# 03_configure_environment.sh
# fcitx5 환경 변수 설정
#
# 사용법: ./03_configure_environment.sh
# 필요한 설정: SUDO_PASSWORD (config.local.env)
#

set -e

# sudo 공통 라이브러리 로드
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../../lib/sudo.sh"

# sudo 캐시 확인 (Tauri 앱 환경에서 필수)
if ! ensure_sudo_cache; then
    echo -e "${RED}❌ Sudo cache expired or not found${NC}"
    echo "Please verify your password in the password screen first."
    exit 1
fi

echo "=========================================="
echo "  fcitx5 환경 변수 설정"
echo "=========================================="

ENV_FILE="/etc/environment"

# 이미 설정되어 있는지 확인
if grep -q "GTK_IM_MODULE=fcitx" "$ENV_FILE" 2>/dev/null; then
    echo "⚠️  환경 변수가 이미 설정되어 있습니다."
    exit 0
fi

echo "[1/1] /etc/environment에 환경 변수 추가 중..."

# 환경 변수 추가
run_as_root tee -a "$ENV_FILE" > /dev/null << 'EOF'

# fcitx5 Input Method
GTK_IM_MODULE=fcitx
QT_IM_MODULE=fcitx
XMODIFIERS=@im=fcitx
EOF

echo ""
echo "✅ 환경 변수 설정 완료!"
echo "⚠️  변경 사항 적용을 위해 로그아웃/로그인이 필요합니다."
echo ""

