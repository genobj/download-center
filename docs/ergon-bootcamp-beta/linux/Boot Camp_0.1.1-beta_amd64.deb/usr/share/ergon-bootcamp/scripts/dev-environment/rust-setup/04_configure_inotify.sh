#!/bin/bash
#
# 04_configure_inotify.sh
# inotify 설정 최적화
#
# 설명:
#   - fs.inotify.max_user_watches: 65536 → 524288
#   - fs.inotify.max_user_instances: 128 → 512
#   - 대규모 프로젝트 파일 감시에 필요
#
# 사용법: ./04_configure_inotify.sh
#

set -e

# sudo 공통 라이브러리 로드
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../../lib/sudo.sh"

# sudo 캐시 확인 (Tauri 앱 환경에서 필수)
if ! ensure_sudo_cache; then
    echo -e "${RED}❌ Sudo cache expired or not found${NC}"
    echo "Please verify your password in the password screen first."
    exit 1
fi

echo "=========================================="
echo "  inotify 설정 최적화"
echo "=========================================="
echo ""

# ============================================
# 1. 현재 값 확인
# ============================================
echo "[1/3] 현재 설정값 확인..."

CURRENT_WATCHES=$(cat /proc/sys/fs/inotify/max_user_watches)
CURRENT_INSTANCES=$(cat /proc/sys/fs/inotify/max_user_instances)

TARGET_WATCHES=524288
TARGET_INSTANCES=512

echo "   max_user_watches:   $CURRENT_WATCHES (권장: $TARGET_WATCHES)"
echo "   max_user_instances: $CURRENT_INSTANCES (권장: $TARGET_INSTANCES)"
echo ""

# ============================================
# 2. 설정 필요 여부 확인
# ============================================
NEED_WATCHES=false
NEED_INSTANCES=false

if [[ $CURRENT_WATCHES -lt $TARGET_WATCHES ]]; then
    NEED_WATCHES=true
fi

if [[ $CURRENT_INSTANCES -lt $TARGET_INSTANCES ]]; then
    NEED_INSTANCES=true
fi

if [[ "$NEED_WATCHES" == "false" && "$NEED_INSTANCES" == "false" ]]; then
    echo "   ✓ inotify 설정이 이미 최적화되어 있습니다."
    echo ""
    exit 0
fi

# ============================================
# 3. 설정 적용
# ============================================
echo "[2/3] sysctl 설정 파일 생성..."

SYSCTL_FILE="/etc/sysctl.d/99-inotify.conf"

SYSCTL_CONTENT="# inotify 설정 최적화 (Tauri, VS Code, Node.js 등)
# Created by rust-setup scripts

fs.inotify.max_user_watches = $TARGET_WATCHES
fs.inotify.max_user_instances = $TARGET_INSTANCES
"

# sh -c 패턴 대신 echo와 run_as_root tee 사용 (quoting 이슈 방지)
echo "$SYSCTL_CONTENT" | run_as_root tee "$SYSCTL_FILE" > /dev/null

echo "   ✓ $SYSCTL_FILE 생성됨"
echo ""

# ============================================
# 4. 설정 즉시 적용
# ============================================
echo "[3/3] 설정 즉시 적용 중..."

run_as_root sysctl -p "$SYSCTL_FILE"

echo ""

# ============================================
# 결과 확인
# ============================================
NEW_WATCHES=$(cat /proc/sys/fs/inotify/max_user_watches)
NEW_INSTANCES=$(cat /proc/sys/fs/inotify/max_user_instances)

echo "┌────────────────────────────────────────┐"
echo "│  inotify 설정 완료                      │"
echo "├────────────────────────────────────────┤"
printf "│  max_user_watches:   %-6s → %-6s  │\n" "$CURRENT_WATCHES" "$NEW_WATCHES"
printf "│  max_user_instances: %-6s → %-6s  │\n" "$CURRENT_INSTANCES" "$NEW_INSTANCES"
echo "└────────────────────────────────────────┘"
echo ""

echo "✅ inotify 설정 최적화 완료!"
echo ""
echo "다음 단계: ./05_verify_setup.sh"
echo ""

