#!/bin/bash
#
# 05_map_hangul_key.sh
# 오른쪽 Alt 키를 Hangul 키로 매핑
#

set -e

echo "=========================================="
echo "  한/영 키 매핑"
echo "=========================================="

echo "[1/1] 오른쪽 Alt 키를 Hangul 키로 매핑 중..."

# gsettings로 xkb 옵션 설정
gsettings set org.gnome.desktop.input-sources xkb-options "['korean:ralt_hangul']"

echo ""
echo "✅ 키 매핑 완료!"
echo "   오른쪽 Alt 키가 Hangul 키로 동작합니다."
echo ""
echo "📝 테스트 방법:"
echo "   xev 명령어 실행 후 오른쪽 Alt 키를 누르면 'Hangul'로 표시되어야 합니다."
echo ""



