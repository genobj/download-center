#!/bin/bash
#
# 04_configure_pip_alternatives.sh
# update-alternatives를 사용한 pip 버전 관리 설정
#
# 설명:
#   - 각 Python 버전의 pip를 update-alternatives에 등록
#   - pip 명령어로 원하는 버전의 pip 사용 가능
#
# 사용법: 
#   ./04_configure_pip_alternatives.sh           # 대화형 선택
#   ./04_configure_pip_alternatives.sh 3.12      # 특정 버전 지정
# 필요한 설정: SUDO_PASSWORD (config.local.env)
#

set -e

# sudo 공통 라이브러리 로드
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../../lib/sudo.sh"

# sudo 캐시 확인 (Tauri 앱 환경에서 필수)
if ! ensure_sudo_cache; then
    echo -e "${RED}❌ Sudo cache expired or not found${NC}"
    echo "Please verify your password in the password screen first."
    exit 1
fi

echo "=========================================="
echo "  pip update-alternatives 설정"
echo "=========================================="

# 인자로 받은 기본 버전
DEFAULT_VERSION="${1:-}"

# ============================================
# 1. pip 심볼릭 링크 생성
# ============================================
echo "[1/3] pip 심볼릭 링크 생성 중..."

PYTHON_VERSIONS=("3.10" "3.12" "3.13" "3.14")
INSTALLED_VERSIONS=()

for VERSION in "${PYTHON_VERSIONS[@]}"; do
    PYTHON_BIN="/usr/bin/python${VERSION}"
    PIP_LINK="/usr/bin/pip${VERSION}"
    
    if [[ -x "$PYTHON_BIN" ]]; then
        # pip 작동 확인
        if "$PYTHON_BIN" -m pip --version &>/dev/null; then
            # pip 래퍼 스크립트 생성
            # heredoc은 run_as_root와 함께 사용할 수 없으므로 echo로 변경
            echo "#!/bin/bash
exec /usr/bin/python${VERSION} -m pip \"\$@\"" | run_as_root tee "$PIP_LINK" > /dev/null
            run_as_root chmod +x "$PIP_LINK"
            echo "   ✓ pip${VERSION} 생성"
            INSTALLED_VERSIONS+=("$VERSION")
        fi
    fi
done

if [[ ${#INSTALLED_VERSIONS[@]} -eq 0 ]]; then
    echo "❌ 사용 가능한 pip가 없습니다."
    echo "   먼저 ./03_install_pip.sh 를 실행하세요."
    exit 1
fi

echo ""

# ============================================
# 2. update-alternatives에 등록
# ============================================
echo "[2/3] update-alternatives에 pip 등록 중..."

# 기존 pip alternatives 제거
run_as_root update-alternatives --remove-all pip 2>/dev/null || true

# 각 버전 등록
for VERSION in "${INSTALLED_VERSIONS[@]}"; do
    PRIORITY=$(echo "$VERSION" | tr -d '.')
    PIP_PATH="/usr/bin/pip${VERSION}"
    
    run_as_root update-alternatives --install /usr/bin/pip pip "$PIP_PATH" "$PRIORITY"
    echo "   ✓ pip${VERSION} 등록 (우선순위: ${PRIORITY})"
done

echo ""

# ============================================
# 3. 기본 버전 선택
# ============================================
echo "[3/3] 기본 pip 버전 설정..."

if [[ -n "$DEFAULT_VERSION" ]]; then
    PIP_PATH="/usr/bin/pip${DEFAULT_VERSION}"
    if [[ -x "$PIP_PATH" ]]; then
        run_as_root update-alternatives --set pip "$PIP_PATH"
        echo "   ✓ 기본 버전: pip ${DEFAULT_VERSION}"
    else
        echo "   ⚠️  pip ${DEFAULT_VERSION}이 설치되지 않았습니다."
    fi
else
    echo ""
    echo "┌────────────────────────────────────────┐"
    echo "│  기본 pip 버전을 선택하세요            │"
    echo "└────────────────────────────────────────┘"
    echo ""
    run_as_root update-alternatives --config pip
fi

echo ""

# 명령어 링크 초기화
hash -r 2>/dev/null || true

# 결과 확인
echo "┌────────────────────────────────────────────────────────┐"
echo "│  설정 완료                                              │"
echo "├────────────────────────────────────────────────────────┤"

for VERSION in "${INSTALLED_VERSIONS[@]}"; do
    PIP_INFO=$(pip${VERSION} --version 2>&1 || echo "N/A")
    printf "│  pip%-4s → %-45s │\n" "$VERSION" "$PIP_INFO"
done

echo "├────────────────────────────────────────────────────────┤"

if command -v pip &> /dev/null; then
    PIP_DEFAULT=$(pip --version 2>&1)
    printf "│  pip     → %-45s │\n" "$PIP_DEFAULT"
fi

echo "└────────────────────────────────────────────────────────┘"
echo ""

echo "✅ pip update-alternatives 설정 완료!"
echo ""
echo "💡 버전 변경 방법:"
echo "   sudo update-alternatives --config pip"
echo ""
echo "💡 사용 예시:"
echo "   pip install <package>        # 기본 pip 사용"
echo "   pip3.12 install <package>    # Python 3.12용 pip"
echo "   pip3.13 install <package>    # Python 3.13용 pip"
echo ""


