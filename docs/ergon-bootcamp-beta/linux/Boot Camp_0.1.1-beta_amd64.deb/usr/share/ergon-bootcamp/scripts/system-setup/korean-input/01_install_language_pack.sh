#!/bin/bash
#
# 01_install_language_pack.sh
# 한국어 언어 팩 및 폰트 설치
#
# 사용법: ./01_install_language_pack.sh
# 필요한 설정: SUDO_PASSWORD (config.local.env)
#

set -e

# sudo 공통 라이브러리 로드
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../../lib/sudo.sh"

# sudo 캐시 확인 (Tauri 앱 환경에서 필수)
if ! ensure_sudo_cache; then
    echo -e "${RED}❌ Sudo cache expired or not found${NC}"
    echo "Please verify your password in the password screen first."
    exit 1
fi

echo "=========================================="
echo "  한국어 언어 팩 설치"
echo "=========================================="

# 패키지 목록 업데이트
echo "[1/3] 패키지 목록 업데이트 중..."
run_as_root apt update

# 한국어 언어 팩 설치
echo "[2/3] 한국어 언어 팩 설치 중..."
run_as_root apt install -y language-pack-ko language-pack-gnome-ko

# 한글 폰트 설치
echo "[3/3] 한글 폰트 설치 중..."
run_as_root apt install -y fonts-nanum fonts-noto-cjk

echo ""
echo "✅ 한국어 언어 팩 설치 완료!"
echo ""

