#!/bin/bash
#
# 03_verify_setup.sh
# Git & GitHub CLI 설정 검증
#
# 설명:
#   - Git 사용자 설정 확인
#   - GitHub CLI 설치 및 인증 상태 확인
#
# 사용법: ./03_verify_setup.sh
#

echo "=========================================="
echo "  Git & GitHub CLI 설정 검증"
echo "=========================================="
echo ""

PASS_COUNT=0
FAIL_COUNT=0
WARN_COUNT=0

pass() {
    echo "   ✅ $1"
    PASS_COUNT=$((PASS_COUNT + 1))
}

fail() {
    echo "   ❌ $1"
    FAIL_COUNT=$((FAIL_COUNT + 1))
}

warn() {
    echo "   ⚠️  $1"
    WARN_COUNT=$((WARN_COUNT + 1))
}

# ============================================
# 1. Git 설치 확인
# ============================================
echo "[1/4] Git 설치 확인..."
if command -v git &> /dev/null; then
    GIT_VERSION=$(git --version)
    pass "Git 설치됨: $GIT_VERSION"
else
    fail "Git이 설치되지 않음"
fi
echo ""

# ============================================
# 2. Git 사용자 설정 확인
# ============================================
echo "[2/4] Git 사용자 설정 확인..."

GIT_USER_NAME=$(git config --global user.name 2>/dev/null)
GIT_USER_EMAIL=$(git config --global user.email 2>/dev/null)

if [[ -n "$GIT_USER_NAME" ]]; then
    pass "user.name: $GIT_USER_NAME"
else
    fail "user.name이 설정되지 않음"
fi

if [[ -n "$GIT_USER_EMAIL" ]]; then
    pass "user.email: $GIT_USER_EMAIL"
else
    fail "user.email이 설정되지 않음"
fi

# 추가 설정 확인
DEFAULT_BRANCH=$(git config --global init.defaultBranch 2>/dev/null)
if [[ "$DEFAULT_BRANCH" == "main" ]]; then
    pass "init.defaultBranch: main"
else
    warn "init.defaultBranch이 'main'이 아님: $DEFAULT_BRANCH"
fi
echo ""

# ============================================
# 3. GitHub CLI 설치 확인
# ============================================
echo "[3/4] GitHub CLI 설치 확인..."

if command -v gh &> /dev/null; then
    GH_VERSION=$(gh --version | head -1)
    pass "gh 설치됨: $GH_VERSION"
else
    fail "gh가 설치되지 않음"
    echo ""
    echo "   설치 방법: sudo ./02_install_gh.sh"
fi
echo ""

# ============================================
# 4. GitHub 인증 상태 확인
# ============================================
echo "[4/4] GitHub 인증 상태 확인..."

if command -v gh &> /dev/null; then
    if gh auth status &>/dev/null; then
        AUTH_USER=$(gh auth status 2>&1 | grep "Logged in to" | head -1)
        pass "GitHub 인증됨"
        echo "      $AUTH_USER"
    else
        warn "GitHub 인증 필요"
        echo ""
        echo "      인증 명령어: gh auth login"
    fi
else
    fail "gh가 설치되지 않아 인증 상태 확인 불가"
fi
echo ""

# ============================================
# 결과 요약
# ============================================
echo "=========================================="
echo "  검증 결과"
echo "=========================================="
echo ""
echo "   ✅ PASS: $PASS_COUNT"
echo "   ❌ FAIL: $FAIL_COUNT"
echo "   ⚠️  WARN: $WARN_COUNT"
echo ""

if [[ $FAIL_COUNT -eq 0 ]]; then
    echo "┌────────────────────────────────────────┐"
    echo "│  🎉 Git & GitHub CLI 설정 완료!        │"
    echo "└────────────────────────────────────────┘"
else
    echo "┌────────────────────────────────────────┐"
    echo "│  ⚠️  일부 설정이 필요합니다            │"
    echo "└────────────────────────────────────────┘"
fi
echo ""

