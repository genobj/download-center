#!/bin/bash
#
# 01_install_rust.sh
# Rust 개발 환경 설치 (rustup 공식 설치)
#
# 설명:
#   - rustup을 통해 Rust 툴체인 설치
#   - rustc (컴파일러), cargo (패키지 매니저) 설치
#   - rustfmt, clippy 컴포넌트 추가
#
# 사용법: ./01_install_rust.sh
#

set -e

echo "=========================================="
echo "  Rust 개발 환경 설치"
echo "=========================================="
echo ""

# ============================================
# 1. 기존 설치 확인
# ============================================
echo "[1/4] 기존 Rust 설치 확인 중..."

if command -v rustc &> /dev/null; then
    CURRENT_VERSION=$(rustc --version)
    echo "   ⚠️  Rust가 이미 설치되어 있습니다: ${CURRENT_VERSION}"
    echo ""
    
    # TTY가 있는 경우 사용자 입력 요청 (터미널 환경)
    # TTY가 없는 경우 (Tauri 앱) 자동으로 업데이트 진행 (터미널과 동일한 동작)
    UPDATE_RUST=false
    if [ -t 0 ] && [ -t 1 ]; then
        read -p "   업데이트를 진행하시겠습니까? (y/N): " -n 1 -r
        echo ""
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            UPDATE_RUST=true
        else
            echo "   설치를 건너뜁니다."
            exit 0
        fi
    else
        # TTY가 없는 경우 (Tauri 앱) - 자동으로 업데이트 진행
        UPDATE_RUST=true
    fi
    
    if [ "$UPDATE_RUST" = true ]; then
        echo "   → rustup update 실행 중..."
        rustup update
        echo "   ✓ Rust 업데이트 완료"
        
        # 컴포넌트 확인 및 추가
        echo ""
        echo "[추가] 컴포넌트 확인 중..."
        rustup component add rustfmt clippy 2>/dev/null || true
        echo "   ✓ 컴포넌트 확인 완료"
        
        # 결과 출력 후 종료
        echo ""
        echo "┌────────────────────────────────────────┐"
        echo "│  현재 Rust 버전                        │"
        echo "├────────────────────────────────────────┤"
        printf "│  %-36s │\n" "$(rustc --version)"
        printf "│  %-36s │\n" "$(cargo --version)"
        printf "│  %-36s │\n" "$(rustup --version)"
        echo "└────────────────────────────────────────┘"
        exit 0
    fi
fi

echo "   ✓ 새로 설치를 진행합니다."
echo ""

# ============================================
# 2. 의존성 확인
# ============================================
echo "[2/4] 의존성 확인 중..."

# curl 확인
if ! command -v curl &> /dev/null; then
    echo "   → curl 설치 중..."
    sudo apt-get update -qq
    sudo apt-get install -y curl
fi
echo "   ✓ curl 확인됨"

# build-essential 확인 (링커 등)
if ! dpkg -l | grep -q build-essential; then
    echo "   → build-essential 설치 중..."
    sudo apt-get update -qq
    sudo apt-get install -y build-essential
fi
echo "   ✓ build-essential 확인됨"

echo ""

# ============================================
# 3. rustup 설치
# ============================================
echo "[3/4] rustup으로 Rust 설치 중..."
echo "   출처: https://sh.rustup.rs (공식)"
echo ""

# rustup 설치 (비대화형 모드)
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y --default-toolchain stable

# PATH 설정 로드
source "$HOME/.cargo/env"

echo ""
echo "   ✓ Rust 기본 설치 완료"

# ============================================
# 4. 추가 컴포넌트 설치
# ============================================
echo "[4/4] 추가 컴포넌트 설치 중..."

# rustfmt (코드 포맷터)
rustup component add rustfmt
echo "   ✓ rustfmt 설치됨"

# clippy (린터)
rustup component add clippy
echo "   ✓ clippy 설치됨"

echo ""

# ============================================
# 결과 확인
# ============================================
echo "┌────────────────────────────────────────┐"
echo "│  설치 완료                              │"
echo "├────────────────────────────────────────┤"
printf "│  %-36s │\n" "$(rustc --version)"
printf "│  %-36s │\n" "$(cargo --version)"
printf "│  %-36s │\n" "$(rustup --version 2>&1 | head -1)"
echo "├────────────────────────────────────────┤"
echo "│  Components:                           │"
printf "│  %-36s │\n" "✓ rustfmt (cargo fmt)"
printf "│  %-36s │\n" "✓ clippy (cargo clippy)"
echo "└────────────────────────────────────────┘"
echo ""

echo "📁 설치 위치:"
echo "   CARGO_HOME: $HOME/.cargo"
echo "   RUSTUP_HOME: $HOME/.rustup"
echo ""

echo "✅ Rust 설치 완료!"
echo ""
echo "💡 새 터미널을 열거나 다음 명령어를 실행하세요:"
echo "   source \$HOME/.cargo/env"
echo ""
echo "다음 단계: ./02_verify_setup.sh"
echo ""


