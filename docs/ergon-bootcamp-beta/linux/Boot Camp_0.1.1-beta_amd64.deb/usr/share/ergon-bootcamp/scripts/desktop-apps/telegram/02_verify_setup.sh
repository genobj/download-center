#!/bin/bash
#
# 02_verify_setup.sh
# Telegram Desktop 설치 검증
#
# 사용법: ./02_verify_setup.sh
#

APP_ID="org.telegram.desktop"
APP_NAME="Telegram Desktop"

echo "=========================================="
echo "  $APP_NAME 설치 검증"
echo "=========================================="
echo ""

PASS_COUNT=0
FAIL_COUNT=0

pass() {
    echo "   ✅ $1"
    PASS_COUNT=$((PASS_COUNT + 1))
}

fail() {
    echo "   ❌ $1"
    FAIL_COUNT=$((FAIL_COUNT + 1))
}

# ============================================
# 1. Flatpak 설치 확인
# ============================================
echo "[1/2] Flatpak 환경 확인..."

if command -v flatpak &> /dev/null; then
    pass "Flatpak 설치됨"
else
    fail "Flatpak 미설치"
fi

if flatpak remotes | grep -q flathub; then
    pass "Flathub 저장소 등록됨"
else
    fail "Flathub 저장소 미등록"
fi
echo ""

# ============================================
# 2. Telegram 설치 확인
# ============================================
echo "[2/2] $APP_NAME 확인..."

if flatpak list | grep -q "$APP_ID"; then
    VERSION=$(flatpak info "$APP_ID" 2>/dev/null | grep "Version:" | awk '{print $2}')
    pass "$APP_NAME 설치됨 (v$VERSION)"
else
    fail "$APP_NAME 미설치"
fi
echo ""

# ============================================
# 결과 요약
# ============================================
echo "=========================================="
echo "  검증 결과"
echo "=========================================="
echo ""
echo "   ✅ PASS: $PASS_COUNT"
echo "   ❌ FAIL: $FAIL_COUNT"
echo ""

if [[ $FAIL_COUNT -eq 0 ]]; then
    echo "┌────────────────────────────────────────────────────┐"
    echo "│  🎉 $APP_NAME 설치 완료!                     │"
    echo "├────────────────────────────────────────────────────┤"
    echo "│                                                    │"
    echo "│  실행 방법:                                        │"
    echo "│    flatpak run $APP_ID            │"
    echo "│    또는 앱 메뉴에서 'Telegram' 검색                │"
    echo "│                                                    │"
    echo "│  업데이트:                                         │"
    echo "│    flatpak update $APP_ID         │"
    echo "│                                                    │"
    echo "│  제거:                                             │"
    echo "│    flatpak uninstall $APP_ID      │"
    echo "│                                                    │"
    echo "└────────────────────────────────────────────────────┘"
else
    echo "┌────────────────────────────────────────┐"
    echo "│  ⚠️  설치가 필요합니다                 │"
    echo "└────────────────────────────────────────┘"
    echo ""
    echo "   ./01_install_telegram.sh 실행"
fi
echo ""

