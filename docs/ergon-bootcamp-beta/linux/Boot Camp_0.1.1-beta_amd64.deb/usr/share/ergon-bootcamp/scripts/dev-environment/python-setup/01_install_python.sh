#!/bin/bash
#
# 01_install_python.sh
# Python 버전 설치 (3.10, 3.12, 3.13, 3.14)
#
# 설명:
#   deadsnakes PPA를 통해 여러 Python 버전을 설치합니다.
#   Ubuntu 22.04: 기본 3.10, 추가 3.12, 3.13, 3.14
#   Ubuntu 24.04: 기본 3.12, 추가 3.10, 3.13, 3.14
#
# 사용법: ./01_install_python.sh
# 필요한 설정: SUDO_PASSWORD (config.local.env)
#

set -e

# sudo 공통 라이브러리 로드
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../../lib/sudo.sh"

# sudo 캐시 확인 (Tauri 앱 환경에서 필수)
if ! ensure_sudo_cache; then
    echo -e "${RED}❌ Sudo cache expired or not found${NC}"
    echo "Please verify your password in the password screen first."
    exit 1
fi

echo "=========================================="
echo "  Python 버전 설치"
echo "=========================================="

# Ubuntu 버전 확인
UBUNTU_VERSION=$(lsb_release -rs)
echo "📋 Ubuntu 버전: $UBUNTU_VERSION"
echo ""

# ============================================
# 1. deadsnakes PPA 추가
# ============================================
echo "[1/4] deadsnakes PPA 추가 중..."

# software-properties-common 설치 확인
if ! command -v add-apt-repository &> /dev/null; then
    run_as_root apt-get update -qq
    run_as_root apt-get install -y software-properties-common
fi

# PPA 추가 (이미 있으면 스킵)
if ! grep -q "deadsnakes/ppa" /etc/apt/sources.list.d/*.list 2>/dev/null; then
    run_as_root add-apt-repository -y ppa:deadsnakes/ppa
    echo "   ✓ deadsnakes PPA 추가됨"
else
    echo "   ✓ deadsnakes PPA 이미 존재"
fi

# ============================================
# 2. 패키지 목록 업데이트
# ============================================
echo "[2/4] 패키지 목록 업데이트 중..."
run_as_root apt-get update -qq
echo "   ✓ 패키지 목록 업데이트 완료"

# ============================================
# 3. Python 버전 설치
# ============================================
echo "[3/4] Python 버전 설치 중..."

PYTHON_VERSIONS=("3.10" "3.12" "3.13" "3.14")

for VERSION in "${PYTHON_VERSIONS[@]}"; do
    echo "   → Python ${VERSION} 설치/업데이트 중..."
    
    # Python 및 관련 패키지 설치 (이미 설치된 경우에도 venv, dev 패키지 확인)
    run_as_root apt-get install -y "python${VERSION}" "python${VERSION}-venv" "python${VERSION}-dev" 2>/dev/null || {
        echo "   ⚠️  Python ${VERSION} 설치 실패 (아직 PPA에서 제공하지 않을 수 있음)"
        continue
    }
    
    if command -v "python${VERSION}" &> /dev/null; then
        INSTALLED_VERSION=$("python${VERSION}" --version 2>&1 | awk '{print $2}')
        echo "   ✓ Python ${VERSION} 설치 완료 (${INSTALLED_VERSION})"
    fi
done

# ============================================
# 4. 설치 확인
# ============================================
echo "[4/4] 설치 확인 중..."
echo ""
echo "┌────────────────────────────────────────┐"
echo "│  설치된 Python 버전                    │"
echo "├────────────────────────────────────────┤"

for VERSION in "${PYTHON_VERSIONS[@]}"; do
    if command -v "python${VERSION}" &> /dev/null; then
        FULL_VERSION=$("python${VERSION}" --version 2>&1)
        printf "│  %-36s │\n" "✓ ${FULL_VERSION}"
    else
        printf "│  %-36s │\n" "✗ Python ${VERSION} 미설치"
    fi
done

echo "└────────────────────────────────────────┘"
echo ""

# 설치된 Python 바이너리 목록
echo "📁 /usr/bin/python* 목록:"
ls -la /usr/bin/python* 2>/dev/null | awk '{print "   " $NF}'
echo ""

echo "✅ Python 버전 설치 완료!"
echo ""
echo "다음 단계: ./02_configure_alternatives.sh"
echo ""

