#!/bin/bash
#
# 02_add_flathub.sh
# Flathub 저장소 등록
#
# 설명:
#   - Flatpak 공식 앱 저장소 Flathub 등록
#   - 이미 등록된 경우 건너뜀
#
# 사용법: ./02_add_flathub.sh
#

set -e

# sudo 공통 라이브러리 로드
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../../lib/sudo.sh"

# sudo 캐시 확인 (Tauri 앱 환경에서 필수)
if ! ensure_sudo_cache; then
    echo -e "${RED}❌ Sudo cache expired or not found${NC}"
    echo "Please verify your password in the password screen first."
    exit 1
fi

echo "=========================================="
echo "  Flathub 저장소 등록"
echo "=========================================="
echo ""

# ============================================
# 1. Flatpak 설치 확인
# ============================================
echo "[1/2] Flatpak 설치 확인..."

if ! command -v flatpak &> /dev/null; then
    echo "   ❌ Flatpak이 설치되지 않았습니다."
    echo "   먼저 ./01_install_flatpak.sh를 실행하세요."
    exit 1
fi

echo "   ✓ Flatpak 설치됨"
echo ""

# ============================================
# 2. Flathub 저장소 등록
# ============================================
echo "[2/2] Flathub 저장소 등록..."

if flatpak remotes | grep -q flathub; then
    echo "   ✓ Flathub이 이미 등록되어 있습니다."
else
    FLATHUB_URL="https://dl.flathub.org/repo/flathub.flatpakrepo"
    
    sudo flatpak remote-add --if-not-exists flathub "$FLATHUB_URL"
    
    echo "   ✓ Flathub 저장소 등록됨"
fi

echo ""

# ============================================
# 결과 확인
# ============================================
echo "┌────────────────────────────────────────┐"
echo "│  등록된 저장소                          │"
echo "├────────────────────────────────────────┤"
flatpak remotes | while read -r line; do
    printf "│  %-36s │\n" "$line"
done
echo "└────────────────────────────────────────┘"
echo ""

echo "✅ Flathub 저장소 등록 완료!"
echo ""
echo "💡 앱 검색: flatpak search <키워드>"
echo "💡 앱 설치: flatpak install flathub <app-id>"
echo ""
echo "다음 단계: ./03_configure_permissions.sh"
echo ""

