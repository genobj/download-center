#!/bin/bash
#
# 04_set_default_im.sh
# fcitx5를 기본 입력기로 설정
#

set -e

echo "=========================================="
echo "  기본 입력기 설정"
echo "=========================================="

echo "[1/1] fcitx5를 기본 입력기로 설정 중..."

# im-config로 fcitx5를 기본 입력기로 설정
im-config -n fcitx5

echo ""
echo "✅ 기본 입력기 설정 완료!"
echo "⚠️  변경 사항 적용을 위해 로그아웃/로그인이 필요합니다."
echo ""



