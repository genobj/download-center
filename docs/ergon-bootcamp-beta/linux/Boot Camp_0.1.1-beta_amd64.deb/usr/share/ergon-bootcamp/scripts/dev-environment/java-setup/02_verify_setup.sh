#!/bin/bash
#
# 02_verify_setup.sh
# Java 설치 검증 스크립트
#

echo "=========================================="
echo "  Java 설치 검증"
echo "=========================================="
echo ""

PASS_COUNT=0
FAIL_COUNT=0
WARN_COUNT=0

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

pass() {
    echo -e "${GREEN}✓ PASS${NC}: $1"
    PASS_COUNT=$((PASS_COUNT + 1))
}

fail() {
    echo -e "${RED}✗ FAIL${NC}: $1"
    FAIL_COUNT=$((FAIL_COUNT + 1))
}

warn() {
    echo -e "${YELLOW}⚠ WARN${NC}: $1"
    WARN_COUNT=$((WARN_COUNT + 1))
}

# ============================================
# 1. 기본 명령어 확인
# ============================================
echo "┌────────────────────────────────────────┐"
echo "│  1. 기본 명령어 확인                   │"
echo "└────────────────────────────────────────┘"

if command -v java &> /dev/null; then
    VERSION=$(java --version 2>&1 | head -1)
    pass "java 설치됨 ($VERSION)"
else
    fail "java 미설치"
fi

if command -v javac &> /dev/null; then
    VERSION=$(javac --version 2>&1)
    pass "javac 설치됨 ($VERSION)"
else
    fail "javac 미설치"
fi

if command -v jar &> /dev/null; then
    pass "jar 설치됨"
else
    warn "jar 미설치"
fi

echo ""

# ============================================
# 2. 환경 변수 확인
# ============================================
echo "┌────────────────────────────────────────┐"
echo "│  2. 환경 변수 확인                     │"
echo "└────────────────────────────────────────┘"

if [[ -n "$JAVA_HOME" ]]; then
    pass "JAVA_HOME 설정됨 ($JAVA_HOME)"
else
    # /etc/environment에서 확인
    if grep -q "JAVA_HOME" /etc/environment 2>/dev/null; then
        JAVA_HOME_VAL=$(grep "JAVA_HOME" /etc/environment | cut -d'"' -f2)
        warn "JAVA_HOME 설정됨 ($JAVA_HOME_VAL) - 새 터미널 필요"
    else
        warn "JAVA_HOME 미설정"
    fi
fi

if [[ -d "/usr/lib/jvm/java-21-openjdk-amd64" ]]; then
    pass "OpenJDK 21 디렉토리 존재"
else
    fail "OpenJDK 21 디렉토리 미존재"
fi

echo ""

# ============================================
# 3. 컴파일 테스트
# ============================================
echo "┌────────────────────────────────────────┐"
echo "│  3. 컴파일 테스트                      │"
echo "└────────────────────────────────────────┘"

if command -v javac &> /dev/null; then
    TEMP_DIR=$(mktemp -d)
    cd "$TEMP_DIR"
    
    # Hello World 작성
    cat > HelloWorld.java << 'EOF'
public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello, World!");
    }
}
EOF
    
    # 컴파일 테스트
    if javac HelloWorld.java 2>/dev/null; then
        pass "javac 컴파일 성공"
        
        # 실행 테스트
        OUTPUT=$(java HelloWorld 2>/dev/null)
        if [[ "$OUTPUT" == "Hello, World!" ]]; then
            pass "java 실행 성공 (Hello, World!)"
        else
            fail "java 실행 실패"
        fi
    else
        fail "javac 컴파일 실패"
    fi
    
    cd /
    rm -rf "$TEMP_DIR"
else
    warn "javac 없어서 컴파일 테스트 스킵"
fi

echo ""

# ============================================
# 4. 버전 확인
# ============================================
echo "┌────────────────────────────────────────┐"
echo "│  4. 버전 상세 확인                     │"
echo "└────────────────────────────────────────┘"

if java --version 2>&1 | grep -q "21"; then
    pass "OpenJDK 21 버전 확인됨"
else
    warn "OpenJDK 21이 아닌 다른 버전"
fi

echo ""

# ============================================
# 결과 요약
# ============================================
echo "=========================================="
echo "  검증 결과 요약"
echo "=========================================="
echo ""
echo -e "  ${GREEN}✓ PASS${NC}: ${PASS_COUNT}"
echo -e "  ${YELLOW}⚠ WARN${NC}: ${WARN_COUNT}"
echo -e "  ${RED}✗ FAIL${NC}: ${FAIL_COUNT}"
echo ""

if [[ $FAIL_COUNT -eq 0 ]]; then
    if [[ $WARN_COUNT -eq 0 ]]; then
        echo -e "${GREEN}🎉 모든 테스트 통과!${NC}"
    else
        echo -e "${YELLOW}⚠️  일부 경고가 있지만 기본 기능은 정상입니다.${NC}"
    fi
    EXIT_CODE=0
else
    echo -e "${RED}❌ 일부 테스트 실패. 위의 FAIL 항목을 확인하세요.${NC}"
    EXIT_CODE=1
fi

echo ""
echo "=========================================="
echo ""

exit $EXIT_CODE


