#!/bin/bash
#
# 06_setup_autostart.sh
# fcitx5 자동 시작 설정
#

set -e

echo "=========================================="
echo "  fcitx5 자동 시작 설정"
echo "=========================================="

AUTOSTART_DIR="$HOME/.config/autostart"
DESKTOP_FILE="$AUTOSTART_DIR/fcitx5.desktop"

# autostart 디렉토리 생성
echo "[1/2] autostart 디렉토리 확인 중..."
mkdir -p "$AUTOSTART_DIR"

# 이미 설정되어 있는지 확인
if [ -f "$DESKTOP_FILE" ]; then
    echo "⚠️  자동 시작이 이미 설정되어 있습니다."
    exit 0
fi

# autostart desktop 파일 생성
echo "[2/2] 자동 시작 파일 생성 중..."
cat > "$DESKTOP_FILE" << 'EOF'
[Desktop Entry]
Name=Fcitx 5
GenericName=Input Method
Comment=Start Input Method
Exec=fcitx5
Icon=fcitx
Terminal=false
Type=Application
Categories=System;Utility;
X-GNOME-Autostart-Phase=Applications
X-GNOME-AutoRestart=false
X-GNOME-Autostart-Notify=false
X-KDE-autostart-after=panel
EOF

echo ""
echo "✅ 자동 시작 설정 완료!"
echo "   다음 로그인부터 fcitx5가 자동으로 시작됩니다."
echo ""



