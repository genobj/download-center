#!/bin/bash
#
# 04_verify_setup.sh
# Flatpak 설정 검증
#
# 설명:
#   - Flatpak 설치 확인
#   - Flathub 저장소 확인
#   - 권한 설정 확인
#
# 사용법: ./04_verify_setup.sh
#

echo "=========================================="
echo "  Flatpak 설정 검증"
echo "=========================================="
echo ""

PASS_COUNT=0
FAIL_COUNT=0
WARN_COUNT=0

pass() {
    echo "   ✅ $1"
    PASS_COUNT=$((PASS_COUNT + 1))
}

fail() {
    echo "   ❌ $1"
    FAIL_COUNT=$((FAIL_COUNT + 1))
}

warn() {
    echo "   ⚠️  $1"
    WARN_COUNT=$((WARN_COUNT + 1))
}

# ============================================
# 1. Flatpak 설치 확인
# ============================================
echo "[1/3] Flatpak 설치 확인..."

if command -v flatpak &> /dev/null; then
    FLATPAK_VERSION=$(flatpak --version)
    pass "$FLATPAK_VERSION"
else
    fail "Flatpak 미설치"
fi
echo ""

# ============================================
# 2. 저장소 확인
# ============================================
echo "[2/3] 저장소 확인..."

if command -v flatpak &> /dev/null; then
    if flatpak remotes | grep -q flathub; then
        pass "Flathub 저장소 등록됨"
    else
        fail "Flathub 저장소 미등록"
    fi
else
    fail "Flatpak 미설치로 확인 불가"
fi
echo ""

# ============================================
# 3. 권한 설정 확인
# ============================================
echo "[3/3] 권한 설정 확인..."

if command -v flatpak &> /dev/null; then
    OVERRIDES=$(flatpak override --show 2>/dev/null || echo "")
    
    if echo "$OVERRIDES" | grep -q "/usr/share/fonts"; then
        pass "시스템 폰트 접근 허용됨"
    else
        warn "시스템 폰트 접근 미설정 (./03_configure_permissions.sh 실행)"
    fi
else
    fail "Flatpak 미설치로 확인 불가"
fi
echo ""

# ============================================
# 결과 요약
# ============================================
echo "=========================================="
echo "  검증 결과"
echo "=========================================="
echo ""
echo "   ✅ PASS: $PASS_COUNT"
echo "   ❌ FAIL: $FAIL_COUNT"
echo "   ⚠️  WARN: $WARN_COUNT"
echo ""

if [[ $FAIL_COUNT -eq 0 ]]; then
    echo "┌────────────────────────────────────────────────────┐"
    echo "│  🎉 Flatpak 설정 완료!                             │"
    echo "├────────────────────────────────────────────────────┤"
    echo "│                                                    │"
    echo "│  앱 검색: flatpak search <키워드>                  │"
    echo "│  앱 설치: flatpak install flathub <app-id>         │"
    echo "│  앱 실행: flatpak run <app-id>                     │"
    echo "│                                                    │"
    echo "│  💡 GUI로 관리하려면:                              │"
    echo "│     desktop-apps/gnome-software 설치               │"
    echo "│                                                    │"
    echo "├────────────────────────────────────────────────────┤"
    echo "│  ⚠️  중요: 재부팅 필요!                            │"
    echo "│                                                    │"
    echo "│  Flatpak 앱이 앱 메뉴에 표시되려면                 │"
    echo "│  반드시 재부팅하거나 로그아웃 후 재로그인하세요.   │"
    echo "│                                                    │"
    echo "│  재부팅: sudo reboot                               │"
    echo "│                                                    │"
    echo "└────────────────────────────────────────────────────┘"
else
    echo "┌────────────────────────────────────────┐"
    echo "│  ⚠️  일부 설정이 필요합니다            │"
    echo "└────────────────────────────────────────┘"
fi
echo ""

