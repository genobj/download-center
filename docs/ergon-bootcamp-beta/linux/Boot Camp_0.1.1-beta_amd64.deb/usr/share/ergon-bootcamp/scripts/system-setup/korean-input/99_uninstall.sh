#!/bin/bash
#
# 99_uninstall.sh
# 자동 생성된 삭제 스크립트
#

set -e

# 환경 변수 설정 (비대화형 모드)
export DEBIAN_FRONTEND=noninteractive
export APT_LISTCHANGES_FRONTEND=none

# sudo 캐시 확인 (만료되었으면 에러)
if ! sudo -n -v 2>/dev/null; then
    echo "❌ Sudo cache expired. Please verify your password first."
    exit 1
fi

# sudo 공통 라이브러리 로드 (캐시가 유효한 경우에만)
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# sudo.sh의 ensure_sudo_cache는 이미 캐시가 유효하면 바로 통과하므로 안전
source "$SCRIPT_DIR/../../lib/sudo.sh"

echo "=========================================="
echo "  삭제 중..."
echo "=========================================="
echo ""

echo "[1/3] sudo apt remove -y fcitx5"
sudo apt remove -y fcitx5
echo ""

echo "[2/3] sudo apt remove -y fonts-nanum"
sudo apt remove -y fonts-nanum
echo ""

echo "[3/3] sudo apt remove -y language-pack-ko"
sudo apt remove -y language-pack-ko
echo ""

echo "✅ 삭제 완료!"
echo ""
