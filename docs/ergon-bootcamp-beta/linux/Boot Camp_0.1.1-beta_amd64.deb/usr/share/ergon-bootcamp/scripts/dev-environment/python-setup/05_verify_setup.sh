#!/bin/bash
#
# 05_verify_setup.sh
# Python 및 pip 설정 검증 스크립트
#
# 설명:
#   - 설치된 Python 버전 확인
#   - update-alternatives 설정 확인
#   - pip 설치 및 설정 확인
#   - 가상환경 생성 테스트
#   - 패키지 설치 테스트
#
# 사용법: ./05_verify_setup.sh
#

# set -e 제거 - 카운터 증가 시 문제 발생

echo "=========================================="
echo "  Python 설정 검증"
echo "=========================================="
echo ""

PASS_COUNT=0
FAIL_COUNT=0
WARN_COUNT=0

# 색상 정의
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

pass() {
    echo -e "${GREEN}✓ PASS${NC}: $1"
    PASS_COUNT=$((PASS_COUNT + 1))
}

fail() {
    echo -e "${RED}✗ FAIL${NC}: $1"
    FAIL_COUNT=$((FAIL_COUNT + 1))
}

warn() {
    echo -e "${YELLOW}⚠ WARN${NC}: $1"
    WARN_COUNT=$((WARN_COUNT + 1))
}

# ============================================
# 1. Python 버전 확인
# ============================================
echo "┌────────────────────────────────────────┐"
echo "│  1. Python 버전 확인                   │"
echo "└────────────────────────────────────────┘"

PYTHON_VERSIONS=("3.10" "3.12" "3.13" "3.14")

for VERSION in "${PYTHON_VERSIONS[@]}"; do
    if command -v "python${VERSION}" &> /dev/null; then
        FULL_VERSION=$(python${VERSION} --version 2>&1)
        pass "Python ${VERSION} 설치됨 (${FULL_VERSION})"
    else
        warn "Python ${VERSION} 미설치"
    fi
done

echo ""

# ============================================
# 2. python 명령어 확인
# ============================================
echo "┌────────────────────────────────────────┐"
echo "│  2. python 명령어 확인                 │"
echo "└────────────────────────────────────────┘"

if command -v python &> /dev/null; then
    PYTHON_VERSION=$(python --version 2>&1)
    pass "python 명령어 작동 (${PYTHON_VERSION})"
else
    fail "python 명령어 없음"
fi

if command -v python3 &> /dev/null; then
    PYTHON3_VERSION=$(python3 --version 2>&1)
    pass "python3 명령어 작동 (${PYTHON3_VERSION})"
else
    fail "python3 명령어 없음"
fi

echo ""

# ============================================
# 3. update-alternatives 확인
# ============================================
echo "┌────────────────────────────────────────┐"
echo "│  3. update-alternatives 확인           │"
echo "└────────────────────────────────────────┘"

if update-alternatives --display python &>/dev/null; then
    CURRENT=$(update-alternatives --query python 2>/dev/null | grep "Value:" | awk '{print $2}')
    pass "Python alternatives 설정됨 (현재: ${CURRENT})"
else
    warn "Python alternatives 미설정"
fi

if update-alternatives --display pip &>/dev/null; then
    CURRENT=$(update-alternatives --query pip 2>/dev/null | grep "Value:" | awk '{print $2}')
    pass "pip alternatives 설정됨 (현재: ${CURRENT})"
else
    warn "pip alternatives 미설정"
fi

echo ""

# ============================================
# 4. pip 확인
# ============================================
echo "┌────────────────────────────────────────┐"
echo "│  4. pip 확인                           │"
echo "└────────────────────────────────────────┘"

for VERSION in "${PYTHON_VERSIONS[@]}"; do
    PYTHON_BIN="/usr/bin/python${VERSION}"
    if [[ -x "$PYTHON_BIN" ]]; then
        if "$PYTHON_BIN" -m pip --version &>/dev/null; then
            PIP_INFO=$("$PYTHON_BIN" -m pip --version 2>&1 | awk '{print $2}')
            pass "pip for Python ${VERSION} 작동 (pip ${PIP_INFO})"
        else
            warn "pip for Python ${VERSION} 미설치"
        fi
    fi
done

if command -v pip &> /dev/null; then
    PIP_VERSION=$(pip --version 2>&1)
    pass "pip 명령어 작동 (${PIP_VERSION})"
else
    warn "pip 명령어 없음"
fi

echo ""

# ============================================
# 5. 가상환경 테스트
# ============================================
echo "┌────────────────────────────────────────┐"
echo "│  5. 가상환경 테스트                    │"
echo "└────────────────────────────────────────┘"

TEMP_VENV=$(mktemp -d)/test_venv

# 기본 python으로 venv 테스트
if command -v python &> /dev/null; then
    if python -m venv "$TEMP_VENV" 2>/dev/null; then
        pass "python -m venv 작동"
        
        # venv 활성화 테스트
        if source "$TEMP_VENV/bin/activate" 2>/dev/null; then
            VENV_PYTHON=$(which python)
            pass "가상환경 활성화 성공 (${VENV_PYTHON})"
            deactivate 2>/dev/null || true
        else
            fail "가상환경 활성화 실패"
        fi
        
        rm -rf "$(dirname $TEMP_VENV)"
    else
        fail "python -m venv 실패"
    fi
else
    warn "python 명령어 없어 venv 테스트 스킵"
fi

echo ""

# ============================================
# 6. 패키지 설치 테스트 (선택적)
# ============================================
echo "┌────────────────────────────────────────┐"
echo "│  6. 패키지 설치 테스트                 │"
echo "└────────────────────────────────────────┘"

# 임시 venv에서 패키지 설치 테스트
TEMP_VENV2=$(mktemp -d)/pkg_test_venv

if command -v python3 &> /dev/null; then
    if python3 -m venv "$TEMP_VENV2" 2>/dev/null; then
        source "$TEMP_VENV2/bin/activate" 2>/dev/null
        
        # pip 업그레이드 테스트
        if pip install --upgrade pip -q 2>/dev/null; then
            pass "pip 업그레이드 성공"
        else
            warn "pip 업그레이드 실패"
        fi
        
        # 간단한 패키지 설치 테스트
        if pip install requests -q 2>/dev/null; then
            pass "패키지 설치 테스트 성공 (requests)"
            
            # import 테스트
            if python -c "import requests; print(f'requests {requests.__version__}')" 2>/dev/null; then
                pass "패키지 import 테스트 성공"
            else
                fail "패키지 import 실패"
            fi
        else
            fail "패키지 설치 실패"
        fi
        
        deactivate 2>/dev/null || true
        rm -rf "$(dirname $TEMP_VENV2)"
    fi
fi

echo ""

# ============================================
# 결과 요약
# ============================================
echo "=========================================="
echo "  검증 결과 요약"
echo "=========================================="
echo ""
echo -e "  ${GREEN}✓ PASS${NC}: ${PASS_COUNT}"
echo -e "  ${YELLOW}⚠ WARN${NC}: ${WARN_COUNT}"
echo -e "  ${RED}✗ FAIL${NC}: ${FAIL_COUNT}"
echo ""

if [[ $FAIL_COUNT -eq 0 ]]; then
    if [[ $WARN_COUNT -eq 0 ]]; then
        echo -e "${GREEN}🎉 모든 테스트 통과!${NC}"
    else
        echo -e "${YELLOW}⚠️  일부 경고가 있지만 기본 기능은 정상입니다.${NC}"
    fi
    EXIT_CODE=0
else
    echo -e "${RED}❌ 일부 테스트 실패. 위의 FAIL 항목을 확인하세요.${NC}"
    EXIT_CODE=1
fi

echo ""
echo "=========================================="
echo ""

exit $EXIT_CODE

