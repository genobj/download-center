#!/bin/bash
#
# 03_pin_to_taskbar.sh
# Microsoft Edge를 GNOME 태스크바(dock)에 고정
#
# 사용법: ./03_pin_to_taskbar.sh
#

set -e

echo "=========================================="
echo "  Microsoft Edge 태스크바 고정"
echo "=========================================="

# 데스크톱 환경 확인
echo "현재 환경: $XDG_CURRENT_DESKTOP"

# Unity 또는 GNOME이 아닌 경우
if [[ "$XDG_CURRENT_DESKTOP" != *"GNOME"* ]] && [[ "$XDG_CURRENT_DESKTOP" != "Unity" ]]; then
    echo "⚠️  지원하지 않는 데스크톱 환경입니다."
    echo "   현재 환경: $XDG_CURRENT_DESKTOP"
    exit 0
fi

# .desktop 파일 확인
DESKTOP_FILE="/usr/share/applications/microsoft-edge.desktop"
if [ ! -f "$DESKTOP_FILE" ]; then
    echo "❌ Microsoft Edge .desktop 파일을 찾을 수 없습니다."
    echo "   먼저 Edge를 설치해주세요."
    exit 1
fi

# 현재 즐겨찾기 목록 가져오기
echo "[1/2] 현재 즐겨찾기 목록 확인 중..."
CURRENT_FAVORITES=$(gsettings get org.gnome.shell favorite-apps)

# 이미 고정되어 있는지 확인
if echo "$CURRENT_FAVORITES" | grep -q "microsoft-edge.desktop"; then
    echo "⚠️  Microsoft Edge가 이미 태스크바에 고정되어 있습니다."
    exit 0
fi

# 새 즐겨찾기 목록 생성 (기존 목록에 추가)
echo "[2/2] 태스크바에 고정 중..."
NEW_FAVORITES=$(echo "$CURRENT_FAVORITES" | sed "s/]$/, 'microsoft-edge.desktop']/")
gsettings set org.gnome.shell favorite-apps "$NEW_FAVORITES"

echo ""
echo "✅ Microsoft Edge가 태스크바에 고정되었습니다!"
echo ""

