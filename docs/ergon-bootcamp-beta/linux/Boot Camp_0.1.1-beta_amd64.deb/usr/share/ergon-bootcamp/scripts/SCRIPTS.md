# Scripts Guide

이 문서는 `scripts/` 폴더의 **스크립트 JSON 파일 생성 규칙**입니다.

---

## 폴더 구조

```
scripts/
├── config.example.env          # 설정 템플릿 (git에 커밋)
├── config.local.env            # 실제 설정값 (gitignored)
├── config.schema.json          # 설정 키 스키마
├── config-loader.sh            # 설정 로더 헬퍼
├── scripts.json                # 전체 카테고리 목록
├── SCRIPTS.md                  # 이 문서 (규칙)
│
├── schemas/                    # JSON 스키마 정의
│   ├── step.schema.json
│   ├── topic.schema.json
│   ├── category.schema.json
│   ├── scripts.schema.json
│   └── checklist.schema.json
│
└── {category}/                 # 카테고리 (1st depth)
    ├── category.json
    └── {topic}/                # 토픽 (2nd depth)
        ├── master.json
        ├── checklist.json
        ├── checklist.sh
        └── XX_step.sh / .json
```

---

## JSON 스키마 참조 (필수)

### 파일별 스키마 매핑

| 파일 | 스키마 | 설명 |
|------|--------|------|
| `scripts.json` | `schemas/scripts.schema.json` | 루트 - 카테고리 목록 |
| `{category}/category.json` | `schemas/category.schema.json` | 카테고리 메타데이터 |
| `{topic}/master.json` | `schemas/topic.schema.json` | 토픽 - 스텝 목록 |
| `{topic}/checklist.json` | `schemas/checklist.schema.json` | 진행 상태 추적 |
| `{topic}/XX_*.json` | `schemas/step.schema.json` | 개별 스텝 메타데이터 |

### JSON 생성 시 규칙

1. **반드시 스키마 참조**: 새 JSON 파일 생성 시 해당 스키마를 먼저 확인
2. **필수 필드 포함**: 스키마의 `required` 필드는 반드시 포함
3. **타입 준수**: 스키마에 정의된 타입과 형식 준수

---

## Step 메타데이터 규칙 (XX_*.json)

### 필수 필드

```json
{
  "id": "01_example_step",
  "name": "예제 스텝 (한글)",
  "name_en": "Example Step",
  "description": "상세 설명",
  "version": "1.0.0",
  "requires": {
    "sudo": false,
    "shell_reload": false,
    "logout": false,
    "reboot": false
  },
  "required_inputs": [],
  "order": 1
}
```

### required_inputs 규칙

sudo 또는 사용자 입력이 필요한 경우 반드시 명시:

```json
"required_inputs": [
  {
    "key": "SUDO_PASSWORD",
    "description": "sudo 명령 실행에 필요한 비밀번호",
    "type": "password",
    "required": true
  },
  {
    "key": "GIT_USER_EMAIL",
    "description": "Git 사용자 이메일",
    "type": "email",
    "required": true
  }
]
```

### required_inputs 타입

| 타입 | 설명 | 예시 |
|------|------|------|
| `string` | 일반 문자열 | 이름, 경로 |
| `password` | 비밀번호 (민감) | sudo 비밀번호, 토큰 |
| `email` | 이메일 형식 | Git 이메일 |
| `path` | 파일/디렉토리 경로 | 프로젝트 경로 |
| `number` | 숫자 | 포트 번호 |
| `boolean` | true/false | 옵션 플래그 |

---

## Config 관리

### 민감한 정보 처리

1. **config.local.env**는 git에 커밋하지 않음 (.gitignore에 포함)
2. **config.example.env**는 템플릿으로 커밋
3. 스크립트는 `config-loader.sh`를 통해 설정 로드

### 스크립트에서 config 사용

```bash
# config-loader 로드
source "$SCRIPT_DIR/../../config-loader.sh"

# 설정 로드 및 검증
load_config
validate_config "SUDO_PASSWORD" "GIT_USER_EMAIL"

# sudo 명령 실행
run_sudo apt update
```

---

## 네이밍 규칙

### 폴더명
- 소문자, 하이픈 사용: `korean-input`, `git-setup`

### 스크립트 파일명
- 2자리 숫자 접두사 + 스네이크케이스: `01_install_packages.sh`
- 같은 이름의 JSON 메타데이터: `01_install_packages.json`

### ID 패턴
- step: `01_install_language_pack`
- category: `dev-environment`
- topic: `korean-input`

---

## 설치 전 필수 사항 (Prerequisites)

### 기본 의존성 설치

외부 저장소를 사용하는 패키지 설치 전에 **반드시** `prerequisites`를 먼저 실행해야 합니다:

```bash
# 기본 의존성 설치 (최초 1회)
./scripts/dev-environment/prerequisites/01_create_keyrings_dir.sh
./scripts/dev-environment/prerequisites/02_install_base_packages.sh
```

### 필수 패키지

| 패키지 | 용도 |
|--------|------|
| `software-properties-common` | PPA 관리 도구 |
| `apt-transport-https` | HTTPS 저장소 지원 |
| `wget` | 파일 다운로드 |
| `gpg` | GPG 키 관리 |
| `curl` | HTTP 클라이언트 |
| `ca-certificates` | SSL 인증서 |

### GPG 키링 디렉토리

- **위치**: `/etc/apt/keyrings/` (Ubuntu 22.04+ 권장)
- **❌ 금지**: `apt-key` 사용 (보안상 deprecated)
- **✅ 권장**: `gpg --dearmor`로 키 저장

---

## 보안 규칙 (필수)

### 패키지 설치 원칙

1. **공식 패키지만 사용**
   - Ubuntu 공식 저장소 (`apt`) 우선 사용
   - GPG 키가 확인된 공식 저장소만 추가
   - 비공식 PPA는 사용 금지

2. **안정 버전 사용**
   - LTS 또는 Stable 버전만 사용
   - Beta, Nightly, Dev 버전 사용 금지
   - 검증된 대중적인 버전 선택

3. **공식 프로그램 우선**

   | ✅ 사용 | ❌ 금지 | 이유 |
   |---------|---------|------|
   | Google Chrome | Chromium | 공식 지원, 보안 업데이트 |
   | Docker Official | Docker.io (Ubuntu) | 최신 버전, 공식 GPG |
   | Node.js (nvm) | Ubuntu nodejs | 버전 관리, 공식 |
   | VS Code | Code-OSS | 공식 마켓플레이스 |

4. **GPG 키 검증 및 저장**
   - 외부 저장소 추가 시 반드시 GPG 키 확인
   - 키는 공식 문서에서 확인된 것만 사용
   - **키 저장 위치**: `/etc/apt/keyrings/` (필수)
   - **❌ 금지**: `apt-key add` (deprecated, 보안 취약)
   - **❌ 금지**: `/usr/share/keyrings/` (시스템 키링과 혼동)
   
   ```bash
   # ✅ 올바른 예: /etc/apt/keyrings/에 저장
   wget -qO /tmp/key.pub https://example.com/key.pub
   gpg --batch --yes --dearmor -o /tmp/key.gpg /tmp/key.pub
   sudo mv /tmp/key.gpg /etc/apt/keyrings/example.gpg
   sudo chmod 644 /etc/apt/keyrings/example.gpg
   
   # 저장소 추가 시 키링 지정
   echo "deb [arch=amd64 signed-by=/etc/apt/keyrings/example.gpg] https://example.com/repo stable main" | sudo tee /etc/apt/sources.list.d/example.list
   ```
   
   ```bash
   # ❌ 잘못된 예: apt-key 사용 (deprecated)
   curl -fsSL https://example.com/key.pub | sudo apt-key add -
   ```

5. **불확실한 경우**
   - 공식 패키지가 없거나 불확실한 경우 **반드시 사용자에게 확인**
   - 메타데이터에 `"requires_user_approval": true` 추가

### 금지 사항

- ❌ 비공식 PPA 추가
- ❌ curl | bash 파이프라인 (검증 없이)
- ❌ 출처 불명의 .deb 파일 설치
- ❌ Snap/Flatpak 비공식 패키지

---

## 체크리스트

새 스크립트 추가 시:

- [ ] 스키마 참조하여 JSON 메타데이터 생성
- [ ] `required_inputs` 필드 확인 (sudo 필요시 SUDO_PASSWORD 추가)
- [ ] **보안 검증**: 모든 패키지가 Ubuntu 공식 또는 GPG 검증된 공식 저장소인지 확인
- [ ] 비공식 패키지 필요 시 `requires_user_approval: true` 설정
- [ ] `master.json`에 스크립트 추가
- [ ] `checklist.json`에 스텝 추가
- [ ] 쉘 스크립트에 `config-loader.sh` 연동

---

**최종 업데이트**: 2025년 12월 6일

