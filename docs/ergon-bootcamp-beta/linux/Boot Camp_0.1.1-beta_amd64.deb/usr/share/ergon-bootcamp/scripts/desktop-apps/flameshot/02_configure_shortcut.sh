#!/bin/bash
#
# 02_configure_shortcut.sh
# Flameshot 키보드 단축키 설정
#
# 기능:
#   - X11: 자동으로 gsettings로 단축키 설정
#   - Wayland: 수동 설정 가이드 출력
#
# 사용법: ./02_configure_shortcut.sh
#

set -e

echo "=========================================="
echo "  Flameshot 단축키 설정"
echo "=========================================="

# Pictures 폴더 확인/생성
PICTURES_DIR="$HOME/Pictures/Screenshots"
mkdir -p "$PICTURES_DIR"
echo "📁 스크린샷 저장 위치: $PICTURES_DIR"
echo ""

# ============================================
# 세션 타입 확인
# ============================================
SESSION_TYPE="${XDG_SESSION_TYPE:-unknown}"
echo "📺 세션 타입: $SESSION_TYPE"
echo ""

# ============================================
# Wayland 환경 - 수동 설정 가이드 출력
# ============================================
if [[ "$SESSION_TYPE" == "wayland" ]]; then
    echo "⚠️  Wayland 환경 감지!"
    echo ""
    echo "Wayland에서는 Flameshot이 직접 화면을 캡처할 수 없습니다."
    echo "GNOME Settings에서 수동으로 단축키를 설정해야 합니다."
    echo ""
    echo "┌─────────────────────────────────────────────────────────────┐"
    echo "│  📋 수동 설정 가이드                                        │"
    echo "├─────────────────────────────────────────────────────────────┤"
    echo "│                                                             │"
    echo "│  1. Settings → Keyboard → Keyboard Shortcuts 열기          │"
    echo "│                                                             │"
    echo "│  2. Screenshots 카테고리에서 기존 단축키 비활성화:          │"
    echo "│     - 'Take a screenshot interactively' (Print) → 비활성화 │"
    echo "│                                                             │"
    echo "│  3. Custom Shortcuts → Add Shortcut 클릭                   │"
    echo "│                                                             │"
    echo "│  4. 아래 내용 입력:                                         │"
    echo "│     Name: Flameshot                                         │"
    echo "│     Command: flameshot gui                                  │"
    echo "│                                                             │"
    echo "│  5. Shortcut 클릭 → Print Screen 키 누르기                 │"
    echo "│                                                             │"
    echo "│  6. Add 버튼 클릭                                           │"
    echo "│                                                             │"
    echo "└─────────────────────────────────────────────────────────────┘"
    echo ""
    echo "┌─────────────────────────────────────────────────────────────┐"
    echo "│  🔧 사용 가능한 Command 옵션                                │"
    echo "├─────────────────────────────────────────────────────────────┤"
    echo "│                                                             │"
    echo "│  ▶ 가장 기본:                                               │"
    echo "│    flameshot gui                                            │"
    echo "│                                                             │"
    echo "│  ▶ 캡처 후 Pictures 폴더에 자동 저장:                       │"
    echo "│    flameshot gui --path ~/Pictures                          │"
    echo "│                                                             │"
    echo "│  ▶ 현재 모니터 전체 캡처:                                   │"
    echo "│    flameshot screen --path ~/Pictures                       │"
    echo "│                                                             │"
    echo "│  ▶ 모든 모니터 전체 캡처:                                   │"
    echo "│    flameshot full --path ~/Pictures                         │"
    echo "│                                                             │"
    echo "│  ▶ 캡처 + 클립보드 + 화면고정 + 저장 (풀옵션):              │"
    echo "│    flameshot gui --clipboard --pin --path ~/Pictures        │"
    echo "│                                                             │"
    echo "└─────────────────────────────────────────────────────────────┘"
    echo ""
    echo "💡 Tip: X11 세션으로 로그인하면 자동 설정이 가능합니다."
    echo "       로그인 화면 → 톱니바퀴 ⚙️ → 'Ubuntu on Xorg' 선택"
    echo ""
    exit 0
fi

# ============================================
# X11 환경 - 자동 설정
# ============================================
echo "[1/3] 기존 GNOME 스크린샷 단축키 제거 중..."

# GNOME Shell 스크린샷 키 비활성화
gsettings set org.gnome.shell.keybindings screenshot "[]" 2>/dev/null || true
gsettings set org.gnome.shell.keybindings screenshot-window "[]" 2>/dev/null || true
gsettings set org.gnome.shell.keybindings show-screenshot-ui "[]" 2>/dev/null || true

# GNOME Settings Daemon 스크린샷 키 비활성화
gsettings set org.gnome.settings-daemon.plugins.media-keys screenshot "" 2>/dev/null || true
gsettings set org.gnome.settings-daemon.plugins.media-keys screenshot-clip "" 2>/dev/null || true
gsettings set org.gnome.settings-daemon.plugins.media-keys window-screenshot "" 2>/dev/null || true
gsettings set org.gnome.settings-daemon.plugins.media-keys window-screenshot-clip "" 2>/dev/null || true
gsettings set org.gnome.settings-daemon.plugins.media-keys area-screenshot "" 2>/dev/null || true
gsettings set org.gnome.settings-daemon.plugins.media-keys area-screenshot-clip "" 2>/dev/null || true

echo "   ✓ 기존 GNOME 스크린샷 단축키 제거됨"

echo "[2/3] Flameshot 단축키 설정 중..."

# 키바인딩 경로 정의
FLAMESHOT_PATH="/org/gnome/settings-daemon/plugins/media-keys/custom-keybindings/flameshot/"
FLAMESHOT_FULL_PATH="/org/gnome/settings-daemon/plugins/media-keys/custom-keybindings/flameshot-full/"

# 커스텀 키바인딩 목록 설정
gsettings set org.gnome.settings-daemon.plugins.media-keys custom-keybindings "['$FLAMESHOT_PATH', '$FLAMESHOT_FULL_PATH']"

# Flameshot GUI (Print Screen)
gsettings set org.gnome.settings-daemon.plugins.media-keys.custom-keybinding:$FLAMESHOT_PATH name "Flameshot"
gsettings set org.gnome.settings-daemon.plugins.media-keys.custom-keybinding:$FLAMESHOT_PATH command "flameshot gui --clipboard --path $PICTURES_DIR"
gsettings set org.gnome.settings-daemon.plugins.media-keys.custom-keybinding:$FLAMESHOT_PATH binding "Print"

echo "   ✓ Print Screen → Flameshot GUI"

# Flameshot Full Screen (Ctrl+Print Screen)
gsettings set org.gnome.settings-daemon.plugins.media-keys.custom-keybinding:$FLAMESHOT_FULL_PATH name "Flameshot Full Screen"
gsettings set org.gnome.settings-daemon.plugins.media-keys.custom-keybinding:$FLAMESHOT_FULL_PATH command "flameshot full --clipboard --path $PICTURES_DIR"
gsettings set org.gnome.settings-daemon.plugins.media-keys.custom-keybinding:$FLAMESHOT_FULL_PATH binding "<Control>Print"

echo "   ✓ Ctrl+Print Screen → 전체화면 캡처"

echo "[3/3] 설정 확인 중..."

echo ""
echo "✅ Flameshot 단축키 설정 완료!"
echo ""
echo "┌─────────────────────────────────────────┐"
echo "│  설정된 단축키                          │"
echo "├─────────────────────────────────────────┤"
echo "│  Print Screen      → 영역 선택 캡처    │"
echo "│  Ctrl+Print Screen → 전체화면 캡처     │"
echo "└─────────────────────────────────────────┘"
echo ""
echo "📁 저장 위치: $PICTURES_DIR"
echo ""
