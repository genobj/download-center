#!/bin/bash
#
# 01_install_cursor.sh
# Cursor AI 에디터 설치
#
# 사용법: ./01_install_cursor.sh
# 필요한 설정: SUDO_PASSWORD (config.local.env)
#

set -e

# sudo 공통 라이브러리 로드
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../../lib/sudo.sh"

# sudo 캐시 확인 (Tauri 앱 환경에서 필수)
if ! ensure_sudo_cache; then
    echo -e "${RED}❌ Sudo cache expired or not found${NC}"
    echo "Please verify your password in the password screen first."
    exit 1
fi

echo "=========================================="
echo "  Cursor AI 에디터 설치"
echo "=========================================="

ARCH=$(dpkg --print-architecture)

if [ "$ARCH" != "amd64" ]; then
    echo "❌ 지원되지 않는 아키텍처: $ARCH"
    echo "   Cursor AI는 현재 amd64만 지원합니다."
    exit 1
fi

# Cursor AI 다운로드 URL
# 참고: https://cursor.sh/ 에서 최신 다운로드 URL 확인
# 일반적으로 .deb 파일 또는 AppImage로 제공됨
CURSOR_VERSION="latest"
DEB_FILE="cursor_${CURSOR_VERSION}_amd64.deb"

# 최신 버전 다운로드 URL (실제 URL은 공식 사이트에서 확인 필요)
# 예시: https://downloader.cursor.sh/linux/appImage/x64
# 또는: https://downloader.cursor.sh/linux/deb/x64
DOWNLOAD_URL="https://downloader.cursor.sh/linux/deb/x64"

# 이미 설치되어 있는지 확인
if command -v cursor &> /dev/null || dpkg -l | grep -q cursor; then
    echo "ℹ️  Cursor AI가 이미 설치되어 있습니다."
    if dpkg -l | grep -q cursor; then
        CURRENT_VERSION=$(dpkg -l | grep cursor | awk '{print $3}')
        echo "   현재 버전: $CURRENT_VERSION"
    fi
    read -p "재설치 하시겠습니까? (y/N): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        echo "설치를 건너뜁니다."
        exit 0
    fi
fi

echo ""
echo "[1/4] 임시 디렉토리 생성..."
TEMP_DIR=$(mktemp -d)
cd "$TEMP_DIR"

echo "[2/4] Cursor AI 다운로드 중..."
echo "   URL: $DOWNLOAD_URL"
echo "   ⚠️  실제 다운로드 URL은 공식 사이트에서 확인하세요: https://cursor.sh/"
echo ""

# wget으로 다운로드 시도
if wget -q --show-progress "$DOWNLOAD_URL" -O "$DEB_FILE" 2>/dev/null; then
    echo "   ✓ 다운로드 완료"
elif curl -L -o "$DEB_FILE" "$DOWNLOAD_URL" 2>/dev/null; then
    echo "   ✓ 다운로드 완료 (curl 사용)"
else
    echo "   ❌ 다운로드 실패"
    echo ""
    echo "   수동 다운로드 방법:"
    echo "   1. https://cursor.sh/ 접속"
    echo "   2. Linux용 .deb 파일 다운로드"
    echo "   3. 다음 명령어로 설치:"
    echo "      sudo dpkg -i cursor_*.deb"
    echo "      sudo apt-get install -f -y"
    cd /
    rm -rf "$TEMP_DIR"
    exit 1
fi

echo "[3/4] Cursor AI 설치 중..."
run_as_root dpkg -i "$DEB_FILE" || true
# 의존성 문제 해결
run_as_root apt-get install -f -y

echo "[4/4] 임시 파일 정리..."
cd /
rm -rf "$TEMP_DIR"

echo ""
echo "┌────────────────────────────────────────────────────┐"
echo "│  ✅ Cursor AI 설치 완료!                            │"
echo "│                                                    │"
echo "│  실행: cursor                                      │"
echo "│  또는: 앱 메뉴에서 'Cursor' 검색                    │"
echo "│                                                    │"
echo "│  💡 팁:                                            │"
echo "│  - Cursor는 AI 기반 코드 에디터입니다               │"
echo "│  - VS Code 기반으로 제작되었습니다                  │"
echo "│  - 첫 실행 시 로그인이 필요할 수 있습니다            │"
echo "└────────────────────────────────────────────────────┘"
echo ""

