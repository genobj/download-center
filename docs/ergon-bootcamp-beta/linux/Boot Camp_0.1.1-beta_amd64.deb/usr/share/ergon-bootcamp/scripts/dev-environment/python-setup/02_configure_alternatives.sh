#!/bin/bash
#
# 02_configure_alternatives.sh
# update-alternatives를 사용한 Python 버전 관리 설정
#
# 설명:
#   - 설치된 Python 버전을 update-alternatives에 등록
#   - python 명령어로 python3를 사용할 수 있도록 설정
#   - 기본 버전을 선택할 수 있는 인터페이스 제공
#
# 사용법: 
#   ./02_configure_alternatives.sh           # 대화형 선택
#   ./02_configure_alternatives.sh 3.12      # 특정 버전 지정
# 필요한 설정: SUDO_PASSWORD (config.local.env)
#

set -e

# sudo 공통 라이브러리 로드
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../../lib/sudo.sh"

# sudo 캐시 확인 (Tauri 앱 환경에서 필수)
if ! ensure_sudo_cache; then
    echo -e "${RED}❌ Sudo cache expired or not found${NC}"
    echo "Please verify your password in the password screen first."
    exit 1
fi

echo "=========================================="
echo "  Python update-alternatives 설정"
echo "=========================================="

# 인자로 받은 기본 버전
DEFAULT_VERSION="${1:-}"

# ============================================
# 1. 설치된 Python 버전 확인
# ============================================
echo "[1/3] 설치된 Python 버전 확인 중..."

PYTHON_VERSIONS=("3.10" "3.12" "3.13" "3.14")
INSTALLED_VERSIONS=()

for VERSION in "${PYTHON_VERSIONS[@]}"; do
    if [[ -x "/usr/bin/python${VERSION}" ]]; then
        INSTALLED_VERSIONS+=("$VERSION")
        echo "   ✓ Python ${VERSION} 발견"
    fi
done

if [[ ${#INSTALLED_VERSIONS[@]} -eq 0 ]]; then
    echo "❌ 설치된 Python 버전이 없습니다."
    echo "   먼저 ./01_install_python.sh 를 실행하세요."
    exit 1
fi

echo ""

# ============================================
# 2. update-alternatives에 등록
# ============================================
echo "[2/3] update-alternatives에 Python 등록 중..."

# 기존 python alternatives 제거 (있는 경우)
run_as_root update-alternatives --remove-all python 2>/dev/null || true

# 각 버전 등록
for VERSION in "${INSTALLED_VERSIONS[@]}"; do
    # 우선순위: 버전 번호에서 점 제거 (3.10 -> 310, 3.14 -> 314)
    PRIORITY=$(echo "$VERSION" | tr -d '.')
    
    run_as_root update-alternatives --install /usr/bin/python python "/usr/bin/python${VERSION}" "$PRIORITY"
    echo "   ✓ Python ${VERSION} 등록 (우선순위: ${PRIORITY})"
done

echo ""

# ============================================
# 3. 기본 버전 선택
# ============================================
echo "[3/3] 기본 Python 버전 설정..."

if [[ -n "$DEFAULT_VERSION" ]]; then
    # 인자로 지정된 경우
    if [[ -x "/usr/bin/python${DEFAULT_VERSION}" ]]; then
        run_as_root update-alternatives --set python "/usr/bin/python${DEFAULT_VERSION}"
        echo "   ✓ 기본 버전: Python ${DEFAULT_VERSION}"
    else
        echo "   ⚠️  Python ${DEFAULT_VERSION}이 설치되지 않았습니다."
        echo "   자동 모드로 설정됩니다."
    fi
else
    # 대화형 선택
    echo ""
    echo "┌────────────────────────────────────────┐"
    echo "│  기본 Python 버전을 선택하세요         │"
    echo "└────────────────────────────────────────┘"
    echo ""
    run_as_root update-alternatives --config python
fi

echo ""

# 결과 확인
echo "┌────────────────────────────────────────┐"
echo "│  설정 완료                              │"
echo "├────────────────────────────────────────┤"

CURRENT_PYTHON=$(python --version 2>&1)
CURRENT_PYTHON3=$(python3 --version 2>&1)

printf "│  python  → %-26s │\n" "$CURRENT_PYTHON"
printf "│  python3 → %-26s │\n" "$CURRENT_PYTHON3"

echo "└────────────────────────────────────────┘"
echo ""

# alternatives 상태 출력
echo "📋 update-alternatives 상태:"
run_as_root update-alternatives --display python 2>/dev/null | head -20
echo ""

echo "✅ Python update-alternatives 설정 완료!"
echo ""
echo "💡 버전 변경 방법:"
echo "   run_as_root update-alternatives --config python"
echo ""
echo "다음 단계: ./03_install_pip.sh"
echo ""


