#!/bin/bash
#
# 03_configure_disk_size.sh
# Docker Desktop 디스크 이미지 크기 500GB로 설정
#
# 사용법: ./03_configure_disk_size.sh
# 참조: Docker Desktop Settings > Resources > Disk image size
#
# 참고: 설정 파일이 없으면 자동으로 생성합니다.
#

set -e

echo "=========================================="
echo "  Docker Desktop 디스크 용량 설정 (500GB)"
echo "=========================================="

# Docker Desktop 설정 파일 경로
DOCKER_DESKTOP_SETTINGS="$HOME/.docker/desktop/settings.json"
DOCKER_DIR="$HOME/.docker/desktop"

# 500GB
DISK_SIZE_GB=500

echo ""
echo "[1/2] Docker Desktop 설정 파일 확인..."

# 디렉토리가 없으면 생성
if [ ! -d "$DOCKER_DIR" ]; then
    echo "   → 디렉토리 생성: $DOCKER_DIR"
    mkdir -p "$DOCKER_DIR"
fi

# 설정 파일이 없으면 기본 파일 생성
if [ ! -f "$DOCKER_DESKTOP_SETTINGS" ]; then
    echo "   → 설정 파일 생성: $DOCKER_DESKTOP_SETTINGS"
    echo "{}" > "$DOCKER_DESKTOP_SETTINGS"
else
    echo "   ✓ 기존 설정 파일 발견: $DOCKER_DESKTOP_SETTINGS"
fi

# jq가 있으면 사용, 없으면 설치
if ! command -v jq &> /dev/null; then
    echo "   → jq 설치 중..."
    sudo apt-get install -y jq
fi

# 기존 설정에 diskSizeGiB 추가/수정
echo "[2/2] 디스크 크기 설정 업데이트..."
jq --argjson size "$DISK_SIZE_GB" '.diskSizeGiB = $size' "$DOCKER_DESKTOP_SETTINGS" > "${DOCKER_DESKTOP_SETTINGS}.tmp"
mv "${DOCKER_DESKTOP_SETTINGS}.tmp" "$DOCKER_DESKTOP_SETTINGS"

echo ""
echo "✅ 디스크 용량 설정 완료!"
echo ""
echo "   설정 파일: $DOCKER_DESKTOP_SETTINGS"
echo "   디스크 용량: ${DISK_SIZE_GB}GB"
echo ""
echo "┌────────────────────────────────────────────────────────┐"
echo "│  ⚠️  중요: 설정 적용을 위해 Docker Desktop 재시작 필요 │"
echo "│                                                        │"
echo "│  재시작 명령어:                                        │"
echo "│    systemctl --user restart docker-desktop             │"
echo "│                                                        │"
echo "│  GUI에서 확인:                                         │"
echo "│  Docker Desktop > Settings > Resources                 │"
echo "│  > Disk image size: 500GB                              │"
echo "└────────────────────────────────────────────────────────┘"
echo ""

