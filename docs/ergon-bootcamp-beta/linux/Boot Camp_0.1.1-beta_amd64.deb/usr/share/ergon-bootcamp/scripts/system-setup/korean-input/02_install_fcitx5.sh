#!/bin/bash
#
# 02_install_fcitx5.sh
# fcitx5 입력기 및 한글 모듈 설치
#
# 사용법: ./02_install_fcitx5.sh
# 필요한 설정: SUDO_PASSWORD (config.local.env)
#

set -e

# sudo 공통 라이브러리 로드
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../../lib/sudo.sh"

# sudo 캐시 확인 (Tauri 앱 환경에서 필수)
if ! ensure_sudo_cache; then
    echo -e "${RED}❌ Sudo cache expired or not found${NC}"
    echo "Please verify your password in the password screen first."
    exit 1
fi

echo "=========================================="
echo "  fcitx5 입력기 설치"
echo "=========================================="

# 패키지 목록 업데이트
echo "[1/2] 패키지 목록 업데이트 중..."
run_as_root apt update

# fcitx5 및 한글 모듈 설치
echo "[2/2] fcitx5 및 한글 모듈 설치 중..."
run_as_root apt install -y fcitx5 fcitx5-hangul fcitx5-config-qt fcitx5-frontend-all

echo ""
echo "✅ fcitx5 설치 완료!"
echo ""

