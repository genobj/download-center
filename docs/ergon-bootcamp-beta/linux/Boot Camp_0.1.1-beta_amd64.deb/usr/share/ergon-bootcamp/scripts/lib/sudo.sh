#!/bin/bash
#
# sudo.sh
# sudo 인증 캐시 관리 공통 라이브러리
#
# 사용법 (다른 스크립트에서):
#   source "$(dirname "$0")/../lib/sudo.sh"
#   # 이후 일반 sudo 명령 사용
#   sudo apt-get install -y git
#
# 설명:
#   - sudo -v로 1회 인증 (대화형 비밀번호 입력)
#   - keepalive로 캐시 유지 (1분마다 sudo -v 실행)
#   - 스크립트 종료 시 keepalive 정리
#   - 비밀번호 저장/전달 없음 (보안 강화)

set -e

# 색상 정의
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# sudo 캐시 확인 및 갱신
ensure_sudo_cache() {
    # root로 실행 중이면 즉시 통과 (Tauri 앱에서 sudo -S bash로 실행된 경우)
    if [ "$EUID" -eq 0 ]; then
        return 0
    fi
    
    # sudo -n -v로 캐시 확인 (비대화형 모드)
    # -n: non-interactive, 캐시가 없으면 에러 반환 (대화형 프롬프트 없음)
    # Tauri 앱에서 실행될 때는 터미널이 없으므로 비대화형 모드 사용
    if sudo -n -v 2>/dev/null; then
        # 캐시가 유효하면 통과 (만료 시간 리셋)
        return 0
    fi
    
    # 캐시가 만료되었거나 없음
    # TTY가 있으면 대화형으로 비밀번호 입력, 없으면 조용히 실패
    if [ -t 0 ] && [ -t 1 ]; then
        # 터미널이 있는 경우 (CLI에서 직접 실행)
        echo ""
        echo -e "${YELLOW}🔐 관리자 권한이 필요합니다${NC}"
        echo "   일부 설치 작업에 sudo 비밀번호가 필요합니다."
        echo ""
        sudo -v  # 대화형 비밀번호 입력 (이 시점부터 15분 시작)
        echo -e "${GREEN}   ✅ 비밀번호 확인됨${NC}"
    else
        # TTY가 없는 경우 (Tauri 앱)
        # PasswordScreen에서 이미 캐시를 생성했어야 함
        # 조용히 실패 반환 - 프론트엔드에서 PasswordScreen으로 리다이렉트
        return 1
    fi
}

# root 권한으로 명령 실행 (root이면 sudo 없이, 일반 사용자면 sudo 사용)
run_as_root() {
    local cmd="$1"
    shift

    if ! command -v "$cmd" >/dev/null 2>&1; then
        echo "❌ Command not found: $cmd"
        return 127
    fi

    if [ "$EUID" -eq 0 ]; then
        "$cmd" "$@"
    else
        sudo "$cmd" "$@"
    fi
}

# keepalive 시작
start_sudo_keepalive() {
    # 이미 실행 중이면 스킵 (같은 스크립트 내에서 중복 방지)
    if [ -n "$SUDO_KEEPALIVE_PID" ] && kill -0 "$SUDO_KEEPALIVE_PID" 2>/dev/null; then
        return
    fi
    
    # 백그라운드에서 keepalive 실행
    (
        while true; do
            sleep 60  # 1분마다
            # sudo -n -v로 비대화형 모드로 캐시 갱신 시도
            # 캐시가 유효하면 갱신, 만료되었으면 조용히 종료
            # -n 옵션으로 대화형 프롬프트 방지
            sudo -n -v 2>/dev/null || break
        done
    ) &
    
    SUDO_KEEPALIVE_PID=$!
    export SUDO_KEEPALIVE_PID
}

# keepalive 정리
cleanup_sudo_keepalive() {
    if [ -n "$SUDO_KEEPALIVE_PID" ]; then
        kill "$SUDO_KEEPALIVE_PID" 2>/dev/null || true
        unset SUDO_KEEPALIVE_PID
    fi
}

# 스크립트 시작 시 sudo 캐시 확보
# TTY가 있으면 대화형으로 비밀번호 입력, 없으면 캐시가 이미 생성되어 있어야 함
ensure_sudo_cache || true

# keepalive 시작 (스크립트 실행 중 캐시 유지)
# 캐시가 유효한 경우에만 keepalive 시작
if sudo -n -v 2>/dev/null; then
    start_sudo_keepalive
    # 스크립트 종료 시 keepalive 정리
    trap cleanup_sudo_keepalive EXIT
fi
