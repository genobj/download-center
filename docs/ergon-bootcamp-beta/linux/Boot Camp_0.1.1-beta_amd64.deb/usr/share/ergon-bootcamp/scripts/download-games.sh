#!/bin/bash
# Download games from Cloudsmith for development/bundling
# Usage: ./scripts/download-games.sh

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
BUNDLED_GAMES_DIR="$PROJECT_ROOT/apps/ergon-bootcamp-tauri/bundled-games"

MANIFEST_URL="https://dl.cloudsmith.io/public/genobj/games/raw/versions/latest/manifest-latest.json"

echo "📥 Downloading games from Cloudsmith..."
echo ""

# Create bundled-games directory if it doesn't exist
mkdir -p "$BUNDLED_GAMES_DIR"
cd "$BUNDLED_GAMES_DIR"

# Download manifest
echo "📋 Fetching manifest..."
MANIFEST=$(curl -sL "$MANIFEST_URL")

if [ -z "$MANIFEST" ] || echo "$MANIFEST" | grep -q "Not Found"; then
    echo "❌ Failed to download manifest from Cloudsmith"
    exit 1
fi

# Extract base_url
BASE_URL=$(echo "$MANIFEST" | jq -r '.base_url')
echo "   Base URL: $BASE_URL"
echo ""

# Get games count
TOTAL_GAMES=$(echo "$MANIFEST" | jq '.games | length')
echo "🎮 Found $TOTAL_GAMES game(s)"
echo ""

# Download each bundled game
echo "$MANIFEST" | jq -c '.games[] | select(.bundled == true)' | while read -r game; do
    GAME_ID=$(echo "$game" | jq -r '.id')
    GAME_FILE=$(echo "$game" | jq -r '.file')
    GAME_SIZE=$(echo "$game" | jq -r '.size')
    GAME_CHECKSUM=$(echo "$game" | jq -r '.checksum')
    
    echo "📦 Downloading: $GAME_ID"
    echo "   File: $GAME_FILE ($GAME_SIZE bytes)"
    
    # Download game ZIP
    DOWNLOAD_URL="https://dl.cloudsmith.io/public/genobj/games/raw/versions/latest/$GAME_FILE"
    curl -sL "$DOWNLOAD_URL" -o "$GAME_FILE"
    
    # Verify checksum if available
    if [ "$GAME_CHECKSUM" != "null" ]; then
        EXPECTED_HASH=$(echo "$GAME_CHECKSUM" | sed 's/sha256://')
        ACTUAL_HASH=$(sha256sum "$GAME_FILE" | cut -d' ' -f1)
        
        if [ "$EXPECTED_HASH" = "$ACTUAL_HASH" ]; then
            echo "   ✅ Checksum verified"
        else
            echo "   ⚠️ Checksum mismatch! Expected: $EXPECTED_HASH, Got: $ACTUAL_HASH"
        fi
    fi
    
    # Extract to game folder
    echo "   📂 Extracting to $GAME_ID/"
    rm -rf "$GAME_ID"
    unzip -q -o "$GAME_FILE" -d "$GAME_ID"
    
    # Clean up ZIP
    rm "$GAME_FILE"
    
    echo "   ✅ Done"
    echo ""
done

echo "🎉 All games downloaded successfully!"
echo ""
echo "📁 Games directory: $BUNDLED_GAMES_DIR"
ls -la "$BUNDLED_GAMES_DIR"

