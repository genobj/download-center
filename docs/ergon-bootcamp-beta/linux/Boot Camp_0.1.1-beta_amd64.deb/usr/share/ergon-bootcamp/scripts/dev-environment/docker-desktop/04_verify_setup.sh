#!/bin/bash
#
# 04_verify_setup.sh
# Docker Desktop 설치 확인
#
# 사용법: ./04_verify_setup.sh
#

echo "=========================================="
echo "  Docker Desktop 설치 확인"
echo "=========================================="

PASS_COUNT=0
FAIL_COUNT=0

# 1. Docker Desktop 패키지 확인
echo ""
echo "[1/5] Docker Desktop 패키지 확인..."
if dpkg -l | grep -q docker-desktop; then
    VERSION=$(dpkg -l | grep docker-desktop | awk '{print $3}')
    echo "   ✅ docker-desktop 설치됨: $VERSION"
    PASS_COUNT=$((PASS_COUNT + 1))
else
    echo "   ❌ docker-desktop 패키지가 설치되지 않음"
    FAIL_COUNT=$((FAIL_COUNT + 1))
fi

# 2. docker 명령어 확인
echo ""
echo "[2/5] docker 명령어 확인..."
if command -v docker &> /dev/null; then
    DOCKER_VERSION=$(docker --version 2>/dev/null || echo "확인 불가")
    echo "   ✅ docker 명령어 사용 가능: $DOCKER_VERSION"
    PASS_COUNT=$((PASS_COUNT + 1))
else
    echo "   ❌ docker 명령어를 찾을 수 없음"
    FAIL_COUNT=$((FAIL_COUNT + 1))
fi

# 3. docker compose 확인
echo ""
echo "[3/5] docker compose 확인..."
if docker compose version &> /dev/null; then
    COMPOSE_VERSION=$(docker compose version 2>/dev/null)
    echo "   ✅ $COMPOSE_VERSION"
    PASS_COUNT=$((PASS_COUNT + 1))
else
    echo "   ⚠️  docker compose를 확인할 수 없음 (Docker Desktop 실행 후 확인)"
    PASS_COUNT=$((PASS_COUNT + 1))  # 치명적이지 않음
fi

# 4. Docker Desktop 서비스 상태 확인
echo ""
echo "[4/5] Docker Desktop 서비스 확인..."
if systemctl --user is-active docker-desktop &> /dev/null; then
    echo "   ✅ Docker Desktop 서비스 실행 중"
    PASS_COUNT=$((PASS_COUNT + 1))
else
    echo "   ⚠️  Docker Desktop이 실행되지 않음"
    echo "      → 앱 메뉴에서 Docker Desktop을 실행하거나:"
    echo "      → systemctl --user start docker-desktop"
    PASS_COUNT=$((PASS_COUNT + 1))  # 설치만 확인하므로 통과
fi

# 5. 디스크 설정 확인
echo ""
echo "[5/5] 디스크 용량 설정 확인..."
SETTINGS_FILE="$HOME/.docker/desktop/settings.json"
if [ -f "$SETTINGS_FILE" ]; then
    if command -v jq &> /dev/null; then
        DISK_SIZE=$(jq -r '.diskSizeGiB // "미설정"' "$SETTINGS_FILE" 2>/dev/null)
        echo "   ✅ 디스크 용량 설정: ${DISK_SIZE}GB"
    else
        echo "   ✅ 설정 파일 존재: $SETTINGS_FILE"
    fi
    PASS_COUNT=$((PASS_COUNT + 1))
else
    echo "   ⚠️  설정 파일을 찾을 수 없음"
    echo "      → Docker Desktop 첫 실행 후 생성됩니다"
    PASS_COUNT=$((PASS_COUNT + 1))  # 치명적이지 않음
fi

echo ""
echo "=========================================="
echo "  검증 결과"
echo "=========================================="
echo ""
echo "  ✅ 통과: $PASS_COUNT"
echo "  ❌ 실패: $FAIL_COUNT"
echo ""

if [ $FAIL_COUNT -eq 0 ]; then
    echo "🎉 Docker Desktop 설치가 완료되었습니다!"
    echo ""
    echo "┌────────────────────────────────────────────────────────┐"
    echo "│  📌 Docker Desktop 사용법                              │"
    echo "│                                                        │"
    echo "│  시작:                                                 │"
    echo "│    systemctl --user start docker-desktop               │"
    echo "│    또는 앱 메뉴에서 'Docker Desktop' 클릭              │"
    echo "│                                                        │"
    echo "│  자동 시작 설정:                                       │"
    echo "│    systemctl --user enable docker-desktop              │"
    echo "│                                                        │"
    echo "│  중지:                                                 │"
    echo "│    systemctl --user stop docker-desktop                │"
    echo "│                                                        │"
    echo "│  디스크 용량 확인:                                     │"
    echo "│    Settings > Resources > Disk image size              │"
    echo "└────────────────────────────────────────────────────────┘"
    exit 0
else
    echo "⚠️  일부 검증이 실패했습니다."
    exit 1
fi

