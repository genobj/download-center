#!/bin/bash
#
# 02_verify_setup.sh
# Rust 설치 검증 스크립트
#
# 설명:
#   - rustc, cargo, rustup 설치 확인
#   - 컴포넌트 확인
#   - 간단한 프로젝트 빌드 테스트
#
# 사용법: ./02_verify_setup.sh
#

echo "=========================================="
echo "  Rust 설치 검증"
echo "=========================================="
echo ""

PASS_COUNT=0
FAIL_COUNT=0
WARN_COUNT=0

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

pass() {
    echo -e "${GREEN}✓ PASS${NC}: $1"
    PASS_COUNT=$((PASS_COUNT + 1))
}

fail() {
    echo -e "${RED}✗ FAIL${NC}: $1"
    FAIL_COUNT=$((FAIL_COUNT + 1))
}

warn() {
    echo -e "${YELLOW}⚠ WARN${NC}: $1"
    WARN_COUNT=$((WARN_COUNT + 1))
}

# PATH 로드
if [[ -f "$HOME/.cargo/env" ]]; then
    source "$HOME/.cargo/env"
fi

# ============================================
# 1. 기본 명령어 확인
# ============================================
echo "┌────────────────────────────────────────┐"
echo "│  1. 기본 명령어 확인                   │"
echo "└────────────────────────────────────────┘"

if command -v rustc &> /dev/null; then
    VERSION=$(rustc --version)
    pass "rustc 설치됨 ($VERSION)"
else
    fail "rustc 미설치"
fi

if command -v cargo &> /dev/null; then
    VERSION=$(cargo --version)
    pass "cargo 설치됨 ($VERSION)"
else
    fail "cargo 미설치"
fi

if command -v rustup &> /dev/null; then
    VERSION=$(rustup --version 2>&1 | head -1)
    pass "rustup 설치됨 ($VERSION)"
else
    fail "rustup 미설치"
fi

echo ""

# ============================================
# 2. 컴포넌트 확인
# ============================================
echo "┌────────────────────────────────────────┐"
echo "│  2. 컴포넌트 확인                      │"
echo "└────────────────────────────────────────┘"

if command -v rustfmt &> /dev/null || cargo fmt --version &>/dev/null; then
    pass "rustfmt 설치됨"
else
    warn "rustfmt 미설치 (rustup component add rustfmt)"
fi

if command -v cargo-clippy &> /dev/null || cargo clippy --version &>/dev/null; then
    pass "clippy 설치됨"
else
    warn "clippy 미설치 (rustup component add clippy)"
fi

echo ""

# ============================================
# 3. 프로젝트 빌드 테스트
# ============================================
echo "┌────────────────────────────────────────┐"
echo "│  3. 프로젝트 빌드 테스트               │"
echo "└────────────────────────────────────────┘"

if command -v cargo &> /dev/null; then
    TEMP_DIR=$(mktemp -d)
    cd "$TEMP_DIR"
    
    # 새 프로젝트 생성
    if cargo new test_project --quiet 2>/dev/null; then
        pass "cargo new 작동"
        cd test_project
        
        # 빌드 테스트
        if cargo build --quiet 2>/dev/null; then
            pass "cargo build 작동"
            
            # 실행 테스트
            OUTPUT=$(cargo run --quiet 2>/dev/null)
            if [[ "$OUTPUT" == "Hello, world!" ]]; then
                pass "cargo run 작동 (Hello, world!)"
            else
                warn "cargo run 출력 확인 필요"
            fi
        else
            fail "cargo build 실패"
        fi
        
        cd ..
    else
        fail "cargo new 실패"
    fi
    
    # 정리
    rm -rf "$TEMP_DIR"
else
    warn "cargo 없어서 빌드 테스트 스킵"
fi

echo ""

# ============================================
# 4. 환경 변수 확인
# ============================================
echo "┌────────────────────────────────────────┐"
echo "│  4. 환경 변수 확인                     │"
echo "└────────────────────────────────────────┘"

if [[ -d "$HOME/.cargo" ]]; then
    pass "CARGO_HOME 존재 ($HOME/.cargo)"
else
    fail "CARGO_HOME 미존재"
fi

if [[ -d "$HOME/.rustup" ]]; then
    pass "RUSTUP_HOME 존재 ($HOME/.rustup)"
else
    fail "RUSTUP_HOME 미존재"
fi

if echo "$PATH" | grep -q ".cargo/bin"; then
    pass "PATH에 .cargo/bin 포함됨"
else
    warn "PATH에 .cargo/bin 미포함 (source ~/.cargo/env 필요)"
fi

echo ""

# ============================================
# 결과 요약
# ============================================
echo "=========================================="
echo "  검증 결과 요약"
echo "=========================================="
echo ""
echo -e "  ${GREEN}✓ PASS${NC}: ${PASS_COUNT}"
echo -e "  ${YELLOW}⚠ WARN${NC}: ${WARN_COUNT}"
echo -e "  ${RED}✗ FAIL${NC}: ${FAIL_COUNT}"
echo ""

if [[ $FAIL_COUNT -eq 0 ]]; then
    if [[ $WARN_COUNT -eq 0 ]]; then
        echo -e "${GREEN}🎉 모든 테스트 통과!${NC}"
    else
        echo -e "${YELLOW}⚠️  일부 경고가 있지만 기본 기능은 정상입니다.${NC}"
    fi
    EXIT_CODE=0
else
    echo -e "${RED}❌ 일부 테스트 실패. 위의 FAIL 항목을 확인하세요.${NC}"
    EXIT_CODE=1
fi

echo ""
echo "=========================================="
echo ""

exit $EXIT_CODE


