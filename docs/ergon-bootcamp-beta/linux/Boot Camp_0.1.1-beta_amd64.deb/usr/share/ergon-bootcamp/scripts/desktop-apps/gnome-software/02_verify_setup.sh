#!/bin/bash
#
# 02_verify_setup.sh
# GNOME Software 설치 검증
#
# 사용법: ./02_verify_setup.sh
#

echo "=========================================="
echo "  GNOME Software 설치 검증"
echo "=========================================="
echo ""

PASS_COUNT=0
FAIL_COUNT=0
WARN_COUNT=0

pass() {
    echo "   ✅ $1"
    PASS_COUNT=$((PASS_COUNT + 1))
}

fail() {
    echo "   ❌ $1"
    FAIL_COUNT=$((FAIL_COUNT + 1))
}

warn() {
    echo "   ⚠️  $1"
    WARN_COUNT=$((WARN_COUNT + 1))
}

# ============================================
# 1. 패키지 설치 확인
# ============================================
echo "[1/2] 패키지 설치 확인..."

if dpkg -l gnome-software 2>/dev/null | grep -q "^ii"; then
    VERSION=$(dpkg -l gnome-software | grep "^ii" | awk '{print $3}')
    pass "gnome-software $VERSION"
else
    fail "gnome-software 미설치"
fi

if dpkg -l gnome-software-plugin-flatpak 2>/dev/null | grep -q "^ii"; then
    pass "gnome-software-plugin-flatpak"
else
    fail "gnome-software-plugin-flatpak 미설치"
fi
echo ""

# ============================================
# 2. Flatpak 연동 확인
# ============================================
echo "[2/2] Flatpak 연동 확인..."

if command -v flatpak &> /dev/null; then
    pass "Flatpak 설치됨"
    
    if flatpak remotes | grep -q flathub; then
        pass "Flathub 저장소 연결됨"
    else
        warn "Flathub 미등록 - system-setup/flatpak-setup 실행 필요"
    fi
else
    warn "Flatpak 미설치 - Flatpak 앱을 관리하려면 설치 필요"
fi
echo ""

# ============================================
# 결과 요약
# ============================================
echo "=========================================="
echo "  검증 결과"
echo "=========================================="
echo ""
echo "   ✅ PASS: $PASS_COUNT"
echo "   ❌ FAIL: $FAIL_COUNT"
echo "   ⚠️  WARN: $WARN_COUNT"
echo ""

if [[ $FAIL_COUNT -eq 0 ]]; then
    echo "┌────────────────────────────────────────────────────┐"
    echo "│  🎉 GNOME Software 설치 완료!                      │"
    echo "├────────────────────────────────────────────────────┤"
    echo "│                                                    │"
    echo "│  실행 방법:                                        │"
    echo "│    1. 터미널: gnome-software                       │"
    echo "│    2. 앱 메뉴에서 '소프트웨어' 검색                │"
    echo "│       (파란색 가방 아이콘 선택)                    │"
    echo "│                                                    │"
    echo "│  기능:                                             │"
    echo "│    - Flatpak/DEB 앱 검색 및 설치                   │"
    echo "│    - 설치된 앱 업데이트                            │"
    echo "│    - 저장소 관리                                   │"
    echo "│                                                    │"
    echo "└────────────────────────────────────────────────────┘"
else
    echo "┌────────────────────────────────────────┐"
    echo "│  ⚠️  일부 설정이 필요합니다            │"
    echo "└────────────────────────────────────────┘"
fi
echo ""

