#!/bin/bash
#
# 05_verify_setup.sh
# Rust & Tauri 개발 환경 종합 검증
#
# 설명:
#   - Rust 툴체인 확인
#   - Tauri 의존성 확인
#   - inotify 설정 확인
#
# 사용법: ./05_verify_setup.sh
#

echo "=========================================="
echo "  Rust & Tauri 개발 환경 검증"
echo "=========================================="
echo ""

PASS_COUNT=0
FAIL_COUNT=0
WARN_COUNT=0

pass() {
    echo "   ✅ $1"
    PASS_COUNT=$((PASS_COUNT + 1))
}

fail() {
    echo "   ❌ $1"
    FAIL_COUNT=$((FAIL_COUNT + 1))
}

warn() {
    echo "   ⚠️  $1"
    WARN_COUNT=$((WARN_COUNT + 1))
}

# ============================================
# 1. Rust 툴체인 확인
# ============================================
echo "[1/4] Rust 툴체인 확인..."

# Cargo env 로드 시도
if [[ -f "$HOME/.cargo/env" ]]; then
    source "$HOME/.cargo/env"
fi

if command -v rustc &> /dev/null; then
    pass "rustc: $(rustc --version | awk '{print $2}')"
else
    fail "rustc 미설치 - ./01_install_rust.sh 실행 필요"
fi

if command -v cargo &> /dev/null; then
    pass "cargo: $(cargo --version | awk '{print $2}')"
else
    fail "cargo 미설치"
fi

if command -v rustup &> /dev/null; then
    pass "rustup: $(rustup --version 2>&1 | head -1 | awk '{print $2}')"
else
    fail "rustup 미설치"
fi

# 컴포넌트 확인
if command -v rustfmt &> /dev/null; then
    pass "rustfmt 설치됨"
else
    warn "rustfmt 미설치 - rustup component add rustfmt"
fi

if command -v cargo-clippy &> /dev/null || rustup component list | grep -q "clippy.*installed"; then
    pass "clippy 설치됨"
else
    warn "clippy 미설치 - rustup component add clippy"
fi
echo ""

# ============================================
# 2. Tauri 의존성 확인
# ============================================
echo "[2/4] Tauri 의존성 확인..."

TAURI_PACKAGES=(
    "libwebkit2gtk-4.1-dev"
    "libayatana-appindicator3-dev"
    "librsvg2-dev"
    "patchelf"
)

for pkg in "${TAURI_PACKAGES[@]}"; do
    if dpkg -l "$pkg" 2>/dev/null | grep -q "^ii"; then
        pass "$pkg"
    else
        fail "$pkg 미설치"
    fi
done
echo ""

# ============================================
# 3. inotify 설정 확인
# ============================================
echo "[3/4] inotify 설정 확인..."

MAX_WATCHES=$(cat /proc/sys/fs/inotify/max_user_watches)
MAX_INSTANCES=$(cat /proc/sys/fs/inotify/max_user_instances)

if [[ $MAX_WATCHES -ge 524288 ]]; then
    pass "max_user_watches: $MAX_WATCHES"
else
    warn "max_user_watches: $MAX_WATCHES (권장: 524288)"
fi

if [[ $MAX_INSTANCES -ge 512 ]]; then
    pass "max_user_instances: $MAX_INSTANCES"
else
    warn "max_user_instances: $MAX_INSTANCES (권장: 512)"
fi
echo ""

# ============================================
# 4. Tauri CLI 확인 (선택사항)
# ============================================
echo "[4/4] Tauri CLI 확인 (선택사항)..."

if command -v cargo &> /dev/null; then
    if cargo install --list 2>/dev/null | grep -q "tauri-cli"; then
        TAURI_VERSION=$(cargo install --list | grep "tauri-cli" | awk '{print $2}')
        pass "tauri-cli $TAURI_VERSION"
    else
        echo "   ℹ️  tauri-cli 미설치 (필요시: cargo install tauri-cli)"
    fi
else
    echo "   ℹ️  cargo 없음 - tauri-cli 확인 불가"
fi
echo ""

# ============================================
# 결과 요약
# ============================================
echo "=========================================="
echo "  검증 결과"
echo "=========================================="
echo ""
echo "   ✅ PASS: $PASS_COUNT"
echo "   ❌ FAIL: $FAIL_COUNT"
echo "   ⚠️  WARN: $WARN_COUNT"
echo ""

if [[ $FAIL_COUNT -eq 0 ]]; then
    echo "┌────────────────────────────────────────────────────┐"
    echo "│  🎉 Rust & Tauri 개발 환경 준비 완료!              │"
    echo "├────────────────────────────────────────────────────┤"
    echo "│                                                    │"
    echo "│  Tauri 프로젝트 시작:                              │"
    echo "│    cargo install tauri-cli                         │"
    echo "│    cargo tauri init                                │"
    echo "│                                                    │"
    echo "│  또는 pnpm으로:                                    │"
    echo "│    pnpm create tauri-app                           │"
    echo "│                                                    │"
    echo "└────────────────────────────────────────────────────┘"
else
    echo "┌────────────────────────────────────────┐"
    echo "│  ⚠️  일부 설정이 필요합니다            │"
    echo "└────────────────────────────────────────┘"
    echo ""
    echo "누락된 항목을 설치하려면:"
    echo "  ./01_install_rust.sh        # Rust 툴체인"
    echo "  ./03_install_tauri_deps.sh  # Tauri 의존성"
    echo "  ./04_configure_inotify.sh   # inotify 설정"
fi
echo ""

