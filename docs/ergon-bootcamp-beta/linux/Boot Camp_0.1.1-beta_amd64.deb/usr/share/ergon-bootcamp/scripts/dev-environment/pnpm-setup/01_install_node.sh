#!/bin/bash
#
# 01_install_node.sh
# Node.js LTS 설치
#
# 설명:
#   - NodeSource 공식 리포지토리를 통해 Node.js LTS 설치
#   - npm도 함께 설치됨
#
# 사용법: ./01_install_node.sh
# 필요한 설정: SUDO_PASSWORD (config.local.env)
#

set -e

# sudo 공통 라이브러리 로드
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../../lib/sudo.sh"

# sudo 캐시 확인 (Tauri 앱 환경에서 필수)
if ! ensure_sudo_cache; then
    echo -e "${RED}❌ Sudo cache expired or not found${NC}"
    echo "Please verify your password in the password screen first."
    exit 1
fi

echo "=========================================="
echo "  Node.js LTS 설치"
echo "=========================================="
echo ""

# ============================================
# 1. 기존 설치 확인
# ============================================
echo "[1/3] 기존 Node.js 설치 확인 중..."

if command -v node &> /dev/null; then
    CURRENT_VERSION=$(node --version)
    echo "   ⚠️  Node.js가 이미 설치되어 있습니다: ${CURRENT_VERSION}"
    
    # 버전 확인 (v20 이상인지)
    MAJOR_VERSION=$(echo "$CURRENT_VERSION" | sed 's/v//' | cut -d. -f1)
    if [[ $MAJOR_VERSION -ge 20 ]]; then
        echo "   ✓ 최신 LTS 버전입니다. 건너뜁니다."
        echo ""
        echo "┌────────────────────────────────────────┐"
        echo "│  현재 Node.js 버전                     │"
        echo "├────────────────────────────────────────┤"
        printf "│  %-36s │\n" "$(node --version)"
        printf "│  %-36s │\n" "npm $(npm --version)"
        echo "└────────────────────────────────────────┘"
        exit 0
    fi
fi

echo "   → 새로 설치를 진행합니다."
echo ""

# ============================================
# 2. NodeSource 리포지토리 설정
# ============================================
echo "[2/3] NodeSource 리포지토리 설정 중..."

# 필요한 패키지 설치
run_as_root apt-get update -qq
run_as_root apt-get install -y ca-certificates curl gnupg

# NodeSource GPG 키 추가
run_as_root mkdir -p /etc/apt/keyrings
curl -fsSL https://deb.nodesource.com/gpgkey/nodesource-repo.gpg.key | run_as_root gpg --batch --yes --dearmor -o /etc/apt/keyrings/nodesource.gpg

# Node.js LTS (현재 22.x)
NODE_MAJOR=22
echo "deb [signed-by=/etc/apt/keyrings/nodesource.gpg] https://deb.nodesource.com/node_$NODE_MAJOR.x nodistro main" | run_as_root tee /etc/apt/sources.list.d/nodesource.list > /dev/null

echo "   ✓ NodeSource 리포지토리 설정 완료"
echo ""

# ============================================
# 3. Node.js 설치
# ============================================
echo "[3/3] Node.js 설치 중..."

run_as_root apt-get update -qq
run_as_root apt-get install -y nodejs

echo "   ✓ Node.js 설치 완료"
echo ""

# ============================================
# 결과 확인
# ============================================
echo "┌────────────────────────────────────────┐"
echo "│  설치 완료                              │"
echo "├────────────────────────────────────────┤"
printf "│  %-36s │\n" "$(node --version)"
printf "│  %-36s │\n" "npm $(npm --version)"
echo "└────────────────────────────────────────┘"
echo ""

echo "✅ Node.js 설치 완료!"
echo ""
echo "다음 단계: ./02_install_pnpm.sh"
echo ""


