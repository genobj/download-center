#!/bin/bash
#
# 01_create_keyrings_dir.sh
# GPG 키링 저장 디렉토리 생성
#
# 사용법: ./01_create_keyrings_dir.sh
# 필요한 설정: SUDO_PASSWORD (config.local.env)
#

set -e

# sudo 공통 라이브러리 로드
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../../lib/sudo.sh"

# sudo 캐시 확인 (Tauri 앱 환경에서 필수)
if ! ensure_sudo_cache; then
    echo -e "${RED}❌ Sudo cache expired or not found${NC}"
    echo "Please verify your password in the password screen first."
    exit 1
fi

echo "=========================================="
echo "  GPG 키링 디렉토리 생성"
echo "=========================================="

KEYRINGS_DIR="/etc/apt/keyrings"

# 이미 존재하는지 확인
if [ -d "$KEYRINGS_DIR" ]; then
    echo "⚠️  키링 디렉토리가 이미 존재합니다: $KEYRINGS_DIR"
    ls -la "$KEYRINGS_DIR"
    exit 0
fi

# 키링 디렉토리 생성
echo "[1/1] 키링 디렉토리 생성 중..."
run_as_root mkdir -p "$KEYRINGS_DIR"
run_as_root chmod 755 "$KEYRINGS_DIR"

echo ""
echo "✅ GPG 키링 디렉토리 생성 완료!"
echo "   위치: $KEYRINGS_DIR"
echo ""
echo "📝 이후 GPG 키는 이 디렉토리에 저장됩니다:"
echo "   예: /etc/apt/keyrings/google-chrome.gpg"
echo ""


