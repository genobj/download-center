#!/bin/bash
#
# 02_install_pnpm.sh
# pnpm 설치
#
# 설명:
#   - corepack을 통해 pnpm 활성화 (권장)
#   - 또는 standalone 스크립트로 설치
#
# 사용법: ./02_install_pnpm.sh
#

set -e

echo "=========================================="
echo "  pnpm 설치"
echo "=========================================="
echo ""

# ============================================
# 1. Node.js 확인
# ============================================
echo "[1/3] Node.js 확인 중..."

if ! command -v node &> /dev/null; then
    echo "❌ Node.js가 설치되어 있지 않습니다."
    echo "   먼저 ./01_install_node.sh 를 실행하세요."
    exit 1
fi

NODE_VERSION=$(node --version)
echo "   ✓ Node.js ${NODE_VERSION} 확인됨"
echo ""

# ============================================
# 2. pnpm 설치 (corepack 사용)
# ============================================
echo "[2/3] pnpm 설치 중..."

# corepack 활성화 (Node.js 16.9+에 내장)
if command -v corepack &> /dev/null; then
    echo "   → corepack을 통해 pnpm 활성화 중..."
    
    # sudo 권한으로 corepack 활성화
    if [[ $EUID -eq 0 ]]; then
        corepack enable
        corepack prepare pnpm@latest --activate
    else
        sudo corepack enable
        corepack prepare pnpm@latest --activate
    fi
    
    echo "   ✓ corepack으로 pnpm 활성화 완료"
else
    echo "   → standalone 스크립트로 pnpm 설치 중..."
    
    # standalone 설치
    curl -fsSL https://get.pnpm.io/install.sh | sh -
    
    # PATH 설정
    export PNPM_HOME="$HOME/.local/share/pnpm"
    export PATH="$PNPM_HOME:$PATH"
    
    echo "   ✓ standalone으로 pnpm 설치 완료"
fi

echo ""

# ============================================
# 3. 환경 변수 설정
# ============================================
echo "[3/3] 환경 변수 설정 중..."

PNPM_HOME="$HOME/.local/share/pnpm"
SHELL_RC=""

# 쉘 설정 파일 확인
if [[ -f "$HOME/.zshrc" ]]; then
    SHELL_RC="$HOME/.zshrc"
elif [[ -f "$HOME/.bashrc" ]]; then
    SHELL_RC="$HOME/.bashrc"
fi

if [[ -n "$SHELL_RC" ]]; then
    # 이미 설정되어 있는지 확인
    if ! grep -q "PNPM_HOME" "$SHELL_RC"; then
        echo "" >> "$SHELL_RC"
        echo "# pnpm" >> "$SHELL_RC"
        echo "export PNPM_HOME=\"$PNPM_HOME\"" >> "$SHELL_RC"
        echo 'case ":$PATH:" in' >> "$SHELL_RC"
        echo '  *":$PNPM_HOME:"*) ;;' >> "$SHELL_RC"
        echo '  *) export PATH="$PNPM_HOME:$PATH" ;;' >> "$SHELL_RC"
        echo 'esac' >> "$SHELL_RC"
        echo "   ✓ $SHELL_RC에 PNPM_HOME 추가됨"
    else
        echo "   ✓ PNPM_HOME 이미 설정됨"
    fi
fi

# 현재 세션에 적용
export PNPM_HOME="$PNPM_HOME"
export PATH="$PNPM_HOME:$PATH"

echo ""

# ============================================
# 결과 확인
# ============================================
PNPM_VERSION=$(pnpm --version 2>/dev/null || echo "확인 필요")

echo "┌────────────────────────────────────────┐"
echo "│  설치 완료                              │"
echo "├────────────────────────────────────────┤"
printf "│  %-36s │\n" "pnpm v${PNPM_VERSION}"
printf "│  %-36s │\n" "$(node --version)"
echo "└────────────────────────────────────────┘"
echo ""

echo "✅ pnpm 설치 완료!"
echo ""
echo "💡 새 터미널을 열거나 다음 명령어를 실행하세요:"
echo "   source $SHELL_RC"
echo ""
echo "다음 단계: ./03_verify_setup.sh"
echo ""


