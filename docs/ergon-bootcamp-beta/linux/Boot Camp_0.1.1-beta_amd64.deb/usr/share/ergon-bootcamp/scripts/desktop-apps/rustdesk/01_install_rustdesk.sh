#!/bin/bash
#
# 01_install_rustdesk.sh
# RustDesk 원격 데스크톱 소프트웨어 설치
#
# 사용법: ./01_install_rustdesk.sh
# 필요한 설정: SUDO_PASSWORD (config.local.env)
#

set -e

# sudo 공통 라이브러리 로드
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../../lib/sudo.sh"

# sudo 캐시 확인 (Tauri 앱 환경에서 필수)
if ! ensure_sudo_cache; then
    echo -e "${RED}❌ Sudo cache expired or not found${NC}"
    echo "Please verify your password in the password screen first."
    exit 1
fi

echo "=========================================="
echo "  RustDesk 원격 데스크톱 설치"
echo "=========================================="

# RustDesk 최신 버전 확인 및 다운로드
RUSTDESK_VERSION="1.3.6"
ARCH=$(dpkg --print-architecture)

if [ "$ARCH" = "amd64" ]; then
    DEB_FILE="rustdesk-${RUSTDESK_VERSION}-x86_64.deb"
else
    echo "❌ 지원되지 않는 아키텍처: $ARCH"
    exit 1
fi

DOWNLOAD_URL="https://github.com/rustdesk/rustdesk/releases/download/${RUSTDESK_VERSION}/${DEB_FILE}"

# 이미 설치되어 있는지 확인
if command -v rustdesk &> /dev/null; then
    CURRENT_VERSION=$(rustdesk --version 2>/dev/null | head -1 || echo "unknown")
    echo "ℹ️  RustDesk가 이미 설치되어 있습니다: $CURRENT_VERSION"
    read -p "재설치 하시겠습니까? (y/N): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        echo "설치를 건너뜁니다."
        exit 0
    fi
fi

echo ""
echo "[1/4] 임시 디렉토리 생성..."
TEMP_DIR=$(mktemp -d)
cd "$TEMP_DIR"

echo "[2/4] RustDesk v${RUSTDESK_VERSION} 다운로드 중..."
echo "   URL: $DOWNLOAD_URL"
wget -q --show-progress "$DOWNLOAD_URL" -O "$DEB_FILE"

echo "[3/4] RustDesk 설치 중..."
run_as_root dpkg -i "$DEB_FILE" || true
# 의존성 문제 해결
run_as_root apt-get install -f -y

echo "[4/4] 임시 파일 정리..."
cd /
rm -rf "$TEMP_DIR"

echo ""
echo "┌────────────────────────────────────────────────────┐"
echo "│  ✅ RustDesk 설치 완료!                            │"
echo "│                                                    │"
echo "│  실행: rustdesk                                    │"
echo "│  또는: 앱 메뉴에서 'RustDesk' 검색                 │"
echo "│                                                    │"
echo "│  💡 팁:                                            │"
echo "│  - RustDesk ID와 비밀번호로 원격 접속 가능         │"
echo "│  - 자체 서버 구축 시 더 빠른 연결 가능             │"
echo "└────────────────────────────────────────────────────┘"
echo ""

