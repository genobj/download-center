#!/bin/bash
#
# 01_add_repository.sh
# Microsoft Edge 공식 저장소 추가
#
# 사용법: ./01_add_repository.sh
# 필요한 설정: SUDO_PASSWORD (config.local.env)
#

set -e

# sudo 공통 라이브러리 로드
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../../lib/sudo.sh"

# sudo 캐시 확인 (Tauri 앱 환경에서 필수)
if ! ensure_sudo_cache; then
    echo -e "${RED}❌ Sudo cache expired or not found${NC}"
    echo "Please verify your password in the password screen first."
    exit 1
fi

echo "=========================================="
echo "  Microsoft Edge 저장소 추가"
echo "=========================================="

# 이미 저장소가 있는지 확인
if [ -f /etc/apt/sources.list.d/microsoft-edge.list ]; then
    echo "⚠️  Microsoft Edge 저장소가 이미 존재합니다."
    exit 0
fi

# 필요한 패키지 설치
echo "[1/3] 필수 패키지 설치 중..."
run_as_root apt update
run_as_root apt install -y wget gnupg

# Microsoft 공식 GPG 키 추가
echo "[2/3] Microsoft 공식 GPG 키 추가 중..."
wget -q -O /tmp/microsoft.asc https://packages.microsoft.com/keys/microsoft.asc
gpg --batch --yes --dearmor -o /tmp/microsoft-edge.gpg /tmp/microsoft.asc
run_as_root mv /tmp/microsoft-edge.gpg /etc/apt/keyrings/microsoft-edge.gpg
run_as_root chmod 644 /etc/apt/keyrings/microsoft-edge.gpg
rm -f /tmp/microsoft.asc

# 저장소 추가
echo "[3/3] Microsoft Edge 저장소 추가 중..."
echo "deb [arch=amd64 signed-by=/etc/apt/keyrings/microsoft-edge.gpg] https://packages.microsoft.com/repos/edge stable main" | run_as_root tee /etc/apt/sources.list.d/microsoft-edge.list > /dev/null

echo ""
echo "✅ Microsoft Edge 저장소 추가 완료!"
echo ""

