#!/bin/bash
#
# 01_setup_repository.sh
# Docker 공식 APT 저장소 설정
#
# 사용법: ./01_setup_repository.sh
# 필요한 설정: SUDO_PASSWORD (config.local.env)
# 참조: https://docs.docker.com/engine/install/ubuntu/
#

set -e

# sudo 공통 라이브러리 로드
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../../lib/sudo.sh"

# sudo 캐시 확인 (Tauri 앱 환경에서 필수)
if ! ensure_sudo_cache; then
    echo -e "${RED}❌ Sudo cache expired or not found${NC}"
    echo "Please verify your password in the password screen first."
    exit 1
fi

echo "=========================================="
echo "  Docker APT 저장소 설정"
echo "=========================================="

# 이전 Docker 패키지 제거 (충돌 방지)
echo ""
echo "[1/4] 이전 Docker 패키지 확인 및 제거..."
for pkg in docker.io docker-doc docker-compose docker-compose-v2 podman-docker containerd runc; do
    if dpkg -l | grep -q "^ii  $pkg"; then
        echo "   → $pkg 제거 중..."
        sudo apt-get remove -y $pkg || true
    fi
done
echo "   ✓ 완료"

# 필수 패키지 설치
echo ""
echo "[2/4] 필수 패키지 설치..."
run_as_root apt-get update
run_as_root apt-get install -y ca-certificates curl

# Docker GPG 키 추가
echo ""
echo "[3/4] Docker 공식 GPG 키 추가..."
run_as_root install -m 0755 -d /etc/apt/keyrings

# GPG 키 다운로드 및 저장
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --batch --yes --dearmor -o /etc/apt/keyrings/docker.gpg
run_as_root chmod a+r /etc/apt/keyrings/docker.gpg
echo "   ✓ GPG 키 저장됨: /etc/apt/keyrings/docker.gpg"

# APT 저장소 추가
echo ""
echo "[4/4] Docker APT 저장소 추가..."
echo \
  "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu \
  $(. /etc/os-release && echo "${UBUNTU_CODENAME:-$VERSION_CODENAME}") stable" | \
  sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

echo "   ✓ 저장소 추가됨: /etc/apt/sources.list.d/docker.list"

# 패키지 목록 업데이트
echo ""
echo "패키지 목록 업데이트 중..."
run_as_root apt-get update

echo ""
echo "✅ Docker APT 저장소 설정 완료!"
echo ""

