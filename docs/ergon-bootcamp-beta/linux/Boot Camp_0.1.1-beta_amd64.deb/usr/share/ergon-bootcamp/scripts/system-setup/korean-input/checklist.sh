#!/bin/bash
#
# checklist.sh
# 체크리스트 상태 확인 및 업데이트
#
# 사용법:
#   ./checklist.sh              # 체크리스트 보기
#   ./checklist.sh status       # 체크리스트 보기
#   ./checklist.sh complete 01  # 01번 스텝 완료 표시
#   ./checklist.sh skip 03      # 03번 스텝 스킵 표시
#   ./checklist.sh reset        # 체크리스트 초기화
#

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CHECKLIST_FILE="$SCRIPT_DIR/checklist.json"

# 색상 정의
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# jq 설치 확인
check_jq() {
    if ! command -v jq &> /dev/null; then
        echo -e "${RED}오류: jq가 설치되어 있지 않습니다.${NC}"
        echo "설치: sudo apt install jq"
        exit 1
    fi
}

# 체크리스트 상태 표시
show_status() {
    check_jq
    
    echo ""
    echo "=========================================="
    echo "  한국어 입력 환경 설정 체크리스트"
    echo "=========================================="
    echo ""
    
    # 각 스텝 표시
    local steps=$(jq -r '.steps[] | "\(.order)|\(.id)|\(.name)|\(.status)"' "$CHECKLIST_FILE")
    
    while IFS='|' read -r order id name status; do
        case $status in
            "completed")
                icon="${GREEN}✅${NC}"
                ;;
            "pending")
                icon="⬜"
                ;;
            "skipped")
                icon="${YELLOW}⏭️${NC}"
                ;;
            "failed")
                icon="${RED}❌${NC}"
                ;;
            *)
                icon="❓"
                ;;
        esac
        
        printf "  %s %02d. %s\n" "$icon" "$order" "$name"
    done <<< "$steps"
    
    echo ""
    echo "------------------------------------------"
    
    # 요약 정보
    local completed=$(jq '.summary.completed' "$CHECKLIST_FILE")
    local total=$(jq '.summary.total' "$CHECKLIST_FILE")
    local percent=$(jq '.summary.progress_percent' "$CHECKLIST_FILE")
    
    echo -e "  진행률: ${BLUE}$completed/$total${NC} ($percent%)"
    
    # 로그아웃 필요 여부
    local logout_req=$(jq '.post_completion.logout_required' "$CHECKLIST_FILE")
    local logout_done=$(jq '.post_completion.logout_done' "$CHECKLIST_FILE")
    
    if [ "$logout_req" = "true" ] && [ "$logout_done" = "false" ]; then
        echo -e "  ${YELLOW}⚠️  완료 후 로그아웃/로그인 필요${NC}"
    fi
    
    echo ""
}

# 스텝 상태 업데이트
update_step() {
    check_jq
    
    local step_num=$1
    local new_status=$2
    local timestamp=$(date -Iseconds)
    
    # 스텝 ID 찾기
    local step_id=$(printf "%02d" "$step_num")
    
    # JSON 업데이트
    local tmp_file=$(mktemp)
    
    jq --arg id "$step_id" --arg status "$new_status" --arg time "$timestamp" '
        .steps |= map(
            if (.id | startswith($id + "_")) then
                .status = $status |
                if $status == "completed" then .completed_at = $time else . end
            else .
            end
        ) |
        .updated_at = $time |
        .summary.completed = ([.steps[] | select(.status == "completed")] | length) |
        .summary.pending = ([.steps[] | select(.status == "pending")] | length) |
        .summary.skipped = ([.steps[] | select(.status == "skipped")] | length) |
        .summary.failed = ([.steps[] | select(.status == "failed")] | length) |
        .summary.progress_percent = ((.summary.completed / .summary.total) * 100 | floor) |
        if .summary.completed == .summary.total then .status = "completed"
        elif .summary.completed > 0 then .status = "in_progress"
        else .status = "not_started" end
    ' "$CHECKLIST_FILE" > "$tmp_file"
    
    mv "$tmp_file" "$CHECKLIST_FILE"
    
    echo -e "${GREEN}✅ 스텝 $step_num 상태가 '$new_status'로 업데이트되었습니다.${NC}"
}

# 체크리스트 초기화
reset_checklist() {
    check_jq
    
    local tmp_file=$(mktemp)
    
    jq '
        .steps |= map(.status = "pending" | .completed_at = null | .notes = null) |
        .updated_at = null |
        .status = "not_started" |
        .summary.completed = 0 |
        .summary.pending = .summary.total |
        .summary.skipped = 0 |
        .summary.failed = 0 |
        .summary.progress_percent = 0 |
        .post_completion.logout_done = false
    ' "$CHECKLIST_FILE" > "$tmp_file"
    
    mv "$tmp_file" "$CHECKLIST_FILE"
    
    echo -e "${GREEN}✅ 체크리스트가 초기화되었습니다.${NC}"
}

# 다음 스텝 찾기
show_next() {
    check_jq
    
    local next_step=$(jq -r '.steps[] | select(.status == "pending") | "\(.order). \(.name)"' "$CHECKLIST_FILE" | head -1)
    
    if [ -n "$next_step" ]; then
        echo -e "\n${BLUE}➡️  다음 스텝: $next_step${NC}\n"
    else
        echo -e "\n${GREEN}🎉 모든 스텝이 완료되었습니다!${NC}\n"
    fi
}

# 도움말
show_help() {
    echo ""
    echo "사용법: ./checklist.sh [명령어] [옵션]"
    echo ""
    echo "명령어:"
    echo "  status, (없음)     체크리스트 상태 보기"
    echo "  complete <번호>    스텝 완료로 표시"
    echo "  skip <번호>        스텝 스킵으로 표시"
    echo "  fail <번호>        스텝 실패로 표시"
    echo "  pending <번호>     스텝 대기로 표시"
    echo "  next               다음 스텝 보기"
    echo "  reset              체크리스트 초기화"
    echo "  help               이 도움말 보기"
    echo ""
    echo "예시:"
    echo "  ./checklist.sh                  # 체크리스트 보기"
    echo "  ./checklist.sh complete 1       # 1번 스텝 완료"
    echo "  ./checklist.sh complete 2       # 2번 스텝 완료"
    echo "  ./checklist.sh skip 3           # 3번 스텝 스킵"
    echo ""
}

# 메인
case "${1:-status}" in
    status)
        show_status
        show_next
        ;;
    complete)
        if [ -z "$2" ]; then
            echo -e "${RED}오류: 스텝 번호를 지정하세요.${NC}"
            exit 1
        fi
        update_step "$2" "completed"
        show_status
        ;;
    skip)
        if [ -z "$2" ]; then
            echo -e "${RED}오류: 스텝 번호를 지정하세요.${NC}"
            exit 1
        fi
        update_step "$2" "skipped"
        show_status
        ;;
    fail)
        if [ -z "$2" ]; then
            echo -e "${RED}오류: 스텝 번호를 지정하세요.${NC}"
            exit 1
        fi
        update_step "$2" "failed"
        show_status
        ;;
    pending)
        if [ -z "$2" ]; then
            echo -e "${RED}오류: 스텝 번호를 지정하세요.${NC}"
            exit 1
        fi
        update_step "$2" "pending"
        show_status
        ;;
    next)
        show_next
        ;;
    reset)
        reset_checklist
        show_status
        ;;
    help|--help|-h)
        show_help
        ;;
    *)
        echo -e "${RED}알 수 없는 명령어: $1${NC}"
        show_help
        exit 1
        ;;
esac



