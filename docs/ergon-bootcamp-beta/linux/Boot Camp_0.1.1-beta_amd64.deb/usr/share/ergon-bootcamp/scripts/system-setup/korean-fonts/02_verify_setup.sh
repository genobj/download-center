#!/bin/bash
#
# 02_verify_setup.sh
# 한글 폰트 설치 검증
#
# 사용법: ./02_verify_setup.sh
#

echo "=========================================="
echo "  한글 폰트 설치 검증"
echo "=========================================="
echo ""

PASS_COUNT=0
FAIL_COUNT=0

pass() {
    echo "   ✅ $1"
    PASS_COUNT=$((PASS_COUNT + 1))
}

fail() {
    echo "   ❌ $1"
    FAIL_COUNT=$((FAIL_COUNT + 1))
}

# ============================================
# 1. 패키지 설치 확인
# ============================================
echo "[1/2] 패키지 설치 확인..."

PACKAGES=("fonts-nanum" "fonts-noto-cjk" "fonts-noto-color-emoji")

for pkg in "${PACKAGES[@]}"; do
    if dpkg -l "$pkg" 2>/dev/null | grep -q "^ii"; then
        pass "$pkg"
    else
        fail "$pkg 미설치"
    fi
done
echo ""

# ============================================
# 2. 폰트 파일 확인
# ============================================
echo "[2/2] 폰트 파일 확인..."

if fc-list | grep -qi nanum; then
    NANUM_COUNT=$(fc-list | grep -i nanum | wc -l)
    pass "나눔 글꼴 ${NANUM_COUNT}개 발견"
else
    fail "나눔 글꼴 없음"
fi

if fc-list | grep -qi "noto.*cjk"; then
    NOTO_COUNT=$(fc-list | grep -i "noto.*cjk" | wc -l)
    pass "Noto CJK ${NOTO_COUNT}개 발견"
else
    fail "Noto CJK 없음"
fi
echo ""

# ============================================
# 결과 요약
# ============================================
echo "=========================================="
echo "  검증 결과"
echo "=========================================="
echo ""
echo "   ✅ PASS: $PASS_COUNT"
echo "   ❌ FAIL: $FAIL_COUNT"
echo ""

if [[ $FAIL_COUNT -eq 0 ]]; then
    echo "┌────────────────────────────────────────┐"
    echo "│  🎉 한글 폰트 설치 완료!               │"
    echo "└────────────────────────────────────────┘"
else
    echo "┌────────────────────────────────────────┐"
    echo "│  ⚠️  일부 폰트가 누락되었습니다        │"
    echo "└────────────────────────────────────────┘"
fi
echo ""

