#!/bin/bash
#
# 01_install_openjdk.sh
# OpenJDK 21 설치
#
# 설명:
#   - Ubuntu 공식 리포지토리에서 OpenJDK 21 설치
#   - JAVA_HOME 환경 변수 설정
#   - update-alternatives 설정
#
# 사용법: ./01_install_openjdk.sh
# 필요한 설정: SUDO_PASSWORD (config.local.env)
#

set -e

# sudo 공통 라이브러리 로드
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../../lib/sudo.sh"

# sudo 캐시 확인 (Tauri 앱 환경에서 필수)
if ! ensure_sudo_cache; then
    echo -e "${RED}❌ Sudo cache expired or not found${NC}"
    echo "Please verify your password in the password screen first."
    exit 1
fi

echo "=========================================="
echo "  OpenJDK 21 설치"
echo "=========================================="
echo ""

# ============================================
# 1. 기존 설치 확인
# ============================================
echo "[1/4] 기존 Java 설치 확인 중..."

if command -v java &> /dev/null; then
    CURRENT_VERSION=$(java --version 2>&1 | head -1)
    echo "   ⚠️  Java가 이미 설치되어 있습니다: ${CURRENT_VERSION}"
    
    # OpenJDK 21인지 확인
    if java --version 2>&1 | grep -q "21"; then
        echo "   ✓ OpenJDK 21이 이미 설치되어 있습니다."
        echo ""
        echo "┌────────────────────────────────────────┐"
        echo "│  현재 Java 버전                        │"
        echo "├────────────────────────────────────────┤"
        java --version 2>&1 | head -3 | while read line; do
            printf "│  %-36s │\n" "$line"
        done
        echo "└────────────────────────────────────────┘"
        
        # JAVA_HOME 설정 확인
        if [[ -z "$JAVA_HOME" ]]; then
            echo ""
            echo "   → JAVA_HOME 환경 변수 설정을 진행합니다..."
        else
            exit 0
        fi
    fi
fi

echo ""

# ============================================
# 2. OpenJDK 21 설치
# ============================================
echo "[2/4] OpenJDK 21 설치 중..."

run_as_root apt-get update -qq
run_as_root apt-get install -y openjdk-21-jdk openjdk-21-doc

echo "   ✓ OpenJDK 21 설치 완료"
echo ""

# ============================================
# 3. JAVA_HOME 환경 변수 설정
# ============================================
echo "[3/4] JAVA_HOME 환경 변수 설정 중..."

JAVA_HOME_PATH="/usr/lib/jvm/java-21-openjdk-amd64"

# /etc/environment에 JAVA_HOME 추가
if ! grep -q "JAVA_HOME" /etc/environment; then
    echo "JAVA_HOME=\"$JAVA_HOME_PATH\"" | sudo tee -a /etc/environment > /dev/null
    echo "   ✓ /etc/environment에 JAVA_HOME 추가됨"
else
    # 기존 JAVA_HOME 업데이트
    sudo sed -i "s|JAVA_HOME=.*|JAVA_HOME=\"$JAVA_HOME_PATH\"|" /etc/environment
    echo "   ✓ /etc/environment의 JAVA_HOME 업데이트됨"
fi

# 사용자 쉘 설정 파일에도 추가 (현재 사용자)
REAL_USER="${SUDO_USER:-$USER}"
REAL_HOME=$(eval echo ~$REAL_USER)

for SHELL_RC in "$REAL_HOME/.bashrc" "$REAL_HOME/.zshrc"; do
    if [[ -f "$SHELL_RC" ]]; then
        if ! grep -q "JAVA_HOME" "$SHELL_RC"; then
            echo "" >> "$SHELL_RC"
            echo "# Java" >> "$SHELL_RC"
            echo "export JAVA_HOME=\"$JAVA_HOME_PATH\"" >> "$SHELL_RC"
            echo 'export PATH="$JAVA_HOME/bin:$PATH"' >> "$SHELL_RC"
            echo "   ✓ $SHELL_RC에 JAVA_HOME 추가됨"
        fi
    fi
done

echo ""

# ============================================
# 4. update-alternatives 설정
# ============================================
echo "[4/4] update-alternatives 설정 중..."

# Java 기본 버전 설정
run_as_root update-alternatives --set java "$JAVA_HOME_PATH/bin/java" 2>/dev/null || true
run_as_root update-alternatives --set javac "$JAVA_HOME_PATH/bin/javac" 2>/dev/null || true

echo "   ✓ OpenJDK 21이 기본 Java로 설정됨"
echo ""

# ============================================
# 결과 확인
# ============================================
echo "┌────────────────────────────────────────┐"
echo "│  설치 완료                              │"
echo "├────────────────────────────────────────┤"

# 버전 정보 출력
JAVA_VERSION=$(java --version 2>&1 | head -1)
JAVAC_VERSION=$(javac --version 2>&1)

printf "│  %-36s │\n" "$JAVA_VERSION"
printf "│  %-36s │\n" "$JAVAC_VERSION"
echo "├────────────────────────────────────────┤"
printf "│  JAVA_HOME: %-24s │\n" "$JAVA_HOME_PATH"
echo "└────────────────────────────────────────┘"
echo ""

echo "✅ OpenJDK 21 설치 완료!"
echo ""
echo "💡 새 터미널을 열거나 다음 명령어를 실행하세요:"
echo "   source ~/.bashrc"
echo ""
echo "다음 단계: ./02_verify_setup.sh"
echo ""


