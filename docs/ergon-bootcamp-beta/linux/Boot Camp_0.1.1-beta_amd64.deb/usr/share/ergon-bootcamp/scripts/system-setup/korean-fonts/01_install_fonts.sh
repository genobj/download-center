#!/bin/bash
#
# 01_install_fonts.sh
# 한글 폰트 패키지 설치
#
# 설명:
#   - fonts-nanum: 네이버 나눔 글꼴
#   - fonts-noto-cjk: Google Noto CJK 글꼴
#   - fonts-noto-color-emoji: 컬러 이모지
#
# 사용법: ./01_install_fonts.sh
#

set -e

# sudo 공통 라이브러리 로드
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../../lib/sudo.sh"

# sudo 캐시 확인 (Tauri 앱 환경에서 필수)
if ! ensure_sudo_cache; then
    echo -e "${RED}❌ Sudo cache expired or not found${NC}"
    echo "Please verify your password in the password screen first."
    exit 1
fi

echo "=========================================="
echo "  한글 폰트 설치"
echo "=========================================="
echo ""

# ============================================
# 1. 패키지 목록
# ============================================
PACKAGES=(
    "fonts-nanum"           # 네이버 나눔 글꼴
    "fonts-noto-cjk"        # Google Noto CJK
    "fonts-noto-color-emoji" # 컬러 이모지
)

echo "[1/3] 설치할 폰트 패키지:"
for pkg in "${PACKAGES[@]}"; do
    if dpkg -l | grep -q "^ii  $pkg "; then
        echo "   ✓ $pkg (이미 설치됨)"
    else
        echo "   → $pkg (설치 예정)"
    fi
done
echo ""

# ============================================
# 2. 패키지 설치
# ============================================
echo "[2/3] 폰트 패키지 설치 중..."

INSTALL_LIST=()
for pkg in "${PACKAGES[@]}"; do
    if ! dpkg -l | grep -q "^ii  $pkg "; then
        INSTALL_LIST+=("$pkg")
    fi
done

if [[ ${#INSTALL_LIST[@]} -eq 0 ]]; then
    echo "   ✓ 모든 폰트가 이미 설치되어 있습니다."
else
    sudo apt-get update -qq
    sudo apt-get install -y "${INSTALL_LIST[@]}"
    echo "   ✓ 폰트 패키지 설치 완료"
fi
echo ""

# ============================================
# 3. 폰트 캐시 갱신
# ============================================
echo "[3/3] 폰트 캐시 갱신 중..."

run_as_root fc-cache -fv > /dev/null 2>&1

echo "   ✓ 폰트 캐시 갱신 완료"
echo ""

# ============================================
# 결과 확인
# ============================================
NANUM_COUNT=$(fc-list | grep -i nanum | wc -l)
NOTO_COUNT=$(fc-list | grep -i "noto.*cjk" | wc -l)

echo "┌────────────────────────────────────────┐"
echo "│  설치된 폰트                            │"
echo "├────────────────────────────────────────┤"
printf "│  나눔 글꼴: %3d개                       │\n" "$NANUM_COUNT"
printf "│  Noto CJK:  %3d개                       │\n" "$NOTO_COUNT"
echo "└────────────────────────────────────────┘"
echo ""

echo "✅ 한글 폰트 설치 완료!"
echo ""
echo "다음 단계: ./02_verify_setup.sh"
echo ""

