#!/bin/bash
#
# 03_install_pip.sh
# 각 Python 버전별 pip 설치
#
# 설명:
#   - 기존 pip 정리
#   - 각 Python 버전에 맞는 pip 설치 (get-pip.py 사용)
#   - pip, pip3, pip3.x 명령어 설정
#
# 사용법: ./03_install_pip.sh
# 필요한 설정: SUDO_PASSWORD (config.local.env)
#

set -e

# sudo 공통 라이브러리 로드
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../../lib/sudo.sh"

# sudo 캐시 확인 (Tauri 앱 환경에서 필수)
if ! ensure_sudo_cache; then
    echo -e "${RED}❌ Sudo cache expired or not found${NC}"
    echo "Please verify your password in the password screen first."
    exit 1
fi

echo "=========================================="
echo "  pip 버전별 설치"
echo "=========================================="

# ============================================
# 1. 기존 pip 정리
# ============================================
echo "[1/4] 기존 pip 정리 중..."

# 기존 pip 심볼릭 링크 및 바이너리 제거
run_as_root rm -f /usr/bin/pip 2>/dev/null || true
run_as_root rm -f /usr/local/bin/pip 2>/dev/null || true
run_as_root rm -f /usr/local/bin/pip3 2>/dev/null || true
run_as_root rm -f /usr/local/bin/pip3.10 2>/dev/null || true
run_as_root rm -f /usr/local/bin/pip3.12 2>/dev/null || true
run_as_root rm -f /usr/local/bin/pip3.13 2>/dev/null || true
run_as_root rm -f /usr/local/bin/pip3.14 2>/dev/null || true

# 기존 alternatives 제거
run_as_root update-alternatives --remove-all pip 2>/dev/null || true

echo "   ✓ 기존 pip 정리 완료"

# ============================================
# 2. get-pip.py 다운로드
# ============================================
echo "[2/4] get-pip.py 다운로드 중..."

TEMP_DIR=$(mktemp -d)
cd "$TEMP_DIR"

curl -sS https://bootstrap.pypa.io/get-pip.py -o get-pip.py
echo "   ✓ get-pip.py 다운로드 완료"

# ============================================
# 3. 각 Python 버전에 pip 설치
# ============================================
echo "[3/4] 각 Python 버전에 pip 설치 중..."

PYTHON_VERSIONS=("3.10" "3.12" "3.13" "3.14")
INSTALLED_PIP=()

for VERSION in "${PYTHON_VERSIONS[@]}"; do
    PYTHON_BIN="/usr/bin/python${VERSION}"
    
    if [[ -x "$PYTHON_BIN" ]]; then
        echo "   → Python ${VERSION}에 pip 설치 중..."
        
        # pip 설치
        run_as_root "$PYTHON_BIN" get-pip.py --prefix=/usr 2>/dev/null || {
            echo "   ⚠️  Python ${VERSION} pip 설치 실패"
            continue
        }
        
        # pip 버전 확인
        PIP_VERSION=$("$PYTHON_BIN" -m pip --version 2>&1 | awk '{print $2}')
        echo "   ✓ pip ${PIP_VERSION} for Python ${VERSION} 설치 완료"
        INSTALLED_PIP+=("$VERSION")
    fi
done

# 정리
cd /
rm -rf "$TEMP_DIR"

echo ""

# ============================================
# 4. 설치 확인
# ============================================
echo "[4/4] 설치 확인 중..."
echo ""
echo "┌────────────────────────────────────────────────────────┐"
echo "│  설치된 pip 버전                                       │"
echo "├────────────────────────────────────────────────────────┤"

for VERSION in "${INSTALLED_PIP[@]}"; do
    PYTHON_BIN="/usr/bin/python${VERSION}"
    if [[ -x "$PYTHON_BIN" ]]; then
        PIP_INFO=$("$PYTHON_BIN" -m pip --version 2>&1 || echo "N/A")
        printf "│  pip%-4s → %-43s │\n" "$VERSION" "$PIP_INFO"
    fi
done

echo "└────────────────────────────────────────────────────────┘"
echo ""

# pip 바이너리 위치 확인
echo "📁 /usr/bin/pip* 목록:"
ls -la /usr/bin/pip* 2>/dev/null | awk '{print "   " $NF}' || echo "   (없음)"
echo ""
echo "📁 /usr/local/bin/pip* 목록:"
ls -la /usr/local/bin/pip* 2>/dev/null | awk '{print "   " $NF}' || echo "   (없음)"
echo ""

echo "✅ pip 버전별 설치 완료!"
echo ""
echo "💡 사용 방법:"
echo "   python3.12 -m pip install <package>  # Python 3.12용"
echo "   python3.13 -m pip install <package>  # Python 3.13용"
echo ""
echo "다음 단계: ./04_configure_pip_alternatives.sh"
echo ""


