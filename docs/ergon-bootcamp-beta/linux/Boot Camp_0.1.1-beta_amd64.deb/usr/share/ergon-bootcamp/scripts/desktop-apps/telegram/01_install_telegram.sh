#!/bin/bash
#
# 01_install_telegram.sh
# Telegram Desktop 설치 (Flatpak)
#
# 설명:
#   - Flathub에서 Telegram Desktop 설치
#   - Flatpak이 먼저 설치되어 있어야 함
#
# 사용법: ./01_install_telegram.sh
#

set -e

APP_ID="org.telegram.desktop"
APP_NAME="Telegram Desktop"

echo "=========================================="
echo "  $APP_NAME 설치"
echo "=========================================="
echo ""

# ============================================
# 1. Flatpak 확인
# ============================================
echo "[1/3] Flatpak 확인..."

if ! command -v flatpak &> /dev/null; then
    echo "   ❌ Flatpak이 설치되지 않았습니다."
    echo ""
    echo "   먼저 다음을 실행하세요:"
    echo "   system-setup/flatpak-setup/01_install_flatpak.sh"
    exit 1
fi

echo "   ✓ Flatpak 설치됨"

# Flathub 확인
if ! flatpak remotes | grep -q flathub; then
    echo "   ❌ Flathub 저장소가 등록되지 않았습니다."
    echo ""
    echo "   먼저 다음을 실행하세요:"
    echo "   system-setup/flatpak-setup/02_add_flathub.sh"
    exit 1
fi

echo "   ✓ Flathub 저장소 등록됨"
echo ""

# ============================================
# 2. 기존 설치 확인
# ============================================
echo "[2/3] 기존 설치 확인..."

if flatpak list | grep -q "$APP_ID"; then
    INSTALLED_VERSION=$(flatpak info "$APP_ID" 2>/dev/null | grep "Version:" | awk '{print $2}')
    echo "   ✓ $APP_NAME이 이미 설치되어 있습니다."
    echo "   버전: $INSTALLED_VERSION"
    echo ""
    
    read -p "   업데이트를 확인하시겠습니까? (y/N): " -n 1 -r
    echo ""
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        echo "   업데이트 확인 중..."
        flatpak update -y "$APP_ID" || true
    fi
    exit 0
fi

echo "   → 새로 설치를 진행합니다."
echo ""

# ============================================
# 3. 설치
# ============================================
echo "[3/3] $APP_NAME 설치 중..."
echo "   출처: Flathub (공식)"
echo ""

flatpak install -y flathub "$APP_ID"

echo ""

# ============================================
# 결과 확인
# ============================================
if flatpak list | grep -q "$APP_ID"; then
    INSTALLED_VERSION=$(flatpak info "$APP_ID" 2>/dev/null | grep "Version:" | awk '{print $2}')
    
    echo "┌────────────────────────────────────────┐"
    echo "│  설치 완료                              │"
    echo "├────────────────────────────────────────┤"
    printf "│  %-36s │\n" "$APP_NAME"
    printf "│  버전: %-29s │\n" "$INSTALLED_VERSION"
    echo "└────────────────────────────────────────┘"
    echo ""
    
    echo "✅ $APP_NAME 설치 완료!"
    echo ""
    echo "💡 실행 방법:"
    echo "   flatpak run $APP_ID"
    echo ""
    echo "┌────────────────────────────────────────────────────┐"
    echo "│  ⚠️  앱 메뉴에서 검색하려면 재부팅 필요!           │"
    echo "│                                                    │"
    echo "│  Flatpak 앱은 재부팅 또는 로그아웃/재로그인 후     │"
    echo "│  앱 메뉴에서 검색할 수 있습니다.                   │"
    echo "│                                                    │"
    echo "│  지금 바로 실행: flatpak run $APP_ID │"
    echo "│  재부팅:         sudo reboot                       │"
    echo "│                                                    │"
    echo "└────────────────────────────────────────────────────┘"
    echo ""
else
    echo "❌ 설치에 실패했습니다."
    exit 1
fi

echo "다음 단계: ./02_verify_setup.sh"
echo ""

