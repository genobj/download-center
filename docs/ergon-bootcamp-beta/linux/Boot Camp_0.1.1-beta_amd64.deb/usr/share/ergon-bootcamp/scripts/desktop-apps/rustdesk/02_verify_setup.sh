#!/bin/bash
#
# 02_verify_setup.sh
# RustDesk 설치 확인
#
# 사용법: ./02_verify_setup.sh
#

echo "=========================================="
echo "  RustDesk 설치 확인"
echo "=========================================="

PASS_COUNT=0
FAIL_COUNT=0

# 1. rustdesk 명령어 확인
echo ""
echo "[1/3] rustdesk 명령어 확인..."
if command -v rustdesk &> /dev/null; then
    echo "   ✅ rustdesk 명령어 사용 가능"
    PASS_COUNT=$((PASS_COUNT + 1))
else
    echo "   ❌ rustdesk 명령어를 찾을 수 없음"
    FAIL_COUNT=$((FAIL_COUNT + 1))
fi

# 2. 패키지 설치 상태 확인
echo ""
echo "[2/3] 패키지 설치 상태 확인..."
if dpkg -l | grep -q rustdesk; then
    VERSION=$(dpkg -l | grep rustdesk | awk '{print $3}')
    echo "   ✅ rustdesk 패키지 설치됨: $VERSION"
    PASS_COUNT=$((PASS_COUNT + 1))
else
    echo "   ❌ rustdesk 패키지가 설치되지 않음"
    FAIL_COUNT=$((FAIL_COUNT + 1))
fi

# 3. 데스크톱 파일 확인
echo ""
echo "[3/3] 데스크톱 통합 확인..."
if [ -f "/usr/share/applications/rustdesk.desktop" ]; then
    echo "   ✅ 데스크톱 파일 존재"
    PASS_COUNT=$((PASS_COUNT + 1))
else
    echo "   ⚠️  데스크톱 파일을 찾을 수 없음 (수동 실행은 가능)"
    PASS_COUNT=$((PASS_COUNT + 1))  # 치명적이지 않음
fi

echo ""
echo "=========================================="
echo "  검증 결과"
echo "=========================================="
echo ""
echo "  ✅ 통과: $PASS_COUNT"
echo "  ❌ 실패: $FAIL_COUNT"
echo ""

if [ $FAIL_COUNT -eq 0 ]; then
    echo "🎉 모든 검증을 통과했습니다!"
    echo ""
    echo "┌────────────────────────────────────────────────────┐"
    echo "│  📌 RustDesk 사용법                                │"
    echo "│                                                    │"
    echo "│  실행:                                             │"
    echo "│    rustdesk                                        │"
    echo "│                                                    │"
    echo "│  또는 앱 메뉴에서 'RustDesk' 검색                  │"
    echo "│                                                    │"
    echo "│  💡 자체 서버 설정은 관리자에게 문의               │"
    echo "└────────────────────────────────────────────────────┘"
    exit 0
else
    echo "⚠️  일부 검증이 실패했습니다."
    exit 1
fi

