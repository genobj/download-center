#!/bin/bash
#
# 01_install_flatpak.sh
# Flatpak 패키지 시스템 설치
#
# 설명:
#   - Ubuntu 공식 저장소에서 Flatpak 설치
#   - Ubuntu 24.04에서는 기본 미포함
#
# 사용법: ./01_install_flatpak.sh
#

set -e

# sudo 공통 라이브러리 로드
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../../lib/sudo.sh"

# sudo 캐시 확인 (Tauri 앱 환경에서 필수)
if ! ensure_sudo_cache; then
    echo -e "${RED}❌ Sudo cache expired or not found${NC}"
    echo "Please verify your password in the password screen first."
    exit 1
fi

echo "=========================================="
echo "  Flatpak 설치"
echo "=========================================="
echo ""

# ============================================
# 1. 기존 설치 확인
# ============================================
echo "[1/2] 기존 Flatpak 설치 확인..."

if command -v flatpak &> /dev/null; then
    CURRENT_VERSION=$(flatpak --version)
    echo "   ✓ Flatpak이 이미 설치되어 있습니다: $CURRENT_VERSION"
    echo ""
    exit 0
fi

echo "   → 새로 설치를 진행합니다."
echo ""

# ============================================
# 2. Flatpak 설치
# ============================================
echo "[2/2] Flatpak 설치 중..."

run_as_root apt-get update -qq
run_as_root apt-get install -y flatpak

echo ""

# ============================================
# 결과 확인
# ============================================
FLATPAK_VERSION=$(flatpak --version)

echo "┌────────────────────────────────────────┐"
echo "│  설치 완료                              │"
echo "├────────────────────────────────────────┤"
printf "│  %-36s │\n" "$FLATPAK_VERSION"
echo "└────────────────────────────────────────┘"
echo ""

echo "✅ Flatpak 설치 완료!"
echo ""
echo "다음 단계: ./02_add_flathub.sh"
echo ""

