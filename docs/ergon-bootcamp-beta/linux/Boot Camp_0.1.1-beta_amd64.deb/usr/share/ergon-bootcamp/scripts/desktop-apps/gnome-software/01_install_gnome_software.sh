#!/bin/bash
#
# 01_install_gnome_software.sh
# GNOME Software 및 Flatpak 플러그인 설치
#
# 설명:
#   - GNOME Software: 순정 GUI 앱스토어
#   - Flatpak 플러그인: Flathub 앱 관리 지원
#
# 사용법: ./01_install_gnome_software.sh
#

set -e

# sudo 공통 라이브러리 로드
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../../lib/sudo.sh"

# sudo 캐시 확인 (Tauri 앱 환경에서 필수)
if ! ensure_sudo_cache; then
    echo -e "${RED}❌ Sudo cache expired or not found${NC}"
    echo "Please verify your password in the password screen first."
    exit 1
fi

echo "=========================================="
echo "  GNOME Software 설치"
echo "=========================================="
echo ""

# ============================================
# 1. 패키지 목록
# ============================================
PACKAGES=(
    "gnome-software"                  # GUI 앱스토어
    "gnome-software-plugin-flatpak"   # Flatpak 플러그인
)

echo "[1/2] 설치할 패키지:"
for pkg in "${PACKAGES[@]}"; do
    if dpkg -l | grep -q "^ii  $pkg "; then
        echo "   ✓ $pkg (이미 설치됨)"
    else
        echo "   → $pkg (설치 예정)"
    fi
done
echo ""

# ============================================
# 2. 패키지 설치
# ============================================
echo "[2/2] 패키지 설치 중..."

INSTALL_LIST=()
for pkg in "${PACKAGES[@]}"; do
    if ! dpkg -l | grep -q "^ii  $pkg "; then
        INSTALL_LIST+=("$pkg")
    fi
done

if [[ ${#INSTALL_LIST[@]} -eq 0 ]]; then
    echo "   ✓ 모든 패키지가 이미 설치되어 있습니다."
else
    sudo apt-get update -qq
    sudo apt-get install -y "${INSTALL_LIST[@]}"
    echo "   ✓ 패키지 설치 완료"
fi
echo ""

# ============================================
# 결과 확인
# ============================================
echo "┌────────────────────────────────────────────────────┐"
echo "│  GNOME Software 설치 완료                          │"
echo "├────────────────────────────────────────────────────┤"
echo "│                                                    │"
echo "│  🔵 파란색 가방 아이콘 = GNOME Software           │"
echo "│  🟠 주황색 가방 아이콘 = Ubuntu Software (Snap)   │"
echo "│                                                    │"
echo "│  실행: gnome-software                              │"
echo "│  또는: 앱 메뉴에서 '소프트웨어' 검색               │"
echo "│                                                    │"
echo "└────────────────────────────────────────────────────┘"
echo ""

echo "✅ GNOME Software 설치 완료!"
echo ""
echo "💡 Flatpak 저장소가 설정되어 있어야 Flathub 앱이 표시됩니다."
echo "   system-setup/flatpak-setup 참조"
echo ""
echo "┌────────────────────────────────────────────────────┐"
echo "│  ⚠️  중요: 재부팅 권장!                            │"
echo "│                                                    │"
echo "│  GNOME Software와 Flatpak 앱이 정상 작동하려면     │"
echo "│  재부팅하거나 로그아웃 후 재로그인하세요.          │"
echo "│                                                    │"
echo "│  재부팅: sudo reboot                               │"
echo "│                                                    │"
echo "└────────────────────────────────────────────────────┘"
echo ""
echo "다음 단계: ./02_verify_setup.sh"
echo ""

