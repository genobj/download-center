#!/bin/bash
#
# 02_install_chrome.sh
# Google Chrome 설치
#
# 사용법: ./02_install_chrome.sh
# 필요한 설정: SUDO_PASSWORD (config.local.env)
#

set -e

# sudo 공통 라이브러리 로드
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../../lib/sudo.sh"

# sudo 캐시 확인 (Tauri 앱 환경에서 필수)
if ! ensure_sudo_cache; then
    echo -e "${RED}❌ Sudo cache expired or not found${NC}"
    echo "Please verify your password in the password screen first."
    exit 1
fi

echo "=========================================="
echo "  Google Chrome 설치"
echo "=========================================="

# 이미 설치되어 있는지 확인
if command -v google-chrome &> /dev/null; then
    echo "⚠️  Google Chrome이 이미 설치되어 있습니다."
    google-chrome --version
    exit 0
fi

# 패키지 목록 업데이트
echo "[1/2] 패키지 목록 업데이트 중..."
run_as_root apt update

# Google Chrome 설치
echo "[2/2] Google Chrome 설치 중..."
run_as_root apt install -y google-chrome-stable

echo ""
echo "✅ Google Chrome 설치 완료!"
google-chrome --version
echo ""


