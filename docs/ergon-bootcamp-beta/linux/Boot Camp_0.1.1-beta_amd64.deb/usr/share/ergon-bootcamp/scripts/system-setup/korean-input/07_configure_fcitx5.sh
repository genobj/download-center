#!/bin/bash
#
# 07_configure_fcitx5.sh
# fcitx5 한글 입력기 및 단축키 설정
#
# 사용법: ./07_configure_fcitx5.sh
#

set -e

echo "=========================================="
echo "  fcitx5 입력기 설정"
echo "=========================================="

CONFIG_DIR="$HOME/.config/fcitx5"
CONF_DIR="$CONFIG_DIR/conf"

# 설정 디렉토리 생성
echo "[1/6] 설정 디렉토리 생성 중..."
mkdir -p "$CONFIG_DIR"
mkdir -p "$CONF_DIR"

# fcitx5 중지 (설정 파일 덮어쓰기 방지)
echo "[2/6] fcitx5 일시 중지 중..."
pkill fcitx5 2>/dev/null || true
sleep 1

# 프로필 설정 (한글 입력기 추가)
echo "[3/6] 한글 입력기 프로필 설정 중..."
cat > "$CONFIG_DIR/profile" << 'EOF'
[Groups/0]
# Group Name
Name=Default
# Layout
Default Layout=us
# Default Input Method
DefaultIM=hangul

[Groups/0/Items/0]
# Name
Name=keyboard-us
# Layout
Layout=

[Groups/0/Items/1]
# Name
Name=hangul
# Layout
Layout=

[GroupOrder]
0=Default
EOF

# 단축키 설정
echo "[4/6] 단축키 설정 중..."
cat > "$CONFIG_DIR/config" << 'EOF'
[Hotkey]
# 입력기 전환 키
TriggerKeys=Hangul

[Hotkey/TriggerKeys]
0=Hangul

[Hotkey/EnumerateForwardKeys]
0=Control+space
EOF

# 한글 입력기 설정
cat > "$CONF_DIR/hangul.conf" << 'EOF'
# 한글 입력기 설정
HanjaKey=F9
TriggerKey=Hangul
EOF

# GNOME 입력 소스에서 ibus 제거 (fcitx5와 충돌 방지)
echo "[5/5] GNOME 입력 소스 정리 중..."
if command -v gsettings &> /dev/null; then
    # ibus가 포함된 경우 제거
    CURRENT_SOURCES=$(gsettings get org.gnome.desktop.input-sources sources 2>/dev/null || echo "[]")
    if echo "$CURRENT_SOURCES" | grep -q "ibus"; then
        gsettings set org.gnome.desktop.input-sources sources "[('xkb', 'us'), ('xkb', 'kr+kr104')]"
        echo "   ✓ ibus 제거 완료"
    fi
fi

# fcitx5 재시작
echo ""
echo "[6/6] fcitx5 재시작 중..."
# 환경 변수 설정
export GTK_IM_MODULE=fcitx
export QT_IM_MODULE=fcitx
export XMODIFIERS=@im=fcitx

fcitx5 -d 2>/dev/null &
sleep 3

# fcitx5가 제대로 시작되었는지 확인
if pgrep -x fcitx5 > /dev/null; then
    # hangul 입력기로 전환
    sleep 1
    fcitx5-remote -s hangul 2>/dev/null || true
    echo "   ✓ fcitx5 재시작 완료"
else
    echo "   ⚠️  fcitx5 시작 확인 필요"
fi

echo ""
echo "✅ fcitx5 입력기 설정 완료!"
echo ""
echo "📝 설정된 내용:"
echo "   - 한글 입력기: 활성화"
echo "   - 한/영 전환: 오른쪽 Alt (Hangul 키)"
echo "   - 대체 전환: Ctrl+Space"
echo "   - 한자 변환: F9"
echo ""
echo "⚠️  Wayland 환경에서는 로그아웃/재로그인이 필요할 수 있습니다."
echo ""

