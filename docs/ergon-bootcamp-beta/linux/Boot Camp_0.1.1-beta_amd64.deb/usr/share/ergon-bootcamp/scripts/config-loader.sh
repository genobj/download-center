#!/bin/bash
#
# config-loader.sh
# 설정 파일을 로드하는 헬퍼 스크립트
#
# 사용법 (다른 스크립트에서):
#   source "$(dirname "$0")/../../config-loader.sh"
#   # 이후 $SUDO_PASSWORD, $GIT_USER_NAME 등 사용 가능
#

SCRIPTS_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONFIG_FILE="$SCRIPTS_ROOT/config.local.env"
CONFIG_EXAMPLE="$SCRIPTS_ROOT/config.example.env"

# 색상 정의
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# 설정 파일 확인 및 로드
load_config() {
    if [ ! -f "$CONFIG_FILE" ]; then
        echo -e "${RED}오류: 설정 파일이 없습니다.${NC}"
        echo ""
        echo "다음 명령어로 설정 파일을 생성하세요:"
        echo -e "  ${YELLOW}cp $CONFIG_EXAMPLE $CONFIG_FILE${NC}"
        echo ""
        echo "그 후 $CONFIG_FILE 파일을 편집하여 값을 채워주세요."
        exit 1
    fi

    # .env 파일 로드
    set -a
    source "$CONFIG_FILE"
    set +a

    echo -e "${GREEN}✓ 설정 파일 로드됨${NC}"
}

# 필수 설정값 검증
validate_config() {
    local required_keys=("$@")
    local missing=()

    for key in "${required_keys[@]}"; do
        if [ -z "${!key}" ]; then
            missing+=("$key")
        fi
    done

    if [ ${#missing[@]} -gt 0 ]; then
        echo -e "${RED}오류: 다음 설정값이 비어있습니다:${NC}"
        for key in "${missing[@]}"; do
            echo -e "  - ${YELLOW}$key${NC}"
        done
        echo ""
        echo "설정 파일을 확인하세요: $CONFIG_FILE"
        exit 1
    fi
}

# sudo 명령 래퍼 (비밀번호 자동 입력)
# 
# ⚠️  DEPRECATED: 이 함수는 더 이상 권장되지 않습니다.
# 
# 새 스크립트는 다음 방식을 사용하세요:
#   source "$(dirname "$0")/../lib/sudo.sh"
#   sudo <command>
# 
# 이 함수는 하위 호환성을 위해 유지되지만, 보안상의 이유로
# 공통 라이브러리 기반 방식(scripts/lib/sudo.sh)을 사용하는 것을 권장합니다.
run_sudo() {
    if [ -z "$SUDO_PASSWORD" ]; then
        echo -e "${RED}오류: SUDO_PASSWORD가 설정되지 않았습니다.${NC}"
        exit 1
    fi
    echo "$SUDO_PASSWORD" | sudo -S "$@"
}

# 직접 실행 시 도움말 표시
if [ "${BASH_SOURCE[0]}" == "${0}" ]; then
    echo "config-loader.sh - 설정 파일 로더"
    echo ""
    echo "사용법 (다른 스크립트에서):"
    echo '  source "$(dirname "$0")/../../config-loader.sh"'
    echo '  load_config'
    echo '  validate_config "SUDO_PASSWORD" "GIT_USER_NAME"'
    echo ""
    echo "설정 파일:"
    echo "  - 템플릿: $CONFIG_EXAMPLE"
    echo "  - 로컬:   $CONFIG_FILE"
    echo ""
    
    if [ -f "$CONFIG_FILE" ]; then
        echo -e "${GREEN}✓ config.local.env 존재함${NC}"
    else
        echo -e "${YELLOW}⚠ config.local.env 없음${NC}"
        echo "  cp config.example.env config.local.env"
    fi
fi


