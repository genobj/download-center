#!/bin/bash
#
# 03_configure_permissions.sh
# Flatpak 권한 설정 (폰트 공유)
#
# 설명:
#   - 시스템 폰트 디렉토리 접근 허용
#   - 한글 폰트 깨짐 방지
#
# 사용법: ./03_configure_permissions.sh
#

set -e

# sudo 공통 라이브러리 로드
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../../lib/sudo.sh"

# sudo 캐시 확인 (Tauri 앱 환경에서 필수)
if ! ensure_sudo_cache; then
    echo -e "${RED}❌ Sudo cache expired or not found${NC}"
    echo "Please verify your password in the password screen first."
    exit 1
fi

echo "=========================================="
echo "  Flatpak 권한 설정"
echo "=========================================="
echo ""

# ============================================
# 1. Flatpak 설치 확인
# ============================================
echo "[1/2] Flatpak 설치 확인..."

if ! command -v flatpak &> /dev/null; then
    echo "   ❌ Flatpak이 설치되지 않았습니다."
    exit 1
fi

echo "   ✓ Flatpak 설치됨"
echo ""

# ============================================
# 2. 폰트 디렉토리 권한 설정
# ============================================
echo "[2/2] 폰트 접근 권한 설정..."

# 권한 설정 명령
OVERRIDE_CMD="flatpak override --filesystem=/usr/share/fonts:ro --filesystem=~/.fonts:ro --filesystem=~/.local/share/fonts:ro"

run_as_root $OVERRIDE_CMD

echo "   ✓ /usr/share/fonts (읽기 전용)"
echo "   ✓ ~/.fonts (읽기 전용)"
echo "   ✓ ~/.local/share/fonts (읽기 전용)"
echo ""

# ============================================
# 결과 확인
# ============================================
echo "┌────────────────────────────────────────┐"
echo "│  Flatpak 전역 권한 설정                │"
echo "├────────────────────────────────────────┤"
echo "│  폰트 디렉토리 접근 허용됨 (ro)        │"
echo "│                                        │"
echo "│  한글 폰트 깨짐 없이 표시됩니다        │"
echo "└────────────────────────────────────────┘"
echo ""

echo "✅ Flatpak 권한 설정 완료!"
echo ""
echo "다음 단계: ./04_verify_setup.sh"
echo ""

