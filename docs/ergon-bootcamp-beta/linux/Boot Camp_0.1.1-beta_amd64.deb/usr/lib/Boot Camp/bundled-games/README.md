# Bundled Games

이 폴더는 Cloudsmith에서 다운로드된 게임들이 저장되는 위치입니다.

## 다운로드 방법

### CI/CD (자동)

GitHub Actions에서 빌드 시 자동으로 다운로드됩니다.

### 로컬 개발 (수동)

```bash
cd apps/ergon-bootcamp-tauri

# manifest 다운로드
curl -L "https://dl.cloudsmith.io/public/genobj/games/raw/names/manifest-latest.json/versions/1.0.0/manifest-latest.json" \
  -o manifest.json

# 게임 다운로드 및 해제
cd bundled-games

BASE_URL=$(jq -r '.base_url' ../manifest.json)
for game in $(jq -r '.games[] | select(.bundled==true) | .file' ../manifest.json); do
  echo "Downloading: $game"
  curl -L "${BASE_URL}/${game}" -o "$game"
  unzip -o "$game" -d "${game%-*.zip}"
  rm "$game"
done
```

## 환경 변수 대안

다른 위치의 게임 폴더를 사용하려면:

```bash
export POLLUX_GAMES_PATH="/path/to/my-local-games"
pnpm tauri dev
```

## 참고

- [Cloudsmith 게임 저장소](https://cloudsmith.io/~genobj/repos/games/)
- [게임 통합 가이드](../../../doc/guide/06-game-integration.md)
