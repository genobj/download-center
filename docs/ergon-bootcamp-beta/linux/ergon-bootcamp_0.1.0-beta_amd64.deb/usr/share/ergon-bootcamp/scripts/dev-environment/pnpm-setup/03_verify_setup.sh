#!/bin/bash
#
# 03_verify_setup.sh
# pnpm 설치 검증 스크립트
#
# 설명:
#   - Node.js, pnpm 설치 확인
#   - 프로젝트 생성/설치 테스트
#
# 사용법: ./03_verify_setup.sh
#

echo "=========================================="
echo "  pnpm 설치 검증"
echo "=========================================="
echo ""

PASS_COUNT=0
FAIL_COUNT=0
WARN_COUNT=0

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

pass() {
    echo -e "${GREEN}✓ PASS${NC}: $1"
    PASS_COUNT=$((PASS_COUNT + 1))
}

fail() {
    echo -e "${RED}✗ FAIL${NC}: $1"
    FAIL_COUNT=$((FAIL_COUNT + 1))
}

warn() {
    echo -e "${YELLOW}⚠ WARN${NC}: $1"
    WARN_COUNT=$((WARN_COUNT + 1))
}

# ============================================
# 1. 기본 명령어 확인
# ============================================
echo "┌────────────────────────────────────────┐"
echo "│  1. 기본 명령어 확인                   │"
echo "└────────────────────────────────────────┘"

if command -v node &> /dev/null; then
    VERSION=$(node --version)
    pass "node 설치됨 ($VERSION)"
else
    fail "node 미설치"
fi

if command -v npm &> /dev/null; then
    VERSION=$(npm --version)
    pass "npm 설치됨 (v$VERSION)"
else
    fail "npm 미설치"
fi

if command -v pnpm &> /dev/null; then
    VERSION=$(pnpm --version)
    pass "pnpm 설치됨 (v$VERSION)"
else
    fail "pnpm 미설치"
fi

echo ""

# ============================================
# 2. 프로젝트 테스트
# ============================================
echo "┌────────────────────────────────────────┐"
echo "│  2. 프로젝트 테스트                    │"
echo "└────────────────────────────────────────┘"

if command -v pnpm &> /dev/null; then
    TEMP_DIR=$(mktemp -d)
    cd "$TEMP_DIR"
    
    # pnpm init 테스트
    if pnpm init -y &>/dev/null; then
        pass "pnpm init 작동"
        
        # 패키지 설치 테스트
        if pnpm add lodash --silent &>/dev/null; then
            pass "pnpm add 작동 (lodash 설치)"
            
            # node_modules 확인
            if [[ -d "node_modules/lodash" ]]; then
                pass "node_modules 생성됨"
            else
                fail "node_modules 미생성"
            fi
            
            # pnpm-lock.yaml 확인
            if [[ -f "pnpm-lock.yaml" ]]; then
                pass "pnpm-lock.yaml 생성됨"
            else
                warn "pnpm-lock.yaml 미생성"
            fi
        else
            fail "pnpm add 실패"
        fi
    else
        fail "pnpm init 실패"
    fi
    
    # 정리
    cd /
    rm -rf "$TEMP_DIR"
else
    warn "pnpm 없어서 프로젝트 테스트 스킵"
fi

echo ""

# ============================================
# 3. 환경 변수 확인
# ============================================
echo "┌────────────────────────────────────────┐"
echo "│  3. 환경 변수 확인                     │"
echo "└────────────────────────────────────────┘"

PNPM_HOME="${PNPM_HOME:-$HOME/.local/share/pnpm}"

if [[ -n "$PNPM_HOME" ]]; then
    pass "PNPM_HOME 설정됨 ($PNPM_HOME)"
else
    warn "PNPM_HOME 미설정"
fi

if echo "$PATH" | grep -q "pnpm"; then
    pass "PATH에 pnpm 포함됨"
else
    warn "PATH에 pnpm 미포함"
fi

echo ""

# ============================================
# 4. 글로벌 패키지 테스트
# ============================================
echo "┌────────────────────────────────────────┐"
echo "│  4. 글로벌 설치 테스트                 │"
echo "└────────────────────────────────────────┘"

if command -v pnpm &> /dev/null; then
    # 글로벌 bin 디렉토리 확인
    GLOBAL_DIR=$(pnpm root -g 2>/dev/null || echo "")
    if [[ -n "$GLOBAL_DIR" ]]; then
        pass "글로벌 디렉토리 확인 ($GLOBAL_DIR)"
    else
        warn "글로벌 디렉토리 확인 실패"
    fi
fi

echo ""

# ============================================
# 결과 요약
# ============================================
echo "=========================================="
echo "  검증 결과 요약"
echo "=========================================="
echo ""
echo -e "  ${GREEN}✓ PASS${NC}: ${PASS_COUNT}"
echo -e "  ${YELLOW}⚠ WARN${NC}: ${WARN_COUNT}"
echo -e "  ${RED}✗ FAIL${NC}: ${FAIL_COUNT}"
echo ""

if [[ $FAIL_COUNT -eq 0 ]]; then
    if [[ $WARN_COUNT -eq 0 ]]; then
        echo -e "${GREEN}🎉 모든 테스트 통과!${NC}"
    else
        echo -e "${YELLOW}⚠️  일부 경고가 있지만 기본 기능은 정상입니다.${NC}"
    fi
    EXIT_CODE=0
else
    echo -e "${RED}❌ 일부 테스트 실패. 위의 FAIL 항목을 확인하세요.${NC}"
    EXIT_CODE=1
fi

echo ""
echo "=========================================="
echo ""

exit $EXIT_CODE


