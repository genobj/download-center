#!/bin/bash
#
# 01_configure_git.sh
# Git 사용자 설정
#
# 설명:
#   - config.local.env에서 사용자 정보 로드
#   - Git 전역 설정 구성
#
# 사용법: ./01_configure_git.sh
#

set -e

echo "=========================================="
echo "  Git 사용자 설정"
echo "=========================================="
echo ""

# ============================================
# 1. 환경 변수 로드
# ============================================
echo "[1/3] 설정 파일 로드 중..."

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONFIG_FILE="$SCRIPT_DIR/../../config.local.env"

if [[ -f "$CONFIG_FILE" ]]; then
    source "$CONFIG_FILE"
    echo "   ✓ config.local.env 로드됨"
else
    echo "   ⚠️  config.local.env 없음"
    echo ""
    echo "   Git 사용자 정보를 입력하세요:"
    read -p "   이름: " GIT_USER_NAME
    read -p "   이메일: " GIT_USER_EMAIL
fi

# 필수 값 확인
if [[ -z "$GIT_USER_NAME" ]] || [[ -z "$GIT_USER_EMAIL" ]]; then
    echo "❌ GIT_USER_NAME과 GIT_USER_EMAIL이 필요합니다."
    exit 1
fi

echo ""

# ============================================
# 2. Git 사용자 설정
# ============================================
echo "[2/3] Git 사용자 설정 중..."

git config --global user.name "$GIT_USER_NAME"
echo "   ✓ user.name: $GIT_USER_NAME"

git config --global user.email "$GIT_USER_EMAIL"
echo "   ✓ user.email: $GIT_USER_EMAIL"

echo ""

# ============================================
# 3. Git 기본 설정
# ============================================
echo "[3/3] Git 기본 설정 중..."

# 기본 브랜치 이름
git config --global init.defaultBranch main
echo "   ✓ init.defaultBranch: main"

# 에디터 설정 (VS Code)
if command -v code &> /dev/null; then
    git config --global core.editor "code --wait"
    echo "   ✓ core.editor: code --wait"
fi

# 줄바꿈 처리 (Linux)
git config --global core.autocrlf input
echo "   ✓ core.autocrlf: input"

# Pull 전략
git config --global pull.rebase false
echo "   ✓ pull.rebase: false"

# Push 시 자동 upstream 설정
git config --global push.autoSetupRemote true
echo "   ✓ push.autoSetupRemote: true"

# 색상 출력
git config --global color.ui auto
echo "   ✓ color.ui: auto"

echo ""

# ============================================
# 결과 확인
# ============================================
echo "┌────────────────────────────────────────┐"
echo "│  Git 설정 완료                          │"
echo "├────────────────────────────────────────┤"
printf "│  user.name:  %-24s │\n" "$GIT_USER_NAME"
printf "│  user.email: %-24s │\n" "$GIT_USER_EMAIL"
echo "└────────────────────────────────────────┘"
echo ""

echo "✅ Git 사용자 설정 완료!"
echo ""
echo "다음 단계: ./02_install_gh.sh"
echo ""


