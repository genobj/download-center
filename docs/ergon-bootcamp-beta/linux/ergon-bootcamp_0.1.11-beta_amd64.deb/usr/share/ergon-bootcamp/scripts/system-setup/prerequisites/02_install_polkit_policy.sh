#!/bin/bash
#
# 02_install_polkit_policy.sh
# Polkit 정책 파일 설치
#
# 사용법: ./02_install_polkit_policy.sh
#

set -e

# sudo 공통 라이브러리 로드
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../../lib/sudo.sh"

# sudo 캐시 확인 (Tauri 앱 환경에서 필수)
if ! ensure_sudo_cache; then
    echo -e "${RED}❌ Sudo cache expired or not found${NC}"
    echo "Please verify your password in the password screen first."
    exit 1
fi

echo "=========================================="
echo "  Polkit 정책 파일 설치"
echo "=========================================="
echo ""

POLICY_FILE="com.ergon.bootcamp.policy"
POLICY_DIR="/usr/share/polkit-1/actions"
POLICY_SOURCE="$SCRIPT_DIR/../../../polkit/$POLICY_FILE"
POLICY_TARGET="$POLICY_DIR/$POLICY_FILE"

# 정책 파일 경로 확인
if [ ! -f "$POLICY_SOURCE" ]; then
    echo "❌ 정책 파일을 찾을 수 없습니다: $POLICY_SOURCE"
    exit 1
fi

# 이미 설치되어 있는지 확인
if [ -f "$POLICY_TARGET" ]; then
    echo "ℹ️  Polkit 정책 파일이 이미 설치되어 있습니다."
    echo "   위치: $POLICY_TARGET"
    echo "   업데이트를 위해 덮어씁니다..."
    echo ""
fi

echo "[1/2] 정책 파일 복사 중..."
run_as_root cp "$POLICY_SOURCE" "$POLICY_TARGET"
run_as_root chmod 644 "$POLICY_TARGET"
echo "   ✓ $POLICY_TARGET"

echo ""
echo "[2/2] 정책 파일 검증 중..."
if [ -f "$POLICY_TARGET" ]; then
    echo "   ✓ 정책 파일이 올바르게 설치되었습니다."
else
    echo "   ❌ 정책 파일 설치 실패"
    exit 1
fi

echo ""
echo "✅ Polkit 정책 파일 설치 완료!"
echo "   위치: $POLICY_TARGET"
echo ""
echo "📝 이제 Tauri 앱에서 스크립트를 실행할 수 있습니다."
echo ""

