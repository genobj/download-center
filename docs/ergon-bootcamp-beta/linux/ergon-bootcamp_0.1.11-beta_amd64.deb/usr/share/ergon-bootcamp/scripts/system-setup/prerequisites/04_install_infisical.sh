#!/bin/bash
#
# 04_install_infisical.sh
# Infisical CLI 설치
#
# 사용법: ./04_install_infisical.sh
#

set -e

# sudo 공통 라이브러리 로드
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../../lib/sudo.sh"

# sudo 캐시 확인 (Tauri 앱 환경에서 필수)
if ! ensure_sudo_cache; then
    echo -e "${RED}❌ Sudo cache expired or not found${NC}"
    echo "Please verify your password in the password screen first."
    exit 1
fi

echo "=========================================="
echo "  Infisical CLI 설치"
echo "=========================================="

# 이미 설치되어 있는지 확인
if command -v infisical &> /dev/null; then
    CURRENT_VERSION=$(infisical --version 2>/dev/null | head -1)
    echo "ℹ️  Infisical CLI가 이미 설치되어 있습니다: $CURRENT_VERSION"
    echo ""
    read -p "재설치하시겠습니까? (y/N): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        echo "설치를 건너뜁니다."
        exit 0
    fi
fi

# Infisical 저장소 설정
echo "[1/2] Infisical 저장소 설정 중..."
curl -1sLf 'https://artifacts-cli.infisical.com/setup.deb.sh' | run_as_root_stdin bash

# Infisical CLI 설치
echo "[2/2] Infisical CLI 설치 중..."
run_as_root apt-get update
run_as_root apt-get install -y infisical

echo ""
echo "✅ Infisical CLI 설치 완료!"
echo ""

# 버전 확인
if command -v infisical &> /dev/null; then
    echo "📝 설치된 버전:"
    echo "   $(infisical --version 2>/dev/null | head -1)"
    echo ""
    echo "🚀 사용법:"
    echo "   infisical login     # 로그인"
    echo "   infisical run       # 시크릿 주입하여 명령 실행"
    echo "   infisical export    # 시크릿 내보내기"
    echo ""
else
    echo "❌ 설치 확인 실패. 수동으로 확인해주세요."
    exit 1
fi

