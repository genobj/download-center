#!/bin/bash
#
# 02_install_base_packages.sh
# apt 패키지 설치에 필요한 기본 의존성 라이브러리 설치
#
# 사용법: ./02_install_base_packages.sh
# 필요한 설정: SUDO_PASSWORD (config.local.env)
#

set -e

# sudo 공통 라이브러리 로드
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../../lib/sudo.sh"

# sudo 캐시 확인 (Tauri 앱 환경에서 필수)
if ! ensure_sudo_cache; then
    echo -e "${RED}❌ Sudo cache expired or not found${NC}"
    echo "Please verify your password in the password screen first."
    exit 1
fi

echo "=========================================="
echo "  기본 의존성 패키지 설치"
echo "=========================================="

# 설치할 패키지 목록
PACKAGES=(
    "git"                         # 버전 관리
    "software-properties-common"  # PPA 관리 도구
    "apt-transport-https"         # HTTPS 저장소 지원
    "wget"                        # 파일 다운로드
    "gpg"                         # GPG 키 관리
    "curl"                        # HTTP 클라이언트
    "ca-certificates"             # SSL 인증서
    "build-essential"             # 컴파일 도구 (gcc, make 등)
    "libssl-dev"                  # OpenSSL 개발 라이브러리
    "pkg-config"                  # 라이브러리 검색 도구
)

# 패키지 목록 업데이트
echo "[1/2] 패키지 목록 업데이트 중..."
run_as_root apt update

# 패키지 설치
echo "[2/2] 기본 의존성 패키지 설치 중..."
echo "   설치 패키지: ${PACKAGES[*]}"
run_as_root apt install -y "${PACKAGES[@]}"

echo ""
echo "✅ 기본 의존성 패키지 설치 완료!"
echo ""
echo "📝 설치된 패키지:"
echo "   - git: 버전 관리 시스템"
echo "   - software-properties-common: PPA 관리"
echo "   - apt-transport-https: HTTPS 저장소 지원"
echo "   - wget: 파일 다운로드"
echo "   - gpg: GPG 키 관리"
echo "   - curl: HTTP 클라이언트"
echo "   - ca-certificates: SSL 인증서"
echo "   - build-essential: 컴파일 도구 (gcc, make 등)"
echo "   - libssl-dev: OpenSSL 개발 라이브러리"
echo "   - pkg-config: 라이브러리 검색 도구"
echo ""


