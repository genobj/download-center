#!/bin/bash
#
# 01_install_cursor.sh
# Cursor AI 에디터 설치
#
# 사용법: ./01_install_cursor.sh
# 필요한 설정: SUDO_PASSWORD (config.local.env)
#

set -e

# sudo 공통 라이브러리 로드
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../../lib/sudo.sh"

# sudo 캐시 확인 (Tauri 앱 환경에서 필수)
if ! ensure_sudo_cache; then
    echo -e "${RED}❌ Sudo cache expired or not found${NC}"
    echo "Please verify your password in the password screen first."
    exit 1
fi

echo "=========================================="
echo "  Cursor AI 에디터 설치"
echo "=========================================="

# 아키텍처 확인
ARCH=$(dpkg --print-architecture)
if [ "$ARCH" != "amd64" ]; then
    echo "❌ 지원되지 않는 아키텍처: $ARCH"
    echo "   Cursor AI는 현재 amd64만 지원합니다."
    exit 1
fi

# 다운로드 설정
DOWNLOAD_URL="https://api2.cursor.sh/updates/download/golden/linux-x64-deb/cursor/2.2"
DEB_FILE="cursor_latest_amd64.deb"

# 설치 상태 확인 (dpkg-query 사용)
# "install ok installed" 상태만 설치된 것으로 판단
CURSOR_STATUS=$(dpkg-query -W -f='${Status}' cursor 2>/dev/null || echo "")
IS_INSTALLED=false

if echo "$CURSOR_STATUS" | grep -q "^install ok installed$"; then
    IS_INSTALLED=true
    CURRENT_VERSION=$(dpkg-query -W -f='${Version}' cursor 2>/dev/null | head -1 | tr -d '[:space:]')
elif [ -f /usr/bin/cursor ] || command -v cursor &> /dev/null; then
    # 패키지 없이 실행 파일만 있는 경우 (불완전한 설치)
    IS_INSTALLED=true
    CURRENT_VERSION=""
fi

# 이미 설치된 경우 처리
if [ "$IS_INSTALLED" = true ]; then
    if [ -n "$CURRENT_VERSION" ]; then
        echo "ℹ️  Cursor AI가 이미 설치되어 있습니다. (버전: $CURRENT_VERSION)"
    else
        echo "ℹ️  Cursor AI 관련 파일이 발견되었습니다."
    fi
    
    # TTY 확인: 터미널이면 대화형, 아니면 자동 재설치
    if [ -t 0 ] && [ -t 1 ]; then
        read -p "재설치 하시겠습니까? (y/N): " -n 1 -r
        echo
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            echo "설치를 건너뜁니다."
            exit 0
        fi
    else
        echo "   비대화형 모드: 재설치를 진행합니다..."
    fi
    
    # 기존 패키지 제거
    echo "   기존 패키지 제거 중..."
    { run_as_root apt-get remove -y -qq cursor >/dev/null 2>&1; } || true
    { run_as_root apt-get purge -y -qq cursor >/dev/null 2>&1; } || true
    { run_as_root dpkg --configure -a >/dev/null 2>&1; } || true
    
    # 잔여 파일 정리
    [ -f /usr/bin/cursor ] && { run_as_root rm -f /usr/bin/cursor >/dev/null 2>&1; } || true
    
    echo "   ✓ 기존 설치 제거 완료"
    echo ""
fi

# 설치 시작
echo "[1/4] 임시 디렉토리 생성..."
TEMP_DIR=$(mktemp -d)
cd "$TEMP_DIR"

echo "[2/4] Cursor AI 다운로드 중..."
echo "   URL: $DOWNLOAD_URL"
echo ""

# 다운로드 (wget 우선, curl 대체)
if wget --show-progress "$DOWNLOAD_URL" -O "$DEB_FILE" 2>&1; then
    echo "   ✓ 다운로드 완료"
elif curl -L --progress-bar -o "$DEB_FILE" "$DOWNLOAD_URL" 2>&1; then
    echo "   ✓ 다운로드 완료 (curl 사용)"
else
    echo "   ❌ 다운로드 실패"
    echo ""
    echo "   수동 다운로드 방법:"
    echo "   1. https://cursor.com/download 접속"
    echo "   2. Linux용 .deb 파일 다운로드"
    echo "   3. sudo dpkg -i cursor_*.deb && sudo apt-get install -f -y"
    cd /
    rm -rf "$TEMP_DIR"
    exit 1
fi

echo "[3/4] Cursor AI 설치 중..."

# 패키지 설치
if run_as_root dpkg -i "$DEB_FILE" 2>&1; then
    echo "   ✓ 패키지 설치 완료"
else
    echo "   의존성 문제 해결 중..."
    run_as_root apt-get install -f -y >/dev/null 2>&1 || true
fi

# 설치 확인
if dpkg-query -W -f='${Status}' cursor 2>/dev/null | grep -q "install ok installed"; then
    INSTALLED_VERSION=$(dpkg-query -W -f='${Version}' cursor 2>/dev/null | head -1 | tr -d '[:space:]')
    echo "   ✓ Cursor AI 설치 완료: $INSTALLED_VERSION"
else
    echo "   ⚠️  설치 확인 실패"
fi

# 데스크톱 데이터베이스 업데이트 (도크에 아이콘 표시)
if command -v update-desktop-database &> /dev/null; then
    run_as_root update-desktop-database /usr/share/applications/ 2>/dev/null || true
fi

echo "[4/4] 임시 파일 정리..."
cd /
rm -rf "$TEMP_DIR"

echo ""
echo "┌────────────────────────────────────────────────────┐"
echo "│  ✅ Cursor AI 설치 완료!                            │"
echo "│                                                    │"
echo "│  실행: cursor                                      │"
echo "│  또는: 앱 메뉴에서 'Cursor' 검색                    │"
echo "└────────────────────────────────────────────────────┘"
echo ""
