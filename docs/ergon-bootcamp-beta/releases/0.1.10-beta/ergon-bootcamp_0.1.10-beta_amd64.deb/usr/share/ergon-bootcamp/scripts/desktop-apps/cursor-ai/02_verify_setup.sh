#!/bin/bash
#
# 02_verify_setup.sh
# Cursor AI 설치 확인
#
# 사용법: ./02_verify_setup.sh
#

echo "=========================================="
echo "  Cursor AI 설치 확인"
echo "=========================================="

PASS_COUNT=0
FAIL_COUNT=0

# 1. cursor 명령어 확인
echo ""
echo "[1/3] cursor 명령어 확인..."
CURSOR_FOUND=false
CURSOR_PATH=""

# PATH에서 cursor 명령어 확인
if command -v cursor &> /dev/null; then
    CURSOR_PATH=$(command -v cursor)
    CURSOR_FOUND=true
else
    # PATH에 없으면 일반적인 설치 경로 확인
    for path in "/usr/bin/cursor" "/usr/local/bin/cursor" "$HOME/.local/bin/cursor"; do
        if [ -f "$path" ] || [ -L "$path" ]; then
            CURSOR_PATH="$path"
            CURSOR_FOUND=true
            break
        fi
    done
fi

if [ "$CURSOR_FOUND" = true ]; then
    echo "   ✅ cursor 명령어 사용 가능"
    echo "      경로: $CURSOR_PATH"
    PASS_COUNT=$((PASS_COUNT + 1))
else
    echo "   ❌ cursor 명령어를 찾을 수 없음"
    FAIL_COUNT=$((FAIL_COUNT + 1))
fi

# 2. 패키지 설치 상태 확인
echo ""
echo "[2/3] 패키지 설치 상태 확인..."
# 정확히 "cursor" 패키지만 확인 (다른 cursor 관련 패키지 제외)
if dpkg -l | grep -q "^ii  cursor "; then
    VERSION=$(dpkg -l | grep "^ii  cursor " | awk '{print $3}')
    echo "   ✅ cursor 패키지 설치됨: $VERSION"
    PASS_COUNT=$((PASS_COUNT + 1))
else
    echo "   ⚠️  cursor 패키지가 설치되지 않음 (AppImage일 수 있음)"
    # AppImage 경로 확인
    if [ -f "$HOME/.local/share/cursor/cursor" ] || [ -f "$HOME/Applications/cursor" ]; then
        echo "   ✅ AppImage 파일 발견됨"
        PASS_COUNT=$((PASS_COUNT + 1))
    else
        FAIL_COUNT=$((FAIL_COUNT + 1))
    fi
fi

# 3. 데스크톱 파일 확인
echo ""
echo "[3/3] 데스크톱 통합 확인..."
DESKTOP_FOUND=false
for DESKTOP_FILE in "/usr/share/applications/cursor.desktop" \
                    "$HOME/.local/share/applications/cursor.desktop" \
                    "/usr/share/applications/com.todesktop.desktop230313mz4w4u92.desktop"; do
    if [ -f "$DESKTOP_FILE" ]; then
        echo "   ✅ 데스크톱 파일 존재: $DESKTOP_FILE"
        DESKTOP_FOUND=true
        break
    fi
done

if [ "$DESKTOP_FOUND" = false ]; then
    echo "   ⚠️  데스크톱 파일을 찾을 수 없음 (수동 실행은 가능)"
    PASS_COUNT=$((PASS_COUNT + 1))  # 치명적이지 않음
else
    PASS_COUNT=$((PASS_COUNT + 1))
fi

echo ""
echo "=========================================="
echo "  검증 결과"
echo "=========================================="
echo ""
echo "  ✅ 통과: $PASS_COUNT"
echo "  ❌ 실패: $FAIL_COUNT"
echo ""

if [ $FAIL_COUNT -eq 0 ]; then
    echo "🎉 모든 검증을 통과했습니다!"
    echo ""
    echo "┌────────────────────────────────────────────────────┐"
    echo "│  📌 Cursor AI 사용법                               │"
    echo "│                                                    │"
    echo "│  실행:                                             │"
    echo "│    cursor                                          │"
    echo "│                                                    │"
    echo "│  또는 앱 메뉴에서 'Cursor' 검색                    │"
    echo "│                                                    │"
    echo "│  💡 참고:                                          │"
    echo "│  - Cursor는 AI 기반 코드 에디터입니다               │"
    echo "│  - VS Code 기반으로 제작되었습니다                  │"
    echo "│  - 첫 실행 시 로그인이 필요할 수 있습니다            │"
    echo "└────────────────────────────────────────────────────┘"
    exit 0
else
    echo "⚠️  일부 검증이 실패했습니다."
    echo ""
    echo "수동 설치 방법:"
    echo "  1. https://cursor.sh/ 접속"
    echo "  2. Linux용 설치 파일 다운로드"
    echo "  3. 다운로드한 파일 실행"
    exit 1
fi

