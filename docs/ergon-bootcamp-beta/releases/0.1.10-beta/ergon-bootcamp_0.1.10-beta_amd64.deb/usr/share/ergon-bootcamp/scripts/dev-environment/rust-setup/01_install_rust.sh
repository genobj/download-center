#!/bin/bash
#
# 01_install_rust.sh
# Rust 개발 환경 설치 (rustup 공식 설치)
#
# 설명:
#   - rustup을 통해 Rust 툴체인 설치
#   - rustc (컴파일러), cargo (패키지 매니저) 설치
#   - rustfmt, clippy 컴포넌트 추가
#
# 사용법: ./01_install_rust.sh
#

set -e

# sudo 공통 라이브러리 로드
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../../lib/sudo.sh"

# sudo로 실행될 때 실제 사용자 홈 디렉토리 찾기
if [ -n "$SUDO_USER" ]; then
    REAL_HOME=$(getent passwd "$SUDO_USER" | cut -d: -f6)
    REAL_USER="$SUDO_USER"
else
    REAL_HOME="$HOME"
    REAL_USER="$USER"
fi

echo "=========================================="
echo "  Rust 개발 환경 설치"
echo "=========================================="
echo ""

# ============================================
# 1. 의존성 확인 (항상 먼저 수행)
# ============================================
echo "[1/4] 의존성 확인 중..."

# sudo 캐시 확인
if ! ensure_sudo_cache; then
    echo -e "${RED}❌ Sudo cache expired or not found${NC}"
    echo "Please verify your password in the password screen first."
    exit 1
fi

# curl 확인
if ! command -v curl &> /dev/null; then
    echo "   → curl 설치 중..."
    run_as_root apt-get update -qq
    run_as_root apt-get install -y curl
fi
echo "   ✓ curl 확인됨"

# build-essential 확인 (링커 등)
if ! dpkg -l | grep -q "^ii  build-essential "; then
    echo "   → build-essential 설치 중..."
    run_as_root apt-get update -qq
    run_as_root apt-get install -y build-essential
fi
echo "   ✓ build-essential 확인됨"

# libssl-dev 확인 (OpenSSL 개발 라이브러리)
if ! dpkg -l | grep -q "^ii  libssl-dev "; then
    echo "   → libssl-dev 설치 중..."
    run_as_root apt-get update -qq
    run_as_root apt-get install -y libssl-dev
fi
echo "   ✓ libssl-dev 확인됨"

# pkg-config 확인 (라이브러리 검색 도구)
if ! command -v pkg-config &> /dev/null; then
    echo "   → pkg-config 설치 중..."
    run_as_root apt-get update -qq
    run_as_root apt-get install -y pkg-config
fi
echo "   ✓ pkg-config 확인됨"

echo ""

# ============================================
# 2. 기존 Rust 설치 확인
# ============================================
echo "[2/4] 기존 Rust 설치 확인 중..."

# 실제 사용자의 cargo 환경 로드
if [ -f "$REAL_HOME/.cargo/env" ]; then
    source "$REAL_HOME/.cargo/env"
fi

if command -v rustc &> /dev/null; then
    CURRENT_VERSION=$(rustc --version)
    echo "   ⚠️  Rust가 이미 설치되어 있습니다: ${CURRENT_VERSION}"
    echo ""
    
    # TTY 확인
    UPDATE_RUST=false
    if [ -t 0 ] && [ -t 1 ]; then
        read -p "   업데이트를 진행하시겠습니까? (y/N): " -n 1 -r
        echo ""
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            UPDATE_RUST=true
        else
            echo "   설치를 건너뜁니다."
            exit 0
        fi
    else
        # TTY가 없는 경우 (Tauri 앱) - 자동으로 업데이트 진행
        UPDATE_RUST=true
    fi
    
    if [ "$UPDATE_RUST" = true ]; then
        echo "   → rustup update 실행 중..."
        if [ -n "$SUDO_USER" ]; then
            sudo -u "$SUDO_USER" rustup update
        else
            rustup update
        fi
        echo "   ✓ Rust 업데이트 완료"
        
        # 컴포넌트 확인 및 추가
        echo ""
        echo "[추가] 컴포넌트 확인 중..."
        if [ -n "$SUDO_USER" ]; then
            sudo -u "$SUDO_USER" rustup component add rustfmt clippy 2>/dev/null || true
        else
            rustup component add rustfmt clippy 2>/dev/null || true
        fi
        echo "   ✓ 컴포넌트 확인 완료"
        
        # 결과 출력 후 종료
        echo ""
        echo "┌────────────────────────────────────────┐"
        echo "│  현재 Rust 버전                        │"
        echo "├────────────────────────────────────────┤"
        printf "│  %-36s │\n" "$(rustc --version)"
        printf "│  %-36s │\n" "$(cargo --version)"
        printf "│  %-36s │\n" "$(rustup --version 2>&1 | head -1)"
        echo "└────────────────────────────────────────┘"
        exit 0
    fi
fi

echo "   ✓ 새로 설치를 진행합니다."
echo ""

# ============================================
# 3. rustup 설치
# ============================================
echo "[3/4] rustup으로 Rust 설치 중..."
echo "   출처: https://sh.rustup.rs (공식)"
echo ""

# rustup 설치 (비대화형 모드, 실제 사용자로 실행)
# rustup이 info 메시지를 stderr로 출력하므로 stdout으로 리다이렉트
if [ -n "$SUDO_USER" ]; then
    sudo -u "$SUDO_USER" bash -c 'curl --proto "=https" --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y --default-toolchain stable' 2>&1
else
    curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y --default-toolchain stable 2>&1
fi

# PATH 설정 로드
source "$REAL_HOME/.cargo/env"

echo ""
echo "   ✓ Rust 기본 설치 완료"

# ============================================
# 4. 추가 컴포넌트 설치
# ============================================
echo "[4/4] 추가 컴포넌트 설치 중..."

# rustfmt (코드 포맷터)
# rustup이 info 메시지를 stderr로 출력하므로 stdout으로 리다이렉트
if [ -n "$SUDO_USER" ]; then
    sudo -u "$SUDO_USER" bash -c "source $REAL_HOME/.cargo/env && rustup component add rustfmt" 2>&1
else
    rustup component add rustfmt 2>&1
fi
echo "   ✓ rustfmt 설치됨"

# clippy (린터)
if [ -n "$SUDO_USER" ]; then
    sudo -u "$SUDO_USER" bash -c "source $REAL_HOME/.cargo/env && rustup component add clippy" 2>&1
else
    rustup component add clippy 2>&1
fi
echo "   ✓ clippy 설치됨"

echo ""

# ============================================
# 설치 검증
# ============================================
echo "[검증] 설치 확인 중..."

# PATH에 cargo bin 추가 (root로 실행 시에도 찾을 수 있도록)
export PATH="$REAL_HOME/.cargo/bin:$PATH"

if ! command -v rustc &> /dev/null; then
    # 직접 경로로도 확인
    if [ ! -f "$REAL_HOME/.cargo/bin/rustc" ]; then
        echo "   ❌ rustc 설치 실패"
        exit 1
    fi
fi

if ! command -v cargo &> /dev/null; then
    # 직접 경로로도 확인
    if [ ! -f "$REAL_HOME/.cargo/bin/cargo" ]; then
        echo "   ❌ cargo 설치 실패"
        exit 1
    fi
fi

echo "   ✓ 설치 검증 완료"
echo ""

# ============================================
# 결과 확인
# ============================================
RUSTC_CMD="$REAL_HOME/.cargo/bin/rustc"
CARGO_CMD="$REAL_HOME/.cargo/bin/cargo"
RUSTUP_CMD="$REAL_HOME/.cargo/bin/rustup"

echo "┌────────────────────────────────────────┐"
echo "│  ✅ 설치 완료                           │"
echo "├────────────────────────────────────────┤"
printf "│  %-36s │\n" "$($RUSTC_CMD --version 2>/dev/null || echo 'rustc installed')"
printf "│  %-36s │\n" "$($CARGO_CMD --version 2>/dev/null || echo 'cargo installed')"
printf "│  %-36s │\n" "$($RUSTUP_CMD --version 2>&1 | head -1 || echo 'rustup installed')"
echo "├────────────────────────────────────────┤"
echo "│  Components:                           │"
printf "│  %-36s │\n" "✓ rustfmt (cargo fmt)"
printf "│  %-36s │\n" "✓ clippy (cargo clippy)"
echo "└────────────────────────────────────────┘"
echo ""

echo "📁 설치 위치:"
echo "   CARGO_HOME: $REAL_HOME/.cargo"
echo "   RUSTUP_HOME: $REAL_HOME/.rustup"
echo ""

echo "💡 새 터미널을 열거나 다음 명령어를 실행하세요:"
echo "   source \$HOME/.cargo/env"
echo ""
echo "다음 단계: ./02_verify_setup.sh"
echo ""
