#!/bin/bash
#
# 01_install_flameshot.sh
# Flameshot 화면 캡처 프로그램 설치
#
# 사용법: ./01_install_flameshot.sh
# 필요한 설정: SUDO_PASSWORD (config.local.env)
#

set -e

# sudo 공통 라이브러리 로드
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../../lib/sudo.sh"

# sudo 캐시 확인 (Tauri 앱 환경에서 필수)
if ! ensure_sudo_cache; then
    echo -e "${RED}❌ Sudo cache expired or not found${NC}"
    echo "Please verify your password in the password screen first."
    exit 1
fi

echo "=========================================="
echo "  Flameshot 설치"
echo "=========================================="

# 이미 설치되어 있는지 확인
if command -v flameshot &> /dev/null; then
    echo "⚠️  Flameshot이 이미 설치되어 있습니다."
    flameshot --version
    exit 0
fi

# 패키지 목록 업데이트
echo "[1/2] 패키지 목록 업데이트 중..."
run_as_root apt update

# Flameshot 설치
echo "[2/2] Flameshot 설치 중..."
run_as_root apt install -y flameshot

echo ""
echo "✅ Flameshot 설치 완료!"
flameshot --version
echo ""
echo "📝 주요 기능:"
echo "   - 전체 화면, 선택 영역, 활성 창 캡처"
echo "   - 실시간 편집: 모자이크, 강조, 텍스트, 화살표"
echo "   - 클립보드 복사, 파일 저장, URL 업로드"
echo ""
echo "┌────────────────────────────────────────────────────┐"
echo "│  💡 사용 방법                                      │"
echo "├────────────────────────────────────────────────────┤"
echo "│  앱 아이콘 클릭 시 시스템 트레이에서 실행됩니다.    │"
echo "│  화면 캡처를 시작하려면:                           │"
echo "│                                                    │"
echo "│  • 터미널: flameshot gui                          │"
echo "│  • 단축키: Print Screen (설정된 경우)             │"
echo "│  • 트레이 아이콘 우클릭 → Take Screenshot         │"
echo "└────────────────────────────────────────────────────┘"
echo ""


