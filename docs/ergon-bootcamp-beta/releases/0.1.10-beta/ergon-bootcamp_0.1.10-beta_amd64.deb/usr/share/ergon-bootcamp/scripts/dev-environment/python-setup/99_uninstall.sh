#!/bin/bash
#
# 99_uninstall.sh
# Python 추가 버전 삭제 스크립트
#
# 주의: 시스템 기본 Python(Ubuntu 24.04: python3.12)은 삭제하지 않음
#       시스템 Python 삭제 시 Ubuntu가 정상 작동하지 않을 수 있음
#

set -e

# 환경 변수 설정 (비대화형 모드)
export DEBIAN_FRONTEND=noninteractive
export APT_LISTCHANGES_FRONTEND=none

# sudo 캐시 확인 (만료되었으면 에러)
if ! sudo -n -v 2>/dev/null; then
    echo "❌ Sudo cache expired. Please verify your password first."
    exit 1
fi

# sudo 공통 라이브러리 로드
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../../lib/sudo.sh"

echo "=========================================="
echo "  Python 추가 버전 삭제"
echo "=========================================="
echo ""
echo "⚠️  주의: 시스템 기본 Python은 삭제하지 않습니다."
echo "   (시스템 Python 삭제 시 Ubuntu가 손상될 수 있음)"
echo ""

# 시스템 기본 Python 버전 확인
SYSTEM_PYTHON=$(python3 --version 2>/dev/null | awk '{print $2}' | cut -d. -f1,2)
echo "   시스템 Python 버전: $SYSTEM_PYTHON (보존됨)"
echo ""

# ============================================
# 1. deadsnakes PPA에서 설치한 추가 Python 삭제
# ============================================
echo "[1/3] 추가 Python 버전 확인 중..."

# 삭제할 Python 버전 목록 (시스템 Python 제외)
PYTHON_VERSIONS=("3.10" "3.11" "3.13" "3.14")
PACKAGES_TO_REMOVE=()

for ver in "${PYTHON_VERSIONS[@]}"; do
    # 시스템 Python이면 건너뛰기
    if [ "$ver" = "$SYSTEM_PYTHON" ]; then
        echo "   ⏭️  python$ver (시스템 Python - 보존)"
        continue
    fi
    
    # 설치되어 있는 패키지만 삭제 목록에 추가
    for suffix in "" "-venv" "-dev"; do
        PKG="python$ver$suffix"
        PKG_STATUS=$(dpkg-query -W -f='${Status}' "$PKG" 2>/dev/null || echo "")
        if echo "$PKG_STATUS" | grep -q "install ok installed"; then
            PACKAGES_TO_REMOVE+=("$PKG")
            echo "   🗑️  $PKG (삭제 예정)"
        fi
    done
done

echo ""

# ============================================
# 2. 패키지 삭제
# ============================================
echo "[2/3] 패키지 삭제 중..."

if [ ${#PACKAGES_TO_REMOVE[@]} -eq 0 ]; then
    echo "   ✓ 삭제할 추가 Python 패키지가 없습니다."
else
    for pkg in "${PACKAGES_TO_REMOVE[@]}"; do
        { run_as_root apt-get remove -y -qq "$pkg" >/dev/null 2>&1; } || true
    done
    { run_as_root apt-get autoremove -y -qq >/dev/null 2>&1; } || true
    echo "   ✓ 패키지 삭제 완료"
fi

echo ""

# ============================================
# 3. update-alternatives 설정 제거
# ============================================
echo "[3/4] update-alternatives 설정 제거 중..."

# python alternatives 제거
if update-alternatives --display python &>/dev/null; then
    { run_as_root update-alternatives --remove-all python >/dev/null 2>&1; } || true
    echo "   ✓ python alternatives 제거 완료"
else
    echo "   ⚠️  python alternatives가 설정되어 있지 않음"
fi

# pip alternatives 제거
if update-alternatives --display pip &>/dev/null; then
    { run_as_root update-alternatives --remove-all pip >/dev/null 2>&1; } || true
    echo "   ✓ pip alternatives 제거 완료"
else
    echo "   ⚠️  pip alternatives가 설정되어 있지 않음"
fi

echo ""

# ============================================
# 4. deadsnakes PPA 제거
# ============================================
echo "[4/4] deadsnakes PPA 제거 중..."

if grep -r "deadsnakes" /etc/apt/sources.list.d/ >/dev/null 2>&1; then
    { run_as_root add-apt-repository --remove -y ppa:deadsnakes/ppa >/dev/null 2>&1; } || true
    echo "   ✓ deadsnakes PPA 제거 완료"
else
    echo "   ⚠️  deadsnakes PPA가 등록되어 있지 않음"
fi

echo ""
echo "✅ Python 추가 버전 삭제 완료!"
echo ""
echo "📝 참고: 시스템 Python($SYSTEM_PYTHON)은 보존되었습니다."
echo ""
