#!/bin/bash
#
# 02_verify_setup.sh
# Tailscale 설치 확인
#
# 사용법: ./02_verify_setup.sh
#

echo "=========================================="
echo "  Tailscale 설치 확인"
echo "=========================================="

# 가장 중요한 체크: tailscale 명령어가 있는지 확인
if command -v tailscale &> /dev/null; then
    VERSION=$(tailscale version 2>/dev/null | head -1 || echo "unknown")
    echo ""
    echo "✅ Tailscale 설치 확인됨: $VERSION"
    echo ""
    
    # 추가 정보 표시
    echo "📋 추가 정보:"
    
    # 패키지 정보
    if dpkg -l | grep -q "^ii.*tailscale"; then
        PKG_VERSION=$(dpkg -l | grep "^ii.*tailscale" | awk '{print $3}')
        echo "   - 패키지 버전: $PKG_VERSION"
    fi
    
    # 서비스 상태
    if systemctl is-active --quiet tailscaled 2>/dev/null; then
        echo "   - 서비스: 실행 중"
    elif systemctl is-enabled --quiet tailscaled 2>/dev/null; then
        echo "   - 서비스: 활성화됨 (시작 필요)"
    else
        echo "   - 서비스: 확인 불가"
    fi
    
    echo ""
    echo "┌────────────────────────────────────────────────────┐"
    echo "│  ✅ Tailscale 설치 확인 완료!                      │"
    echo "│                                                    │"
    echo "│  다음 단계:                                        │"
    echo "│    sudo tailscale up                               │"
    echo "│                                                    │"
    echo "│  💡 처음 실행 시 tailscale.com에서 인증 필요      │"
    echo "└────────────────────────────────────────────────────┘"
    echo ""
    exit 0
else
    echo ""
    echo "❌ Tailscale이 설치되지 않았습니다."
    echo ""
    echo "설치 스크립트를 다시 실행해주세요."
    exit 1
fi

# 아래 코드는 실행되지 않지만, 이전 로직과의 호환성을 위해 유지
PASS_COUNT=1
FAIL_COUNT=0

if [ $FAIL_COUNT -eq 0 ]; then
    echo "🎉 모든 검증을 통과했습니다!"
    echo ""
    
    # 연결 상태 확인
    if tailscale status &>/dev/null; then
        echo "┌────────────────────────────────────────────────────┐"
        echo "│  📌 Tailscale 연결 상태                            │"
        echo "│                                                    │"
        tailscale status 2>/dev/null | head -5 || echo "│  연결되지 않음 (sudo tailscale up 실행 필요)        │"
        echo "└────────────────────────────────────────────────────┘"
    else
        echo "┌────────────────────────────────────────────────────┐"
        echo "│  📌 Tailscale 사용법                                │"
        echo "│                                                    │"
        echo "│  연결하기:                                          │"
        echo "│    sudo tailscale up                                │"
        echo "│                                                    │"
        echo "│  상태 확인:                                         │"
        echo "│    tailscale status                                 │"
        echo "│                                                    │"
        echo "│  연결 해제:                                         │"
        echo "│    tailscale down                                   │"
        echo "│                                                    │"
        echo "│  💡 처음 실행 시 tailscale.com에서 인증 필요      │"
        echo "└────────────────────────────────────────────────────┘"
    fi
    exit 0
else
    echo "⚠️  일부 검증이 실패했습니다."
    exit 1
fi

