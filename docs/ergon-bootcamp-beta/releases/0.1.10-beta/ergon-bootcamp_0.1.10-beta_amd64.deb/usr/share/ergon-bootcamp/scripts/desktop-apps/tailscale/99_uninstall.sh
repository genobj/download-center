#!/bin/bash
#
# 99_uninstall.sh
# Tailscale 삭제 스크립트
#
# 삭제 항목:
#   - tailscale 패키지
#   - tailscale-archive-keyring 패키지
#   - 저장소 설정 파일
#   - GPG 키링 파일
#   - 데스크톱 파일
#   - 임시 파일 (/tmp/tailscale.desktop)
#
# 사용법: ./99_uninstall.sh
#

set -e

# 환경 변수 설정 (비대화형 모드)
export DEBIAN_FRONTEND=noninteractive
export APT_LISTCHANGES_FRONTEND=none

# sudo 공통 라이브러리 로드
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../../lib/sudo.sh"

# sudo 캐시 확인 (Tauri 앱 환경에서 필수)
if ! ensure_sudo_cache; then
    echo -e "${RED}❌ Sudo cache expired or not found${NC}"
    echo "Please verify your password in the password screen first."
    exit 1
fi

echo "=========================================="
echo "  Tailscale 삭제"
echo "=========================================="
echo ""

# 1. tailscale 패키지 제거
if dpkg -l | grep -q "^ii.*tailscale "; then
    echo "[1/2] Tailscale 패키지 제거 중..."
    run_as_root apt-get remove -y tailscale || true
    echo "   ✓ 패키지 제거 완료"
    echo ""
    
    echo "[2/2] Tailscale 설정 파일 완전 제거 중..."
    run_as_root apt-get purge -y tailscale || true
    echo "   ✓ 설정 파일 제거 완료"
    echo ""
else
    echo "ℹ️  Tailscale 패키지가 설치되어 있지 않습니다."
    echo ""
fi

# 추가 정리: tailscale-archive-keyring 패키지 제거
if dpkg -l | grep -q "^ii.*tailscale-archive-keyring"; then
    echo "[추가] Tailscale 키링 패키지 제거 중..."
    run_as_root apt-get remove -y tailscale-archive-keyring || true
    run_as_root apt-get purge -y tailscale-archive-keyring || true
    echo "   ✓ 키링 패키지 제거 완료"
    echo ""
fi

# 추가 정리: 저장소 파일 제거
if [ -f /etc/apt/sources.list.d/tailscale.list ]; then
    echo "[추가] 저장소 파일 제거 중..."
    run_as_root rm -f /etc/apt/sources.list.d/tailscale.list
    echo "   ✓ 저장소 파일 제거 완료"
    echo ""
fi

# 추가 정리: 키링 파일 제거
if [ -f /usr/share/keyrings/tailscale-archive-keyring.gpg ]; then
    echo "[추가] 키링 파일 제거 중..."
    run_as_root rm -f /usr/share/keyrings/tailscale-archive-keyring.gpg
    echo "   ✓ 키링 파일 제거 완료"
    echo ""
fi

# 추가 정리: 데스크톱 파일 제거
if [ -f /usr/share/applications/tailscale.desktop ]; then
    echo "[추가] 데스크톱 파일 제거 중..."
    run_as_root rm -f /usr/share/applications/tailscale.desktop
    run_as_root update-desktop-database /usr/share/applications/ 2>/dev/null || true
    echo "   ✓ 데스크톱 파일 제거 완료"
    echo ""
fi

# 추가 정리: 임시 파일 제거
if [ -f /tmp/tailscale.desktop ]; then
    echo "[추가] 임시 파일 제거 중..."
    rm -f /tmp/tailscale.desktop 2>/dev/null || run_as_root rm -f /tmp/tailscale.desktop 2>/dev/null || true
    echo "   ✓ 임시 파일 제거 완료"
    echo ""
fi

echo "┌────────────────────────────────────────────────────┐"
echo "│  ✅ Tailscale 삭제 완료!                            │"
echo "│                                                    │"
echo "│  💡 참고:                                          │"
echo "│  - 패키지와 설정 파일이 제거되었습니다              │"
echo "│  - 저장소 및 키링 파일도 정리되었습니다             │"
echo "└────────────────────────────────────────────────────┘"
echo ""
