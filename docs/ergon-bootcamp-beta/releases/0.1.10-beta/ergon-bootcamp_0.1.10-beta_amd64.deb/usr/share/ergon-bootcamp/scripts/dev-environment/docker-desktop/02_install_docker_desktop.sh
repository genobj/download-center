#!/bin/bash
#
# 02_install_docker_desktop.sh
# Docker Desktop for Linux 설치
#
# 사용법: ./02_install_docker_desktop.sh
# 필요한 설정: SUDO_PASSWORD (config.local.env)
# 참조: https://docs.docker.com/desktop/setup/install/linux/ubuntu/
#

set -e

# sudo 공통 라이브러리 로드
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../../lib/sudo.sh"

# sudo 캐시 확인 (Tauri 앱 환경에서 필수)
if ! ensure_sudo_cache; then
    echo -e "${RED}❌ Sudo cache expired or not found${NC}"
    echo "Please verify your password in the password screen first."
    exit 1
fi

echo "=========================================="
echo "  Docker Desktop 설치"
echo "=========================================="

# 환경 변수 설정 (비대화형 모드)
export DEBIAN_FRONTEND=noninteractive
export APT_LISTCHANGES_FRONTEND=none

# Docker Desktop 최신 버전 다운로드
# 참조: https://docs.docker.com/desktop/release-notes/
DOCKER_DESKTOP_DEB="docker-desktop-amd64.deb"
DOWNLOAD_URL="https://desktop.docker.com/linux/main/amd64/docker-desktop-amd64.deb"

# 패키지 상태 확인 (ii=설치됨, rc=삭제됨 설정만 남음)
PKG_STATUS=$(dpkg-query -W -f='${Status}' docker-desktop 2>/dev/null || echo "")

# rc 상태 (삭제됨, 설정 파일만 남음)인 경우 완전히 purge
if echo "$PKG_STATUS" | grep -q "deinstall\|config-files"; then
    echo "[사전 정리] 이전 설치 잔여물 제거 중..."
    { run_as_root dpkg --purge docker-desktop >/dev/null 2>&1; } || true
    { run_as_root apt-get autoremove -y -qq >/dev/null 2>&1; } || true
    echo "   ✓ 잔여물 제거 완료"
    echo ""
    PKG_STATUS=""
fi

# 이미 정상 설치되어 있는지 확인
if echo "$PKG_STATUS" | grep -q "install ok installed"; then
    echo "ℹ️  Docker Desktop이 이미 설치되어 있습니다."
    CURRENT_VERSION=$(docker --version 2>/dev/null || echo "unknown")
    echo "   현재 버전: $CURRENT_VERSION"
    
    # TTY가 없으면 (Tauri 앱 환경) 자동으로 건너뛰기
    if [ ! -t 0 ] || [ ! -t 1 ]; then
        echo "   → 이미 설치되어 있어 건너뜁니다."
        exit 0
    fi
    
    # TTY가 있으면 사용자에게 물어보기
    read -p "업그레이드 하시겠습니까? (y/N): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        echo "설치를 건너뜁니다."
        exit 0
    fi
fi

echo ""
echo "[1/3] Docker Desktop 다운로드 중..."
echo "   URL: $DOWNLOAD_URL"
TEMP_DIR=$(mktemp -d)
cd "$TEMP_DIR"
wget -q --show-progress "$DOWNLOAD_URL" -O "$DOCKER_DESKTOP_DEB"

echo ""
echo "[2/3] Docker Desktop 설치 중..."
echo "   (이 과정은 몇 분 소요될 수 있습니다)"
run_as_root apt-get update
run_as_root apt-get install -y "./$DOCKER_DESKTOP_DEB"

echo ""
echo "[3/4] 임시 파일 정리..."
cd /
rm -rf "$TEMP_DIR"

echo ""
echo "[4/5] docker 그룹에 사용자 추가..."
# docker 그룹이 없으면 생성
if ! getent group docker &>/dev/null; then
    run_as_root groupadd docker
    echo "   ✓ docker 그룹 생성"
fi

# 현재 사용자를 docker 그룹에 추가
REAL_USER="${SUDO_USER:-$USER}"
if ! groups "$REAL_USER" | grep -q docker; then
    run_as_root usermod -aG docker "$REAL_USER"
    echo "   ✓ $REAL_USER 사용자를 docker 그룹에 추가"
    echo "   ⚠️  그룹 변경 적용을 위해 로그아웃 후 다시 로그인하세요!"
else
    echo "   ✓ $REAL_USER 사용자가 이미 docker 그룹에 속해 있음"
fi

echo ""
echo "[5/6] 부팅 시 자동 시작 설정..."
systemctl --user enable docker-desktop 2>/dev/null || true
echo "   ✓ Docker Desktop 자동 시작 설정 완료"

echo ""
echo "[6/6] 데스크톱 데이터베이스 업데이트..."
if command -v update-desktop-database &> /dev/null; then
    { run_as_root update-desktop-database /usr/share/applications/ >/dev/null 2>&1; } || true
    echo "   ✓ 데스크톱 데이터베이스 업데이트 완료"
fi

echo ""
echo "┌────────────────────────────────────────────────────────┐"
echo "│  ✅ Docker Desktop 설치 완료!                          │"
echo "│                                                        │"
echo "│  📌 중요: 다음 단계가 필요합니다                       │"
echo "│                                                        │"
echo "│  1. 로그아웃 후 다시 로그인 (또는 재부팅)              │"
echo "│  2. 앱 메뉴에서 'Docker Desktop' 실행                  │"
echo "│  3. Docker Subscription Service Agreement 동의         │"
echo "│                                                        │"
echo "│  터미널에서 실행:                                      │"
echo "│    systemctl --user start docker-desktop               │"
echo "│                                                        │"
echo "└────────────────────────────────────────────────────────┘"
echo ""

