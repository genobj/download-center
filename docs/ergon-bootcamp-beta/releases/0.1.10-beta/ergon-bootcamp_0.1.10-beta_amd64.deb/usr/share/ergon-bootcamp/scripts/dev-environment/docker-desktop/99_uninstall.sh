#!/bin/bash
#
# 99_uninstall.sh
# 자동 생성된 삭제 스크립트
#

set -e

# root로 실행 중인지 확인
if [ "$EUID" -ne 0 ]; then
    echo "❌ Uninstall must be run as root"
    exit 1
fi

# 환경 변수 설정 (비대화형 모드)
export DEBIAN_FRONTEND=noninteractive
export APT_LISTCHANGES_FRONTEND=none

# PATH 설정 (rustup 등 사용자 설치 도구를 위해)
export PATH="$HOME/.cargo/bin:$PATH"

# sudo 공통 라이브러리 로드 (run_as_root 헬퍼 사용을 위해)
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../../lib/sudo.sh"

echo "=========================================="
echo "  삭제 중..."
echo "=========================================="
echo ""

echo "[1/1] sudo apt remove -y docker-desktop"
sudo apt remove -y docker-desktop
echo ""

echo "✅ 삭제 완료!"
echo ""
