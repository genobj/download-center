#!/bin/bash
#
# 02_install_gh.sh
# GitHub CLI 설치
#
# 설명:
#   - GitHub 공식 리포지토리에서 gh 설치
#   - 브라우저를 통한 인증 안내
#
# 사용법: ./02_install_gh.sh
# 필요한 설정: SUDO_PASSWORD (config.local.env)
#

set -e

# sudo 공통 라이브러리 로드
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../../lib/sudo.sh"

# sudo 캐시 확인 (Tauri 앱 환경에서 필수)
if ! ensure_sudo_cache; then
    echo -e "${RED}❌ Sudo cache expired or not found${NC}"
    echo "Please verify your password in the password screen first."
    exit 1
fi

echo "=========================================="
echo "  GitHub CLI (gh) 설치"
echo "=========================================="
echo ""

# ============================================
# 1. 기존 설치 확인
# ============================================
echo "[1/3] 기존 gh 설치 확인 중..."

if command -v gh &> /dev/null; then
    CURRENT_VERSION=$(gh --version | head -1)
    echo "   ✓ gh가 이미 설치되어 있습니다: ${CURRENT_VERSION}"
    
    # 인증 상태 확인
    echo ""
    echo "[인증 상태 확인]"
    if gh auth status &>/dev/null; then
        echo "   ✓ GitHub 인증 완료됨"
        gh auth status
    else
        echo "   ⚠️  GitHub 인증 필요"
        echo ""
        echo "   다음 명령어로 인증하세요:"
        echo "   gh auth login"
    fi
    exit 0
fi

echo "   → 새로 설치를 진행합니다."
echo ""

# ============================================
# 2. GitHub CLI 리포지토리 추가
# ============================================
echo "[2/3] GitHub CLI 리포지토리 추가 중..."

# 필수 패키지 설치
run_as_root apt-get update -qq
run_as_root apt-get install -y curl gpg

# GitHub CLI GPG 키 추가
run_as_root mkdir -p -m 755 /etc/apt/keyrings
curl -fsSL https://cli.github.com/packages/githubcli-archive-keyring.gpg | run_as_root tee /etc/apt/keyrings/githubcli-archive-keyring.gpg > /dev/null
run_as_root chmod go+r /etc/apt/keyrings/githubcli-archive-keyring.gpg

# 리포지토리 추가
echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/githubcli-archive-keyring.gpg] https://cli.github.com/packages stable main" | run_as_root tee /etc/apt/sources.list.d/github-cli.list > /dev/null

echo "   ✓ GitHub CLI 리포지토리 추가됨"
echo ""

# ============================================
# 3. gh 설치
# ============================================
echo "[3/3] gh 설치 중..."

run_as_root apt-get update -qq
run_as_root apt-get install -y gh

echo "   ✓ gh 설치 완료"
echo ""

# ============================================
# 결과 및 인증 안내
# ============================================
GH_VERSION=$(gh --version | head -1)

echo "┌────────────────────────────────────────┐"
echo "│  설치 완료                              │"
echo "├────────────────────────────────────────┤"
printf "│  %-36s │\n" "$GH_VERSION"
echo "└────────────────────────────────────────┘"
echo ""

echo "✅ GitHub CLI 설치 완료!"
echo ""
echo "┌────────────────────────────────────────────────────┐"
echo "│  🔐 GitHub 인증 방법                               │"
echo "├────────────────────────────────────────────────────┤"
echo "│                                                    │"
echo "│  다음 명령어를 실행하세요:                         │"
echo "│                                                    │"
echo "│    gh auth login                                   │"
echo "│                                                    │"
echo "│  선택 옵션:                                        │"
echo "│    1. GitHub.com                                   │"
echo "│    2. HTTPS                                        │"
echo "│    3. Login with a web browser                     │"
echo "│                                                    │"
echo "│  브라우저가 열리면 GitHub에 로그인하세요.          │"
echo "│                                                    │"
echo "└────────────────────────────────────────────────────┘"
echo ""
echo "다음 단계: ./02_configure_git.sh"
echo ""


