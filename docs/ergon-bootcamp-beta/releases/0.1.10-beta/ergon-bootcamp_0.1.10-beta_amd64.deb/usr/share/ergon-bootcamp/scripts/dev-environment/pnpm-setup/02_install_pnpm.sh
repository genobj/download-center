#!/bin/bash
#
# 02_install_pnpm.sh
# pnpm 설치
#
# 설명:
#   - corepack을 통해 pnpm 활성화 (권장)
#   - 또는 standalone 스크립트로 설치
#
# 사용법: ./02_install_pnpm.sh
#

set -e

# sudo 공통 라이브러리 로드
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../../lib/sudo.sh"

# sudo 캐시 확인 (Tauri 앱 환경에서 필수)
if ! ensure_sudo_cache; then
    echo -e "${RED}❌ Sudo cache expired or not found${NC}"
    echo "Please verify your password in the password screen first."
    exit 1
fi

# sudo로 실행될 때 실제 사용자 홈 디렉토리 찾기
if [ -n "$SUDO_USER" ]; then
    REAL_HOME=$(getent passwd "$SUDO_USER" | cut -d: -f6)
else
    REAL_HOME="$HOME"
fi

echo "=========================================="
echo "  pnpm 설치"
echo "=========================================="
echo ""

# ============================================
# 1. Node.js 확인
# ============================================
echo "[1/4] Node.js 확인 중..."

if ! command -v node &> /dev/null; then
    echo "❌ Node.js가 설치되어 있지 않습니다."
    echo "   먼저 ./01_install_node.sh 를 실행하세요."
    exit 1
fi

NODE_VERSION=$(node --version)
echo "   ✓ Node.js ${NODE_VERSION} 확인됨"
echo ""

# ============================================
# 2. pnpm 설치 (corepack 사용)
# ============================================
echo "[2/4] pnpm 설치 중..."

# corepack 활성화 (Node.js 16.9+에 내장)
if command -v corepack &> /dev/null; then
    echo "   → corepack을 통해 pnpm 활성화 중..."
    
    # sudo 권한으로 corepack 활성화 (시스템 전역)
    run_as_root corepack enable
    
    # pnpm 활성화
    corepack prepare pnpm@latest --activate 2>/dev/null || run_as_root corepack prepare pnpm@latest --activate
    
    echo "   ✓ corepack으로 pnpm 활성화 완료"
else
    echo "   → standalone 스크립트로 pnpm 설치 중..."
    
    # standalone 설치
    curl -fsSL https://get.pnpm.io/install.sh | sh -
    
    # PATH 설정
    export PNPM_HOME="$REAL_HOME/.local/share/pnpm"
    export PATH="$PNPM_HOME:$PATH"
    
    echo "   ✓ standalone으로 pnpm 설치 완료"
fi

echo ""

# ============================================
# 3. 환경 변수 설정
# ============================================
echo "[3/4] 환경 변수 설정 중..."

PNPM_HOME="$REAL_HOME/.local/share/pnpm"
SHELL_RC=""

# 쉘 설정 파일 확인
if [[ -f "$REAL_HOME/.zshrc" ]]; then
    SHELL_RC="$REAL_HOME/.zshrc"
elif [[ -f "$REAL_HOME/.bashrc" ]]; then
    SHELL_RC="$REAL_HOME/.bashrc"
fi

if [[ -n "$SHELL_RC" ]]; then
    # 이미 설정되어 있는지 확인
    if ! grep -q "PNPM_HOME" "$SHELL_RC"; then
        echo "" >> "$SHELL_RC"
        echo "# pnpm" >> "$SHELL_RC"
        echo "export PNPM_HOME=\"$PNPM_HOME\"" >> "$SHELL_RC"
        echo 'case ":$PATH:" in' >> "$SHELL_RC"
        echo '  *":$PNPM_HOME:"*) ;;' >> "$SHELL_RC"
        echo '  *) export PATH="$PNPM_HOME:$PATH" ;;' >> "$SHELL_RC"
        echo 'esac' >> "$SHELL_RC"
        echo "   ✓ $SHELL_RC에 PNPM_HOME 추가됨"
    else
        echo "   ✓ PNPM_HOME 이미 설정됨"
    fi
fi

# 현재 세션에 적용
export PNPM_HOME="$PNPM_HOME"
export PATH="$PNPM_HOME:$PATH"

echo ""

# ============================================
# 4. 설치 검증
# ============================================
echo "[4/4] 설치 검증 중..."

# pnpm 명령어 확인
if ! command -v pnpm &> /dev/null; then
    echo "   ❌ pnpm 설치 실패: pnpm 명령어를 찾을 수 없습니다."
    echo ""
    echo "   수동 설치 방법:"
    echo "   curl -fsSL https://get.pnpm.io/install.sh | sh -"
    exit 1
fi

PNPM_VERSION=$(pnpm --version)
echo "   ✓ pnpm v${PNPM_VERSION} 설치 확인됨"
echo ""

# ============================================
# 결과 확인
# ============================================
echo "┌────────────────────────────────────────┐"
echo "│  ✅ 설치 완료                           │"
echo "├────────────────────────────────────────┤"
printf "│  pnpm: v%-29s │\n" "$PNPM_VERSION"
printf "│  Node.js: %-27s │\n" "$(node --version)"
echo "└────────────────────────────────────────┘"
echo ""

echo "💡 새 터미널을 열거나 다음 명령어를 실행하세요:"
echo "   source $SHELL_RC"
echo ""
