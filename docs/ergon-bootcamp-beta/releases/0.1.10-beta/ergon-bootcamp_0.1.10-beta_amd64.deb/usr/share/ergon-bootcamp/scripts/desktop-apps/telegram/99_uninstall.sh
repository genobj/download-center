#!/bin/bash
#
# 99_uninstall.sh
# Telegram Desktop 삭제 스크립트
#

set -e

APP_ID="org.telegram.desktop"
APP_NAME="Telegram Desktop"

# sudo로 실행될 때 실제 사용자 홈 디렉토리 찾기
if [ -n "$SUDO_USER" ]; then
    REAL_HOME=$(getent passwd "$SUDO_USER" | cut -d: -f6)
else
    REAL_HOME="$HOME"
fi

echo "=========================================="
echo "  $APP_NAME 삭제 중..."
echo "=========================================="
echo ""

# ============================================
# 1. Flatpak 앱 삭제
# ============================================
echo "[1/2] Flatpak 앱 삭제..."

if flatpak list | grep -q "$APP_ID"; then
    flatpak uninstall -y "$APP_ID"
    echo "   ✓ Flatpak 앱 삭제 완료"
else
    echo "   ⚠️  Flatpak 앱이 설치되어 있지 않음"
fi

echo ""

# ============================================
# 2. 사용자 로컬 파일 정리
# ============================================
echo "[2/2] 사용자 설정 파일 정리..."

# 로컬 .desktop 파일 삭제
LOCAL_DESKTOP="$REAL_HOME/.local/share/applications/org.telegram.desktop.desktop"
if [ -f "$LOCAL_DESKTOP" ]; then
    rm -f "$LOCAL_DESKTOP"
    echo "   ✓ 로컬 데스크톱 파일 삭제: $LOCAL_DESKTOP"
fi

# DBus 서비스 심볼릭 링크 삭제
LOCAL_DBUS="$REAL_HOME/.local/share/dbus-1/services/org.telegram.desktop.service"
if [ -L "$LOCAL_DBUS" ] || [ -f "$LOCAL_DBUS" ]; then
    rm -f "$LOCAL_DBUS"
    echo "   ✓ DBus 서비스 링크 삭제"
fi

# 데스크톱 데이터베이스 업데이트
if command -v update-desktop-database &> /dev/null; then
    update-desktop-database "$REAL_HOME/.local/share/applications/" 2>/dev/null || true
fi

echo ""
echo "✅ $APP_NAME 삭제 완료!"
echo ""
