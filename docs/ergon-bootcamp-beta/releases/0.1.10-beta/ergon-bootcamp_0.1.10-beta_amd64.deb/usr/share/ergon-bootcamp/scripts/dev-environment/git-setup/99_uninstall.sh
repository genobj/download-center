#!/bin/bash
#
# 99_uninstall.sh
# Git & GitHub CLI 삭제 스크립트
#

set -e

# 환경 변수 설정 (비대화형 모드)
export DEBIAN_FRONTEND=noninteractive
export APT_LISTCHANGES_FRONTEND=none

# sudo로 실행될 때 실제 사용자 홈 디렉토리 찾기
if [ -n "$SUDO_USER" ]; then
    REAL_HOME=$(getent passwd "$SUDO_USER" | cut -d: -f6)
else
    REAL_HOME="$HOME"
fi

# PATH 설정
export PATH="$REAL_HOME/.cargo/bin:$PATH"

# sudo 캐시 확인 (만료되었으면 에러)
if ! sudo -n -v 2>/dev/null; then
    echo "❌ Sudo cache expired. Please verify your password first."
    exit 1
fi

# sudo 공통 라이브러리 로드
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../../lib/sudo.sh"

echo "=========================================="
echo "  Git & GitHub CLI 삭제"
echo "=========================================="
echo ""

# ============================================
# 1. GitHub CLI (gh) 삭제
# ============================================
echo "[1/2] GitHub CLI (gh) 삭제 중..."

if command -v gh &> /dev/null; then
    # gh 인증 로그아웃
    gh auth logout --hostname github.com 2>/dev/null || true
    
    # gh 패키지 삭제
    run_as_root apt-get remove -y gh || true
    run_as_root apt-get purge -y gh || true
    
    # GitHub CLI 리포지토리 제거
    run_as_root rm -f /etc/apt/sources.list.d/github-cli.list || true
    run_as_root rm -f /etc/apt/keyrings/githubcli-archive-keyring.gpg || true
    
    echo "   ✓ GitHub CLI 삭제 완료"
else
    echo "   ⚠️  GitHub CLI가 설치되어 있지 않음"
fi

echo ""

# ============================================
# 2. Git 설정 초기화
# ============================================
echo "[2/2] Git 설정 초기화 중..."

# 실제 사용자의 .gitconfig 파일 경로
GITCONFIG_FILE="$REAL_HOME/.gitconfig"

if [ -f "$GITCONFIG_FILE" ]; then
    # 실제 사용자로 git config 실행
    if [ -n "$SUDO_USER" ]; then
        # sudo 환경: 실제 사용자로 명령 실행
        sudo -u "$SUDO_USER" git config --global --unset user.name 2>/dev/null || true
        sudo -u "$SUDO_USER" git config --global --unset user.email 2>/dev/null || true
        sudo -u "$SUDO_USER" git config --global --unset init.defaultBranch 2>/dev/null || true
        sudo -u "$SUDO_USER" git config --global --unset core.editor 2>/dev/null || true
        sudo -u "$SUDO_USER" git config --global --unset core.autocrlf 2>/dev/null || true
        sudo -u "$SUDO_USER" git config --global --unset pull.rebase 2>/dev/null || true
        sudo -u "$SUDO_USER" git config --global --unset push.autoSetupRemote 2>/dev/null || true
        sudo -u "$SUDO_USER" git config --global --unset color.ui 2>/dev/null || true
    else
        # 일반 환경
        git config --global --unset user.name 2>/dev/null || true
        git config --global --unset user.email 2>/dev/null || true
        git config --global --unset init.defaultBranch 2>/dev/null || true
        git config --global --unset core.editor 2>/dev/null || true
        git config --global --unset core.autocrlf 2>/dev/null || true
        git config --global --unset pull.rebase 2>/dev/null || true
        git config --global --unset push.autoSetupRemote 2>/dev/null || true
        git config --global --unset color.ui 2>/dev/null || true
    fi
    echo "   ✓ user.name, user.email 제거"
    echo "   ✓ Git 기본 설정 제거"
else
    echo "   ⚠️  .gitconfig 파일이 없음"
fi

echo ""
echo "✅ Git & GitHub CLI 삭제 완료!"
echo ""
echo "ℹ️  참고: git 자체는 시스템 패키지이므로 삭제하지 않습니다."
echo ""
