#!/bin/bash
#
# 99_uninstall.sh
# Cursor AI 삭제 스크립트
#
# 사용법: ./99_uninstall.sh
#

set -e

# 환경 변수 설정 (비대화형 모드)
export DEBIAN_FRONTEND=noninteractive
export APT_LISTCHANGES_FRONTEND=none

# sudo로 실행될 때 실제 사용자 홈 디렉토리 찾기
if [ -n "$SUDO_USER" ]; then
    REAL_HOME=$(getent passwd "$SUDO_USER" | cut -d: -f6)
else
    REAL_HOME="$HOME"
fi

# PATH 설정
export PATH="$REAL_HOME/.cargo/bin:$PATH"

# sudo 공통 라이브러리 로드
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../../lib/sudo.sh"

# sudo 캐시 확인 (Tauri 앱 환경에서 필수)
if ! ensure_sudo_cache; then
    echo -e "${RED}❌ Sudo cache expired or not found${NC}"
    echo "Please verify your password in the password screen first."
    exit 1
fi

echo "=========================================="
echo "  Cursor AI 삭제"
echo "=========================================="
echo ""

# Cursor 패키지가 설치되어 있는지 확인
if dpkg -l | grep -q "^ii  cursor "; then
    echo "[1/2] Cursor AI 패키지 제거 중..."
    run_as_root apt-get remove -y cursor || true
    echo "   ✓ 패키지 제거 완료"
    echo ""
    
    echo "[2/2] Cursor AI 설정 파일 완전 제거 중..."
    run_as_root apt-get purge -y cursor || true
    echo "   ✓ 설정 파일 제거 완료"
    echo ""
else
    echo "ℹ️  Cursor AI 패키지가 설치되어 있지 않습니다."
    echo ""
fi

# 사용자 디렉토리의 cursor 관련 파일 제거 (선택적)
if [ -d "$REAL_HOME/.local/share/cursor" ]; then
    echo "[추가] 사용자 디렉토리의 cursor 파일 제거 중..."
    rm -rf "$REAL_HOME/.local/share/cursor"
    echo "   ✓ 사용자 디렉토리 정리 완료"
    echo ""
fi

if [ -d "$REAL_HOME/Applications/cursor" ]; then
    echo "[추가] Applications 디렉토리의 cursor 파일 제거 중..."
    rm -rf "$REAL_HOME/Applications/cursor"
    echo "   ✓ Applications 디렉토리 정리 완료"
    echo ""
fi

# 데스크톱 파일 제거 (선택적)
if [ -f "$REAL_HOME/.local/share/applications/cursor.desktop" ]; then
    echo "[추가] 데스크톱 파일 제거 중..."
    rm -f "$REAL_HOME/.local/share/applications/cursor.desktop"
    echo "   ✓ 데스크톱 파일 제거 완료"
    echo ""
fi

# 데스크톱 데이터베이스 업데이트
if command -v update-desktop-database &> /dev/null; then
    update-desktop-database "$REAL_HOME/.local/share/applications/" 2>/dev/null || true
fi

echo "┌────────────────────────────────────────────────────┐"
echo "│  ✅ Cursor AI 삭제 완료!                            │"
echo "│                                                    │"
echo "│  💡 참고:                                          │"
echo "│  - 패키지와 설정 파일이 제거되었습니다              │"
echo "│  - 사용자 디렉토리의 파일도 정리되었습니다           │"
echo "└────────────────────────────────────────────────────┘"
echo ""
