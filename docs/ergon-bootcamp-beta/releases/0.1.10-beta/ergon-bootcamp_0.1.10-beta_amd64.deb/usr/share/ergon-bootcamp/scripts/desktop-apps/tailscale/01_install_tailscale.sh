#!/bin/bash
#
# 01_install_tailscale.sh
# Tailscale VPN 설치
#
# 설명:
#   - Tailscale 공식 설치 스크립트 실행
#   - tailscaled 서비스 활성화
#   - 데스크톱 파일 생성 (앱 메뉴에서 실행 가능)
#
# 사용법: ./01_install_tailscale.sh
# 필요한 설정: SUDO_PASSWORD (config.local.env)
#

set -e

# sudo 공통 라이브러리 로드
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../../lib/sudo.sh"

# sudo 캐시 확인 (Tauri 앱 환경에서 필수)
if ! ensure_sudo_cache; then
    echo -e "${RED}❌ Sudo cache expired or not found${NC}"
    echo "Please verify your password in the password screen first."
    exit 1
fi

echo "=========================================="
echo "  Tailscale VPN 설치"
echo "=========================================="

# 이미 설치되어 있는지 확인
if command -v tailscale &> /dev/null; then
    CURRENT_VERSION=$(tailscale version 2>/dev/null | head -1 || echo "unknown")
    echo "ℹ️  Tailscale이 이미 설치되어 있습니다: $CURRENT_VERSION"
    
    # TTY가 있으면 사용자에게 물어봄, 없으면 재설치 진행 (Tauri 앱 환경)
    if [ -t 0 ] && [ -t 1 ]; then
        read -p "재설치 하시겠습니까? (y/N): " -n 1 -r
        echo
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            echo "설치를 건너뜁니다."
            exit 0
        fi
    else
        echo "   → Tauri 앱 환경에서 자동으로 재설치를 진행합니다."
    fi
fi

# Ubuntu 버전 확인 및 코드명 매핑
if [ -f /etc/os-release ]; then
    . /etc/os-release
    UBUNTU_CODENAME=$(lsb_release -cs 2>/dev/null || echo "")
    
    # Ubuntu 버전에 따른 코드명 확인
    if [ -z "$UBUNTU_CODENAME" ]; then
        UBUNTU_VERSION=$(lsb_release -rs 2>/dev/null || echo "")
        case "$UBUNTU_VERSION" in
            20.04) UBUNTU_CODENAME="focal" ;;
            22.04) UBUNTU_CODENAME="jammy" ;;
            24.04) UBUNTU_CODENAME="noble" ;;
            *) UBUNTU_CODENAME="jammy" ;;  # 기본값
        esac
    fi
else
    UBUNTU_CODENAME="jammy"  # 기본값
fi

echo "📋 Ubuntu 코드명: $UBUNTU_CODENAME"
echo ""

# Tailscale 공식 설치 스크립트 사용 (가장 안정적)
echo "[1/4] Tailscale 공식 설치 스크립트 실행 중..."
echo "   → Tailscale 공식 설치 스크립트 다운로드 및 실행..."

# curl이 없으면 설치
if ! command -v curl &> /dev/null; then
    run_as_root apt update -qq
    run_as_root apt install -y curl
fi

# Tailscale 공식 설치 스크립트 실행
# -s: silent mode, -S: show errors
curl -fsSL https://tailscale.com/install.sh | run_as_root sh

echo ""
echo "[2/4] Tailscale 서비스 상태 확인..."
if systemctl is-active --quiet tailscaled 2>/dev/null; then
    echo "   ✅ Tailscale 서비스 실행 중"
else
    echo "   ℹ️  Tailscale 서비스 시작 중..."
    run_as_root systemctl enable --now tailscaled 2>/dev/null || true
fi

echo ""
echo "[3/4] 설치 확인 중..."
if command -v tailscale &> /dev/null; then
    INSTALLED_VERSION=$(tailscale version 2>/dev/null | head -1 || echo "unknown")
    echo "   ✅ Tailscale 설치 완료: $INSTALLED_VERSION"
else
    echo "   ⚠️  Tailscale 명령어를 찾을 수 없습니다. 설치를 다시 시도해주세요."
    exit 1
fi

echo ""
echo "[4/4] 데스크톱 파일 생성 중..."
DESKTOP_FILE="/usr/share/applications/tailscale.desktop"

# 임시 파일 정리 후 생성
rm -f /tmp/tailscale.desktop 2>/dev/null || run_as_root rm -f /tmp/tailscale.desktop 2>/dev/null || true
cat > /tmp/tailscale.desktop << 'EOF'
[Desktop Entry]
Version=1.0
Type=Application
Name=Tailscale
Name[ko]=Tailscale
Comment=Zero-config VPN for secure network connections
Comment[ko]=제로 설정 VPN으로 안전한 네트워크 연결
Exec=bash -c 'tailscale status; echo ""; read -p "Press Enter to exit..."'
Icon=network-vpn
Terminal=true
Categories=Network;VPN;
Keywords=vpn;network;tailscale;wireguard;
EOF
run_as_root mv /tmp/tailscale.desktop "$DESKTOP_FILE"
run_as_root chmod 644 "$DESKTOP_FILE"
run_as_root update-desktop-database /usr/share/applications/ 2>/dev/null || true
echo "   ✅ 데스크톱 파일 생성 완료"

echo ""
echo "┌────────────────────────────────────────────────────┐"
echo "│  ✅ Tailscale 설치 완료!                          │"
echo "└────────────────────────────────────────────────────┘"
echo ""
echo "⚠️  중요: Tailscale을 사용하려면 터미널에서 로그인이 필요합니다!"
echo ""
echo "   터미널을 열고 다음 명령을 실행하세요:"
echo ""
echo "   sudo tailscale up"
echo ""
echo "   → 인증 URL이 표시되면 브라우저에서 열어 로그인하세요."
echo "   → 같은 계정으로 로그인한 모든 기기가 자동으로 연결됩니다."
echo ""
echo "┌────────────────────────────────────────────────────┐"
echo "│  💡 유용한 명령어:                                 │"
echo "│  - tailscale status : 연결된 기기 목록 확인       │"
echo "│  - tailscale down   : VPN 연결 해제               │"
echo "│  - tailscale up     : VPN 다시 연결               │"
echo "└────────────────────────────────────────────────────┘"
echo ""

