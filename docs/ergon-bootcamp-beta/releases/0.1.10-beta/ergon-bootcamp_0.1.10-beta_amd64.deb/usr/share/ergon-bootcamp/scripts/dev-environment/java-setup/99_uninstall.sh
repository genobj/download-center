#!/bin/bash
#
# 99_uninstall.sh
# Java 개발 환경 삭제 스크립트
#

set -e

# 환경 변수 설정 (비대화형 모드)
export DEBIAN_FRONTEND=noninteractive
export APT_LISTCHANGES_FRONTEND=none

# sudo 캐시 확인 (만료되었으면 에러)
if ! sudo -n -v 2>/dev/null; then
    echo "❌ Sudo cache expired. Please verify your password first."
    exit 1
fi

# sudo 공통 라이브러리 로드
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../../lib/sudo.sh"

echo "=========================================="
echo "  Java 개발 환경 삭제"
echo "=========================================="
echo ""

# ============================================
# 1. OpenJDK 21 패키지 삭제
# ============================================
echo "[1/3] OpenJDK 21 패키지 삭제 중..."

JAVA_PACKAGES=(
    "openjdk-21-jdk"
    "openjdk-21-jre"
    "openjdk-21-jre-headless"
    "openjdk-21-doc"
)

for pkg in "${JAVA_PACKAGES[@]}"; do
    PKG_STATUS=$(dpkg-query -W -f='${Status}' "$pkg" 2>/dev/null || echo "")
    if echo "$PKG_STATUS" | grep -q "install ok installed"; then
        { run_as_root apt-get remove -y -qq "$pkg" >/dev/null 2>&1; } || true
        echo "   ✓ $pkg 삭제"
    fi
done

{ run_as_root apt-get autoremove -y -qq >/dev/null 2>&1; } || true
echo "   ✓ 패키지 삭제 완료"
echo ""

# ============================================
# 2. JAVA_HOME 환경 변수 제거
# ============================================
echo "[2/3] JAVA_HOME 환경 변수 제거 중..."

if grep -q "JAVA_HOME=" /etc/environment 2>/dev/null; then
    { run_as_root sed -i '/JAVA_HOME=/d' /etc/environment; } || true
    echo "   ✓ /etc/environment에서 JAVA_HOME 제거"
else
    echo "   ⚠️  JAVA_HOME이 설정되어 있지 않음"
fi

echo ""

# ============================================
# 3. 잔여 디렉토리 정리
# ============================================
echo "[3/3] 잔여 디렉토리 정리 중..."

# Java 디렉토리가 비어있으면 삭제
if [ -d "/usr/lib/jvm/java-21-openjdk-amd64" ]; then
    # 디렉토리 내용이 거의 비어있는지 확인
    FILE_COUNT=$(find /usr/lib/jvm/java-21-openjdk-amd64 -type f 2>/dev/null | wc -l)
    if [ "$FILE_COUNT" -lt 5 ]; then
        { run_as_root rm -rf /usr/lib/jvm/java-21-openjdk-amd64 >/dev/null 2>&1; } || true
        echo "   ✓ /usr/lib/jvm/java-21-openjdk-amd64 제거"
    else
        echo "   ⚠️  Java 디렉토리에 파일이 남아있음 (수동 확인 필요)"
    fi
else
    echo "   ✓ Java 디렉토리가 이미 없음"
fi

echo ""
echo "✅ Java 개발 환경 삭제 완료!"
echo ""
