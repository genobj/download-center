#!/bin/bash
#
# 99_uninstall.sh
# Prerequisites 삭제 스크립트
#
# 주의: 이 스크립트는 시스템 기본 패키지를 삭제하므로 주의해서 사용하세요.
#

set -e

# 환경 변수 설정 (비대화형 모드)
export DEBIAN_FRONTEND=noninteractive
export APT_LISTCHANGES_FRONTEND=none

# sudo 캐시 확인 (만료되었으면 에러)
if ! sudo -n -v 2>/dev/null; then
    echo "❌ Sudo cache expired. Please verify your password first."
    exit 1
fi

# sudo 공통 라이브러리 로드 (캐시가 유효한 경우에만)
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../../lib/sudo.sh"

echo "=========================================="
echo "  Prerequisites 삭제"
echo "=========================================="
echo ""

# 삭제할 패키지 목록 (시스템 기본 패키지는 제외)
# 주의: build-essential, libssl-dev 등은 다른 프로그램에서 필요할 수 있음
PACKAGES=(
    "infisical"
)

# Infisical 삭제
echo "[1/2] Infisical CLI 삭제 중..."
if dpkg -l infisical &>/dev/null; then
    run_as_root apt remove -y infisical
    echo "   ✅ Infisical CLI 삭제됨"
else
    echo "   ℹ️  Infisical CLI가 설치되어 있지 않음"
fi

# Infisical 저장소 삭제
echo "[2/3] Infisical 저장소 삭제 중..."
if [ -f /etc/apt/sources.list.d/infisical-infisical-cli.list ]; then
    run_as_root rm -f /etc/apt/sources.list.d/infisical-infisical-cli.list
    echo "   ✅ Infisical 저장소 삭제됨"
else
    echo "   ℹ️  Infisical 저장소가 설정되어 있지 않음"
fi

# Polkit 정책 파일 삭제
echo "[3/3] Polkit 정책 파일 삭제 중..."
POLICY_FILE="/usr/share/polkit-1/actions/com.ergon.bootcamp.policy"
if [ -f "$POLICY_FILE" ]; then
    run_as_root rm -f "$POLICY_FILE"
    echo "   ✅ Polkit 정책 파일 삭제됨"
    echo "   위치: $POLICY_FILE"
else
    echo "   ℹ️  Polkit 정책 파일이 설치되어 있지 않음"
fi

echo ""
echo "⚠️  참고: build-essential, libssl-dev 등 기본 패키지는"
echo "   다른 프로그램에서 필요할 수 있어 삭제하지 않았습니다."
echo ""
echo "✅ 삭제 완료!"
echo ""
