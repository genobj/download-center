#!/bin/bash
#
# 03_verify_setup.sh
# pnpm 설치 검증 스크립트
#
# 설명:
#   - Node.js, pnpm 설치 확인
#   - 프로젝트 생성/설치 테스트
#
# 사용법: ./03_verify_setup.sh
#

echo "=========================================="
echo "  pnpm 설치 검증"
echo "=========================================="
echo ""

PASS_COUNT=0
FAIL_COUNT=0
WARN_COUNT=0

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

pass() {
    echo -e "${GREEN}✓ PASS${NC}: $1"
    PASS_COUNT=$((PASS_COUNT + 1))
}

fail() {
    echo -e "${RED}✗ FAIL${NC}: $1"
    FAIL_COUNT=$((FAIL_COUNT + 1))
}

warn() {
    echo -e "${YELLOW}⚠ WARN${NC}: $1"
    WARN_COUNT=$((WARN_COUNT + 1))
}

# ============================================
# 1. 기본 명령어 확인
# ============================================
echo "┌────────────────────────────────────────┐"
echo "│  1. 기본 명령어 확인                   │"
echo "└────────────────────────────────────────┘"

if command -v node &> /dev/null; then
    VERSION=$(node --version)
    pass "node 설치됨 ($VERSION)"
else
    fail "node 미설치"
fi

if command -v npm &> /dev/null; then
    VERSION=$(npm --version)
    pass "npm 설치됨 (v$VERSION)"
else
    fail "npm 미설치"
fi

if command -v pnpm &> /dev/null; then
    VERSION=$(pnpm --version)
    pass "pnpm 설치됨 (v$VERSION)"
else
    fail "pnpm 미설치"
fi

echo ""

# ============================================
# 2. 프로젝트 테스트
# ============================================
echo "┌────────────────────────────────────────┐"
echo "│  2. 프로젝트 테스트                    │"
echo "└────────────────────────────────────────┘"

if command -v pnpm &> /dev/null; then
    TEMP_DIR=$(mktemp -d)
    cd "$TEMP_DIR"
    
    # 환경 변수 확인 및 설정 (Tauri 앱에서 실행 시 필요)
    if [[ -z "$PNPM_HOME" ]]; then
        PNPM_HOME="$HOME/.local/share/pnpm"
    fi
    if [[ ":$PATH:" != *":$PNPM_HOME:"* ]]; then
        export PATH="$PNPM_HOME:$PATH"
    fi
    
    # 환경 변수 확인 및 설정 (Tauri 앱에서 실행 시 필요)
    if [[ -z "$PNPM_HOME" ]]; then
        PNPM_HOME="$HOME/.local/share/pnpm"
    fi
    if [[ ":$PATH:" != *":$PNPM_HOME:"* ]]; then
        export PATH="$PNPM_HOME:$PATH"
    fi
    
    # pnpm init 테스트 (pnpm init은 -y 옵션을 지원하지 않음)
    # 에러 메시지를 확인할 수 있도록 stderr를 캡처
    INIT_OUTPUT=$(pnpm init 2>&1)
    INIT_EXIT=$?
    if [[ $INIT_EXIT -eq 0 ]]; then
        pass "pnpm init 작동"
        
        # 패키지 설치 테스트
        if pnpm add lodash --silent 2>&1 >/dev/null; then
            pass "pnpm add 작동 (lodash 설치)"
            
            # node_modules 확인
            if [[ -d "node_modules/lodash" ]]; then
                pass "node_modules 생성됨"
            else
                fail "node_modules 미생성"
            fi
            
            # pnpm-lock.yaml 확인
            if [[ -f "pnpm-lock.yaml" ]]; then
                pass "pnpm-lock.yaml 생성됨"
            else
                warn "pnpm-lock.yaml 미생성"
            fi
        else
            fail "pnpm add 실패"
        fi
    else
        # pnpm init 실패 시 상세 에러 메시지 출력
        fail "pnpm init 실패: $INIT_OUTPUT"
    fi
    
    # 정리
    cd /
    rm -rf "$TEMP_DIR"
else
    warn "pnpm 없어서 프로젝트 테스트 스킵"
fi

echo ""

# ============================================
# 3. 환경 변수 확인
# ============================================
echo "┌────────────────────────────────────────┐"
echo "│  3. 환경 변수 확인                     │"
echo "└────────────────────────────────────────┘"

PNPM_HOME="${PNPM_HOME:-$HOME/.local/share/pnpm}"

if [[ -n "$PNPM_HOME" ]]; then
    pass "PNPM_HOME 설정됨 ($PNPM_HOME)"
else
    warn "PNPM_HOME 미설정"
fi

if echo "$PATH" | grep -q "pnpm"; then
    pass "PATH에 pnpm 포함됨"
else
    warn "PATH에 pnpm 미포함"
fi

echo ""

# ============================================
# 4. 글로벌 패키지 테스트
# ============================================
echo "┌────────────────────────────────────────┐"
echo "│  4. 글로벌 설치 테스트                 │"
echo "└────────────────────────────────────────┘"

if command -v pnpm &> /dev/null; then
    # 글로벌 bin 디렉토리 확인
    GLOBAL_DIR=$(pnpm root -g 2>/dev/null || echo "")
    if [[ -n "$GLOBAL_DIR" ]]; then
        pass "글로벌 디렉토리 확인 ($GLOBAL_DIR)"
    else
        warn "글로벌 디렉토리 확인 실패"
    fi
fi

echo ""

# ============================================
# 5. Boot Camp 프로젝트 의존성 설치 (선택적)
# ============================================
echo "┌────────────────────────────────────────┐"
echo "│  5. Boot Camp 프로젝트 설정            │"
echo "└────────────────────────────────────────┘"

# 스크립트 디렉토리에서 boot-camp 프로젝트 찾기
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# scripts/dev-environment/pnpm-setup -> ../../.. -> boot-camp 루트
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../../.." && pwd)"
BOOT_CAMP_TAURI_DIR="$PROJECT_ROOT/apps/ergon-bootcamp-tauri"

if [[ -f "$BOOT_CAMP_TAURI_DIR/package.json" ]]; then
    echo "   → Boot Camp Tauri 프로젝트 발견: $BOOT_CAMP_TAURI_DIR"
    
    # pnpm 명령어 확인
    if command -v pnpm &> /dev/null; then
        # 환경 변수 설정 (Tauri 앱에서 실행 시 필요)
        if [[ -z "$PNPM_HOME" ]]; then
            PNPM_HOME="$HOME/.local/share/pnpm"
        fi
        if [[ ":$PATH:" != *":$PNPM_HOME:"* ]]; then
            export PATH="$PNPM_HOME:$PATH"
        fi
        
        cd "$BOOT_CAMP_TAURI_DIR"
        
        # node_modules 확인
        if [[ -d "node_modules" ]]; then
            warn "node_modules가 이미 존재합니다 (건너뜀)"
            echo "   💡 재설치하려면: cd $BOOT_CAMP_TAURI_DIR && pnpm install"
        else
            echo "   → pnpm install 실행 중..."
            # pnpm install 실행 (에러 발생해도 스크립트는 계속 진행)
            if pnpm install 2>&1; then
                if [[ -d "node_modules" ]]; then
                    pass "Boot Camp 프로젝트 의존성 설치 완료"
                else
                    warn "Boot Camp 프로젝트 의존성 설치 완료했지만 node_modules 미확인"
                fi
            else
                INSTALL_EXIT=$?
                if [[ -d "node_modules" ]]; then
                    warn "Boot Camp 프로젝트 의존성 설치 중 일부 에러 발생 (node_modules는 생성됨)"
                else
                    warn "Boot Camp 프로젝트 의존성 설치 실패 (exit code: $INSTALL_EXIT)"
                    echo "   💡 수동 설치: cd $BOOT_CAMP_TAURI_DIR && pnpm install"
                fi
            fi
        fi
    else
        warn "pnpm이 없어서 Boot Camp 프로젝트 설치 스킵"
    fi
else
    warn "Boot Camp Tauri 프로젝트를 찾을 수 없습니다 (선택적 단계)"
    echo "   경로: $BOOT_CAMP_TAURI_DIR"
fi

echo ""

# ============================================
# 결과 요약
# ============================================
echo "=========================================="
echo "  검증 결과 요약"
echo "=========================================="
echo ""
echo -e "  ${GREEN}✓ PASS${NC}: ${PASS_COUNT}"
echo -e "  ${YELLOW}⚠ WARN${NC}: ${WARN_COUNT}"
echo -e "  ${RED}✗ FAIL${NC}: ${FAIL_COUNT}"
echo ""

if [[ $FAIL_COUNT -eq 0 ]]; then
    if [[ $WARN_COUNT -eq 0 ]]; then
        echo -e "${GREEN}🎉 모든 테스트 통과!${NC}"
    else
        echo -e "${YELLOW}⚠️  일부 경고가 있지만 기본 기능은 정상입니다.${NC}"
    fi
    EXIT_CODE=0
else
    echo -e "${RED}❌ 일부 테스트 실패. 위의 FAIL 항목을 확인하세요.${NC}"
    EXIT_CODE=1
fi

echo ""
echo "=========================================="
echo ""

exit $EXIT_CODE


