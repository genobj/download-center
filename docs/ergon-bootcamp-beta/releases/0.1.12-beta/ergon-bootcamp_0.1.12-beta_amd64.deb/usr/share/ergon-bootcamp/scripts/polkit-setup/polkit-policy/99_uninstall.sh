#!/bin/bash
#
# 99_uninstall.sh
# Polkit 정책 파일 제거
#
# 사용법: ./99_uninstall.sh
#

set -e

# sudo 공통 라이브러리 로드
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../../lib/sudo.sh"

echo "=========================================="
echo "  Polkit 정책 파일 제거"
echo "=========================================="
echo ""

POLICY_FILE="com.ergon.bootcamp.policy"
POLICY_DIR="/usr/share/polkit-1/actions"
POLICY_TARGET="$POLICY_DIR/$POLICY_FILE"

if [ ! -f "$POLICY_TARGET" ]; then
    echo "ℹ️  Polkit 정책 파일이 설치되어 있지 않습니다."
    exit 0
fi

echo "[1/2] 정책 파일 제거 중..."
run_as_root rm -f "$POLICY_TARGET"
echo "   ✓ $POLICY_TARGET 제거 완료"

echo ""
echo "[2/2] Polkit 데몬에 신호 전송 중..."
run_as_root killall -HUP polkitd 2>/dev/null || true
echo "   ✓ Polkit 정책 파일이 제거되었습니다"

echo ""
echo "✅ Polkit 정책 파일 제거 완료!"
echo ""

