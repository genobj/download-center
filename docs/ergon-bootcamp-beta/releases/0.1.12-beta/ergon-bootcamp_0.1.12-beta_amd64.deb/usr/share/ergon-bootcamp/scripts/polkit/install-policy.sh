#!/bin/bash
#
# install-policy.sh
# polkit 정책 파일 설치 스크립트 (테스트용)
#
# 사용법: sudo bash install-policy.sh

set -e

POLICY_FILE="com.ergon.bootcamp.policy"
POLICY_DIR="/usr/share/polkit-1/actions"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [ "$EUID" -ne 0 ]; then
    echo "❌ 이 스크립트는 root 권한이 필요합니다."
    echo ""
    echo "실행 방법:"
    echo "  sudo bash $0"
    exit 1
fi

echo "=========================================="
echo "  Polkit 정책 파일 설치"
echo "=========================================="
echo ""

# 정책 파일 경로 확인
POLICY_SOURCE="$SCRIPT_DIR/$POLICY_FILE"
POLICY_TARGET="$POLICY_DIR/$POLICY_FILE"

if [ ! -f "$POLICY_SOURCE" ]; then
    echo "❌ 정책 파일을 찾을 수 없습니다: $POLICY_SOURCE"
    exit 1
fi

echo "[1/2] 정책 파일 복사 중..."
cp "$POLICY_SOURCE" "$POLICY_TARGET"
chmod 644 "$POLICY_TARGET"
echo "   ✓ $POLICY_TARGET"

echo ""
echo "[2/2] 정책 파일 검증 중..."
if [ -f "$POLICY_TARGET" ]; then
    echo "   ✓ 정책 파일이 올바르게 설치되었습니다."
else
    echo "   ❌ 정책 파일 설치 실패"
    exit 1
fi

echo ""
echo "=========================================="
echo "  ✅ Polkit 정책 파일 설치 완료"
echo "=========================================="
echo ""
echo "설치된 정책 파일: $POLICY_TARGET"
echo ""

# 프로덕션 환경을 위한 스크립트 권한 설정 (선택적)
# 개발 환경에서는 스크립트 수정이 빈번하므로 기본값은 비활성화
# 프로덕션 배포 시 아래 주석을 해제하여 활성화할 수 있습니다
#
# SCRIPTS_BASE_DIR="$SCRIPT_DIR/../.."
# echo "[선택] 스크립트 파일 권한 설정 중..."
# echo "   ⚠️  주의: 이 옵션은 프로덕션 환경에서만 사용하세요."
# echo "   스크립트 파일의 소유권을 root:root로 변경하고 권한을 755로 설정합니다."
# echo ""
# read -p "   스크립트 권한을 설정하시겠습니까? (y/N): " -n 1 -r
# echo ""
# if [[ $REPLY =~ ^[Yy]$ ]]; then
#     echo "   스크립트 디렉토리 권한 설정 중..."
#     # 스크립트 디렉토리의 모든 .sh 파일을 찾아 권한 설정
#     find "$SCRIPTS_BASE_DIR" -type f -name "*.sh" -exec chown root:root {} \; 2>/dev/null || true
#     find "$SCRIPTS_BASE_DIR" -type f -name "*.sh" -exec chmod 755 {} \; 2>/dev/null || true
#     echo "   ✓ 스크립트 파일 권한 설정 완료"
#     echo ""
#     echo "   📌 참고: 스크립트를 수정하려면 다음 명령을 사용하세요:"
#     echo "      sudo chown $USER:$USER <script-path>"
# else
#     echo "   ⏭️  스크립트 권한 설정 건너뜀 (개발 환경 권장)"
# fi

echo "테스트 방법:"
echo "  1. 앱 실행: pnpm tauri dev"
echo "  2. 설치 스크립트 실행하여 polkit 인증 다이얼로그 확인"
echo "  3. 15분 이내 재실행 시 재인증 없이 실행되는지 확인"
echo ""



