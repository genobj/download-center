#!/bin/bash
#
# 01_install_telegram.sh
# Telegram Desktop 설치 (Flatpak)
#
# 설명:
#   - Flathub에서 Telegram Desktop 설치
#   - Flatpak이 먼저 설치되어 있어야 함
#
# 사용법: ./01_install_telegram.sh
#

set -e

APP_ID="org.telegram.desktop"
APP_NAME="Telegram Desktop"

echo "=========================================="
echo "  $APP_NAME 설치"
echo "=========================================="
echo ""

# ============================================
# 1. Flatpak 확인
# ============================================
echo "[1/4] Flatpak 확인..."

if ! command -v flatpak &> /dev/null; then
    echo "   ❌ Flatpak이 설치되지 않았습니다."
    echo ""
    echo "   먼저 다음을 실행하세요:"
    echo "   system-setup/flatpak-setup/01_install_flatpak.sh"
    exit 1
fi

echo "   ✓ Flatpak 설치됨"

# Flathub 확인
if ! flatpak remotes | grep -q flathub; then
    echo "   ❌ Flathub 저장소가 등록되지 않았습니다."
    echo ""
    echo "   먼저 다음을 실행하세요:"
    echo "   system-setup/flatpak-setup/02_add_flathub.sh"
    exit 1
fi

echo "   ✓ Flathub 저장소 등록됨"
echo ""

# ============================================
# 2. 기존 설치 확인
# ============================================
echo "[2/4] 기존 설치 확인..."

if flatpak list | grep -q "$APP_ID"; then
    INSTALLED_VERSION=$(flatpak info "$APP_ID" 2>/dev/null | grep "Version:" | awk '{print $2}')
    echo "   ✓ $APP_NAME이 이미 설치되어 있습니다. (버전: $INSTALLED_VERSION)"
    
    # TTY 확인: 터미널이면 대화형, 아니면 자동 업데이트
    if [ -t 0 ] && [ -t 1 ]; then
        read -p "   업데이트를 확인하시겠습니까? (y/N): " -n 1 -r
        echo ""
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            echo "   업데이트 확인 중..."
            flatpak update -y "$APP_ID" || true
        fi
    else
        echo "   비대화형 모드: 업데이트를 확인합니다..."
        flatpak update -y "$APP_ID" || true
    fi
    exit 0
fi

echo "   → 새로 설치를 진행합니다."
echo ""

# ============================================
# 3. 설치
# ============================================
echo "[3/4] $APP_NAME 설치 중..."
echo "   출처: Flathub (공식)"
echo ""

flatpak install -y flathub "$APP_ID"

echo ""

# ============================================
# 4. DBusActivatable 수정 및 아이콘 캐시 업데이트
# ============================================
echo "[4/5] 데스크톱 통합 설정..."

FLATPAK_DESKTOP="/var/lib/flatpak/exports/share/applications/org.telegram.desktop.desktop"
LOCAL_DESKTOP="$HOME/.local/share/applications/org.telegram.desktop.desktop"

if [ -f "$FLATPAK_DESKTOP" ]; then
    mkdir -p "$HOME/.local/share/applications"
    cp "$FLATPAK_DESKTOP" "$LOCAL_DESKTOP"
    sed -i 's/DBusActivatable=true/DBusActivatable=false/' "$LOCAL_DESKTOP"
    
    # 데스크톱 데이터베이스 업데이트
    if command -v update-desktop-database &> /dev/null; then
        update-desktop-database "$HOME/.local/share/applications/" 2>/dev/null || true
    fi
    
    echo "   ✓ 데스크톱 통합 설정 완료"
else
    echo "   ⚠️  데스크톱 파일을 찾을 수 없음 (선택적)"
fi

# ============================================
# 5. 아이콘 캐시 업데이트
# ============================================
echo "[5/5] 아이콘 캐시 업데이트..."

# Flatpak 아이콘 캐시 업데이트
if command -v flatpak &> /dev/null; then
    flatpak update --appstream 2>/dev/null || true
fi

# 시스템 아이콘 캐시 업데이트
if command -v gtk-update-icon-cache &> /dev/null; then
    # 로컬 아이콘 캐시
    if [ -d "$HOME/.local/share/icons" ]; then
        gtk-update-icon-cache -f -t "$HOME/.local/share/icons" 2>/dev/null || true
    fi
    # 시스템 아이콘 캐시 (sudo 필요할 수 있음)
    if [ -d "/usr/share/icons/hicolor" ]; then
        sudo gtk-update-icon-cache -f -t /usr/share/icons/hicolor 2>/dev/null || true
    fi
fi

# Flatpak exports 아이콘 캐시
FLATPAK_ICON_DIR="/var/lib/flatpak/exports/share/icons/hicolor"
if [ -d "$FLATPAK_ICON_DIR" ] && command -v gtk-update-icon-cache &> /dev/null; then
    sudo gtk-update-icon-cache -f -t "$FLATPAK_ICON_DIR" 2>/dev/null || true
fi

echo "   ✓ 아이콘 캐시 업데이트 완료"

echo ""

# ============================================
# 결과 확인
# ============================================
if flatpak list | grep -q "$APP_ID"; then
    INSTALLED_VERSION=$(flatpak info "$APP_ID" 2>/dev/null | grep "Version:" | awk '{print $2}')
    
    echo "┌────────────────────────────────────────┐"
    echo "│  ✅ $APP_NAME 설치 완료!"
    echo "├────────────────────────────────────────┤"
    printf "│  버전: %-29s │\n" "$INSTALLED_VERSION"
    echo "└────────────────────────────────────────┘"
    echo ""
    echo "💡 실행 방법:"
    echo "   - 앱 메뉴에서 'Telegram' 검색"
    echo "   - 또는: flatpak run $APP_ID"
    echo ""
else
    echo "❌ 설치에 실패했습니다."
    exit 1
fi
