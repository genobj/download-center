#!/bin/bash
#
# 03_install_tauri_deps.sh
# Tauri 개발에 필요한 시스템 의존성 설치
#
# 설명:
#   - libwebkit2gtk-4.1-dev: WebView 렌더링
#   - libappindicator3-dev: 시스템 트레이 아이콘
#   - librsvg2-dev: SVG 아이콘 렌더링
#   - patchelf: ELF 바이너리 수정 도구
#
# 사용법: ./03_install_tauri_deps.sh
#

set -e

# 환경 변수 설정 (비대화형 모드)
export DEBIAN_FRONTEND=noninteractive
export APT_LISTCHANGES_FRONTEND=none

# sudo 공통 라이브러리 로드
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../../lib/sudo.sh"

# sudo 캐시 확인 (Tauri 앱 환경에서 필수)
if ! ensure_sudo_cache; then
    echo -e "${RED}❌ Sudo cache expired or not found${NC}"
    echo "Please verify your password in the password screen first."
    exit 1
fi

echo "=========================================="
echo "  Tauri 개발 의존성 설치"
echo "=========================================="
echo ""

# ============================================
# 1. 패키지 목록
# ============================================
PACKAGES=(
    "libwebkit2gtk-4.1-dev"         # WebView 렌더링
    "libayatana-appindicator3-dev"  # 시스템 트레이 (Ubuntu 22.04+)
    "librsvg2-dev"                  # SVG 렌더링
    "patchelf"                      # ELF 수정 도구
)

echo "[1/2] 설치할 패키지:"
for pkg in "${PACKAGES[@]}"; do
    # dpkg-query로 정확한 설치 상태 확인 (아키텍처 접미사 무시)
    PKG_STATUS=$(dpkg-query -W -f='${Status}' "$pkg" 2>/dev/null || echo "")
    if echo "$PKG_STATUS" | grep -q "install ok installed"; then
        echo "   ✓ $pkg (이미 설치됨)"
    else
        echo "   → $pkg (설치 예정)"
    fi
done
echo ""

# ============================================
# 2. 패키지 설치
# ============================================
echo "[2/2] 패키지 설치 중..."

INSTALL_LIST=()
for pkg in "${PACKAGES[@]}"; do
    PKG_STATUS=$(dpkg-query -W -f='${Status}' "$pkg" 2>/dev/null || echo "")
    if ! echo "$PKG_STATUS" | grep -q "install ok installed"; then
        INSTALL_LIST+=("$pkg")
    fi
done

if [[ ${#INSTALL_LIST[@]} -eq 0 ]]; then
    echo "   ✓ 모든 패키지가 이미 설치되어 있습니다."
else
    run_as_root apt-get update -qq
    run_as_root apt-get install -y "${INSTALL_LIST[@]}"
    echo "   ✓ 패키지 설치 완료"
fi

# 설치 검증
echo ""
echo "[검증] 설치 확인 중..."
FAILED=false
for pkg in "${PACKAGES[@]}"; do
    PKG_STATUS=$(dpkg-query -W -f='${Status}' "$pkg" 2>/dev/null || echo "")
    if ! echo "$PKG_STATUS" | grep -q "install ok installed"; then
        echo "   ❌ $pkg 설치 실패"
        FAILED=true
    else
        echo "   ✓ $pkg 설치 확인"
    fi
done

if [ "$FAILED" = true ]; then
    echo "   일부 패키지 설치에 실패했습니다."
    exit 1
fi
echo ""
echo "   ✓ 모든 패키지 설치 확인됨"

echo ""

# ============================================
# 결과 확인
# ============================================
echo "┌────────────────────────────────────────┐"
echo "│  Tauri 의존성 설치 완료                │"
echo "├────────────────────────────────────────┤"
for pkg in "${PACKAGES[@]}"; do
    VERSION=$(dpkg-query -W -f='${Version}' "$pkg" 2>/dev/null | cut -d'-' -f1)
    if [[ -n "$VERSION" ]]; then
        printf "│  ✓ %-26s %8s │\n" "$pkg" "$VERSION"
    else
        printf "│  ❌ %-36s │\n" "$pkg"
    fi
done
echo "└────────────────────────────────────────┘"
echo ""

echo "✅ Tauri 개발 의존성 설치 완료!"
echo ""
echo "다음 단계: ./04_configure_inotify.sh"
echo ""

