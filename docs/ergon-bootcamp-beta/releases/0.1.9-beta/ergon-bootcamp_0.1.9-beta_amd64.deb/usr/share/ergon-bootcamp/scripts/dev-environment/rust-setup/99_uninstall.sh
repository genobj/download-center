#!/bin/bash
#
# 99_uninstall.sh
# Rust & Tauri 개발 환경 삭제 스크립트
#

set -e

# 환경 변수 설정 (비대화형 모드)
export DEBIAN_FRONTEND=noninteractive
export APT_LISTCHANGES_FRONTEND=none

# sudo 캐시 확인 (만료되었으면 에러)
if ! sudo -n -v 2>/dev/null; then
    echo "❌ Sudo cache expired. Please verify your password first."
    exit 1
fi

# sudo 공통 라이브러리 로드
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../../lib/sudo.sh"

# sudo로 실행될 때 실제 사용자 홈 디렉토리 찾기
if [ -n "$SUDO_USER" ]; then
    REAL_HOME=$(getent passwd "$SUDO_USER" | cut -d: -f6)
    REAL_USER="$SUDO_USER"
else
    REAL_HOME="$HOME"
    REAL_USER="$USER"
fi

# 실제 사용자의 cargo bin PATH 설정
export PATH="$REAL_HOME/.cargo/bin:$PATH"

echo "=========================================="
echo "  Rust & Tauri 삭제"
echo "=========================================="
echo ""

# ============================================
# 1. rustup 제거 (실제 사용자 권한으로)
# ============================================
echo "[1/3] rustup 제거 중..."

RUSTUP_PATH="$REAL_HOME/.cargo/bin/rustup"
if [ -f "$RUSTUP_PATH" ]; then
    # rustup은 사용자 권한으로 실행해야 함
    sudo -u "$REAL_USER" "$RUSTUP_PATH" self uninstall -y || true
    echo "   ✓ rustup 제거 완료"
else
    echo "   ⚠️  rustup이 설치되어 있지 않음"
fi

echo ""

# ============================================
# 2. Tauri 의존성 패키지 제거
# ============================================
echo "[2/3] Tauri 의존성 패키지 제거 중..."

TAURI_PACKAGES=(
    "libwebkit2gtk-4.1-dev"
    "libayatana-appindicator3-dev"
    "librsvg2-dev"
    "patchelf"
)

for pkg in "${TAURI_PACKAGES[@]}"; do
    { run_as_root apt-get remove -y -qq "$pkg" >/dev/null 2>&1; } || true
done
{ run_as_root apt-get autoremove -y -qq >/dev/null 2>&1; } || true

echo "   ✓ Tauri 의존성 패키지 제거 완료"
echo ""

# ============================================
# 3. 잔여 파일 정리
# ============================================
echo "[3/3] 잔여 파일 정리 중..."

# .cargo 디렉토리 제거
if [ -d "$REAL_HOME/.cargo" ]; then
    rm -rf "$REAL_HOME/.cargo"
    echo "   ✓ $REAL_HOME/.cargo 제거 완료"
fi

# .rustup 디렉토리 제거
if [ -d "$REAL_HOME/.rustup" ]; then
    rm -rf "$REAL_HOME/.rustup"
    echo "   ✓ $REAL_HOME/.rustup 제거 완료"
fi

echo ""
echo "✅ Rust & Tauri 삭제 완료!"
echo ""
