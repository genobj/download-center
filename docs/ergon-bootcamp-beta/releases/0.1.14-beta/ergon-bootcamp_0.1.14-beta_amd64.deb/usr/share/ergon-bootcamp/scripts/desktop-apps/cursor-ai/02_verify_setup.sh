#!/bin/bash
#
# 02_verify_setup.sh
# Cursor AI 설치 및 APT 저장소 확인
#
# 사용법: ./02_verify_setup.sh
#

echo "=========================================="
echo "  Cursor AI 설치 확인"
echo "=========================================="

PASS_COUNT=0
FAIL_COUNT=0

# 설정
CURSOR_REPO_URL="downloads.cursor.com/aptrepo"
CURSOR_SOURCES_PATH="/etc/apt/sources.list.d/cursor.sources"
CURSOR_GPG_PATH="/usr/share/keyrings/anysphere.gpg"

# 1. cursor 명령어 확인
echo ""
echo "[1/5] cursor 명령어 확인..."
CURSOR_FOUND=false
CURSOR_PATH=""

if command -v cursor &> /dev/null; then
    CURSOR_PATH=$(command -v cursor)
    CURSOR_FOUND=true
else
    for path in "/usr/bin/cursor" "/usr/local/bin/cursor" "$HOME/.local/bin/cursor"; do
        if [ -f "$path" ] || [ -L "$path" ]; then
            CURSOR_PATH="$path"
            CURSOR_FOUND=true
            break
        fi
    done
fi

if [ "$CURSOR_FOUND" = true ]; then
    echo "   ✅ cursor 명령어 사용 가능"
    echo "      경로: $CURSOR_PATH"
    PASS_COUNT=$((PASS_COUNT + 1))
else
    echo "   ❌ cursor 명령어를 찾을 수 없음"
    FAIL_COUNT=$((FAIL_COUNT + 1))
fi

# 2. 패키지 설치 상태 확인
echo ""
echo "[2/5] 패키지 설치 상태 확인..."
if dpkg -l | grep -q "^ii  cursor "; then
    VERSION=$(dpkg -l | grep "^ii  cursor " | awk '{print $3}')
    echo "   ✅ cursor 패키지 설치됨: $VERSION"
    PASS_COUNT=$((PASS_COUNT + 1))
else
    echo "   ❌ cursor 패키지가 설치되지 않음"
    FAIL_COUNT=$((FAIL_COUNT + 1))
fi

# 3. APT 저장소 확인 (Bootstrap으로 자동 등록)
echo ""
echo "[3/5] APT 저장소 확인..."
REPO_FOUND=false

if [ -f "$CURSOR_SOURCES_PATH" ]; then
    if grep -q "$CURSOR_REPO_URL" "$CURSOR_SOURCES_PATH" 2>/dev/null; then
        REPO_FOUND=true
        echo "   ✅ 저장소 파일 존재: $CURSOR_SOURCES_PATH"
    fi
fi

# APT 캐시에서도 확인
if [ "$REPO_FOUND" = false ]; then
    if apt-cache policy cursor 2>/dev/null | grep -q "$CURSOR_REPO_URL"; then
        REPO_FOUND=true
        echo "   ✅ APT 캐시에서 저장소 확인됨"
    fi
fi

if [ "$REPO_FOUND" = true ]; then
    echo "   ✅ APT 저장소 활성화됨: https://$CURSOR_REPO_URL"
    PASS_COUNT=$((PASS_COUNT + 1))
else
    echo "   ⚠️  APT 저장소가 등록되지 않음"
    echo "      (Cursor 재설치로 자동 등록됩니다)"
    # 치명적이지 않음 - 수동 업데이트는 가능
    PASS_COUNT=$((PASS_COUNT + 1))
fi

# 4. GPG 키 확인
echo ""
echo "[4/5] GPG 키 확인..."
if [ -f "$CURSOR_GPG_PATH" ]; then
    echo "   ✅ GPG 키 파일 존재: $CURSOR_GPG_PATH"
    
    if command -v gpg >/dev/null 2>&1; then
        if gpg --show-keys "$CURSOR_GPG_PATH" >/dev/null 2>&1; then
            echo "   ✅ GPG 키 유효성 확인됨"
        else
            echo "   ⚠️  GPG 키 검증 실패"
        fi
    else
        echo "   ℹ️  gpg 명령이 없어 키 유효성 검증은 스킵합니다"
    fi
    PASS_COUNT=$((PASS_COUNT + 1))
else
    echo "   ⚠️  GPG 키 파일 없음 (Cursor 재설치 시 자동 생성)"
    PASS_COUNT=$((PASS_COUNT + 1))  # 치명적이지 않음
fi

# 5. 데스크톱 파일 확인
echo ""
echo "[5/5] 데스크톱 통합 확인..."
DESKTOP_FOUND=false
for DESKTOP_FILE in "/usr/share/applications/cursor.desktop" \
                    "$HOME/.local/share/applications/cursor.desktop" \
                    "/usr/share/applications/com.todesktop.desktop230313mz4w4u92.desktop"; do
    if [ -f "$DESKTOP_FILE" ]; then
        echo "   ✅ 데스크톱 파일 존재: $DESKTOP_FILE"
        DESKTOP_FOUND=true
        break
    fi
done

if [ "$DESKTOP_FOUND" = false ]; then
    echo "   ⚠️  데스크톱 파일을 찾을 수 없음 (수동 실행은 가능)"
fi
PASS_COUNT=$((PASS_COUNT + 1))

# 결과 출력
echo ""
echo "=========================================="
echo "  검증 결과"
echo "=========================================="
echo ""
echo "  ✅ 통과: $PASS_COUNT"
echo "  ❌ 실패: $FAIL_COUNT"
echo ""

# APT 업데이트 가능 여부 확인
if [ "$REPO_FOUND" = true ]; then
    INSTALLED=$(dpkg-query -W -f='${Version}' cursor 2>/dev/null || echo "")
    CANDIDATE=$(apt-cache policy cursor 2>/dev/null | grep "Candidate:" | awk '{print $2}')
    
    if [ -n "$CANDIDATE" ] && [ "$CANDIDATE" != "(none)" ]; then
        if [ "$INSTALLED" != "$CANDIDATE" ]; then
            echo "  ⬆️  업데이트 가능: $INSTALLED → $CANDIDATE"
            echo "     sudo apt upgrade cursor"
            echo ""
        fi
    fi
fi

if [ $FAIL_COUNT -eq 0 ]; then
    echo "🎉 모든 검증을 통과했습니다!"
    echo ""
    echo "┌────────────────────────────────────────────────────┐"
    echo "│  📌 Cursor AI 사용법                               │"
    echo "│                                                    │"
    echo "│  실행:                                             │"
    echo "│    cursor                                          │"
    echo "│                                                    │"
    echo "│  업데이트:                                         │"
    echo "│    sudo apt upgrade cursor                         │"
    echo "│                                                    │"
    echo "│  또는 앱 메뉴에서 'Cursor' 검색                    │"
    echo "│                                                    │"
    echo "│  💡 참고:                                          │"
    echo "│  - Cursor는 AI 기반 코드 에디터입니다               │"
    echo "│  - VS Code 기반으로 제작되었습니다                  │"
    echo "│  - apt upgrade로 자동 업데이트됩니다                │"
    echo "└────────────────────────────────────────────────────┘"
    exit 0
else
    echo "⚠️  일부 검증이 실패했습니다."
    echo ""
    echo "문제 해결 방법:"
    echo "  1. 설치: ./01_install_cursor.sh"
    echo ""
    echo "수동 설치 방법:"
    echo "  1. https://cursor.sh/ 접속"
    echo "  2. Linux용 .deb 파일 다운로드"
    echo "  3. sudo apt install ./cursor_*.deb"
    exit 1
fi
