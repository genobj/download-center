#!/bin/bash
#
# 01_install_cursor.sh
# Cursor AI 에디터 설치 (Bootstrap 방식)
#
# 사용법: ./01_install_cursor.sh
# 필요한 설정: SUDO_PASSWORD (config.local.env)
#
# 참고: .deb 패키지 설치 시 APT 저장소가 자동으로 등록됩니다.
#       이후 apt upgrade cursor로 업데이트가 가능합니다.
#
# 환경변수:
#   CURSOR_NO_REINSTALL=true  - Case C 자동 재설치 억제
#   CI=true / NONINTERACTIVE=true - 비대화형 모드
#

set -e

# 비대화형 패키지 설치 (debconf Dialog 방지)
export DEBIAN_FRONTEND=noninteractive
export APT_LISTCHANGES_FRONTEND=none

# sudo 공통 라이브러리 로드
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../../lib/sudo.sh"

# 임시 디렉토리 정리를 위한 trap 설정
TEMP_DIR=""
cleanup() {
    if [ -n "$TEMP_DIR" ] && [ -d "$TEMP_DIR" ]; then
        cd /
        rm -rf "$TEMP_DIR"
    fi
}
trap cleanup EXIT

# 설치 로그 파일
INSTALL_LOG="/tmp/cursor_install_$(date +%Y%m%d_%H%M%S).log"

# ──────────────────────────────────────────────
# 헬퍼 함수
# ──────────────────────────────────────────────

# 비대화형 모드 판별
is_noninteractive() {
    [ "${CI:-false}" = "true" ] || [ "${NONINTERACTIVE:-false}" = "true" ] || { ! [ -t 0 ] || ! [ -t 1 ]; }
}

# APT 경로 정상 여부 판별 (sources + keyring + candidate 3중 확인)
is_apt_repo_healthy() {
    local has_sources=false
    local has_keyring=false
    local has_candidate=false

    [ -f /etc/apt/sources.list.d/cursor.sources ] && has_sources=true
    [ -f /usr/share/keyrings/anysphere.gpg ] && has_keyring=true

    local candidate
    candidate=$(apt-cache policy cursor 2>/dev/null | awk '/Candidate:/{print $2}')
    [ -n "$candidate" ] && [ "$candidate" != "(none)" ] && has_candidate=true

    $has_sources && $has_keyring && $has_candidate
}

# .deb 다운로드 + 검증 (TEMP_DIR 내에 절대경로로 저장)
# 성공 시 DEB_PATH 변수에 절대경로 설정
download_deb() {
    TEMP_DIR=$(mktemp -d)
    DEB_PATH="$TEMP_DIR/$DEB_FILE"

    echo "   URL: $DEB_URL"
    echo ""

    if curl -fL --retry 3 --retry-delay 2 --connect-timeout 10 --max-time 300 \
        --progress-bar -o "$DEB_PATH" "$DEB_URL" 2>&1; then

        # .deb 유효성 검증 (dpkg-deb 사용 - 로케일 무관)
        if dpkg-deb --info "$DEB_PATH" > /dev/null 2>&1; then
            # 패키지 메타데이터 검증
            PKG_NAME=$(dpkg-deb -f "$DEB_PATH" Package 2>/dev/null || echo "")
            PKG_VERSION=$(dpkg-deb -f "$DEB_PATH" Version 2>/dev/null || echo "")
            PKG_ARCH=$(dpkg-deb -f "$DEB_PATH" Architecture 2>/dev/null || echo "")

            if [ "$PKG_NAME" = "cursor" ]; then
                echo "   ✓ 다운로드 완료"
                echo "   패키지: $PKG_NAME $PKG_VERSION ($PKG_ARCH)"

                # 아키텍처 검증
                if [ "$PKG_ARCH" != "amd64" ] && [ "$PKG_ARCH" != "all" ]; then
                    echo "   ⚠️  패키지 아키텍처가 예상과 다릅니다: $PKG_ARCH"
                fi
            else
                echo "   ⚠️  패키지 이름이 예상과 다릅니다: $PKG_NAME"
                echo "   계속 진행합니다..."
            fi
            return 0
        else
            echo "   ❌ 다운로드된 파일이 유효한 .deb 패키지가 아닙니다."
            return 1
        fi
    else
        echo "   ❌ 다운로드 실패"
        return 1
    fi
}

# 설치 실패 시 수동 안내 출력
show_manual_install_guide() {
    echo ""
    echo "   수동 설치 방법:"
    echo "   1. https://cursor.com/download 접속"
    echo "   2. Linux용 .deb 파일 다운로드"
    echo "   3. sudo apt install ./cursor_*.deb"
}

# .deb 설치 실행
install_deb() {
    # apt install 사용 (의존성 자동 해결 + 저장소 자동 등록)
    if run_as_root apt-get install -y "$DEB_PATH" 2>&1 | tee -a "$INSTALL_LOG"; then
        echo "   ✓ 패키지 설치 완료"
    else
        echo "   apt-get install 실패, dpkg로 직접 설치 시도 중..."
        echo "--- dpkg 설치 시도 ---" >> "$INSTALL_LOG"
        if run_as_root dpkg -i "$DEB_PATH" 2>&1 | tee -a "$INSTALL_LOG"; then
            echo "   ✓ 패키지 설치 완료"
        else
            echo "   의존성 문제 해결 중..."
            echo "--- 의존성 해결 시도 ---" >> "$INSTALL_LOG"
            run_as_root apt-get install -f -y 2>&1 | tee -a "$INSTALL_LOG" || true
        fi
    fi

    # 설치 확인
    if dpkg-query -W -f='${Status}' cursor 2>/dev/null | grep -q "install ok installed"; then
        INSTALLED_VERSION=$(dpkg-query -W -f='${Version}' cursor 2>/dev/null | head -1 | tr -d '[:space:]')
        echo "   ✓ Cursor AI 설치 완료: $INSTALLED_VERSION"
        return 0
    else
        echo "   ❌ 설치 확인 실패"
        echo "   설치 로그: $INSTALL_LOG"
        return 1
    fi
}

# ──────────────────────────────────────────────
# sudo 캐시 확인
# ──────────────────────────────────────────────

if ! ensure_sudo_cache; then
    echo -e "${RED}❌ Sudo cache expired or not found${NC}"
    echo "Please verify your password in the password screen first."
    exit 1
fi

echo "=========================================="
echo "  Cursor AI 에디터 설치"
echo "=========================================="

# ──────────────────────────────────────────────
# 아키텍처 확인
# ──────────────────────────────────────────────

ARCH=$(dpkg --print-architecture)
if [ "$ARCH" != "amd64" ]; then
    echo "❌ 지원되지 않는 아키텍처: $ARCH"
    echo ""
    echo "   현재 스크립트는 x64(amd64)만 지원합니다."
    echo "   arm64 사용자는 공식 사이트에서 직접 다운로드하세요:"
    echo "   https://cursor.com/download"
    exit 1
fi

# ──────────────────────────────────────────────
# 다운로드 URL 설정
# ──────────────────────────────────────────────

DEB_URL="https://api2.cursor.sh/updates/download/golden/linux-x64-deb/cursor/latest"
DEB_FILE="cursor_latest_amd64.deb"
DEB_PATH=""  # download_deb()에서 설정됨

# ──────────────────────────────────────────────
# 설치 유형 판별 (dpkg vs 비-dpkg vs 미설치)
# ──────────────────────────────────────────────

IS_DEB_INSTALLED=false
IS_OTHER_INSTALLED=false
CURRENT_VERSION=""

if dpkg-query -W -f='${Status}' cursor 2>/dev/null | grep -q "install ok installed"; then
    IS_DEB_INSTALLED=true
    CURRENT_VERSION=$(dpkg-query -W -f='${Version}' cursor 2>/dev/null | head -1 | tr -d '[:space:]')
elif command -v cursor &> /dev/null; then
    IS_OTHER_INSTALLED=true
fi

# ──────────────────────────────────────────────
# [Case B] 설치됨(dpkg) + APT 경로 정상
# ──────────────────────────────────────────────

if [ "$IS_DEB_INSTALLED" = true ] && is_apt_repo_healthy; then
    echo "ℹ️  Cursor AI가 이미 설치되어 있습니다. (버전: $CURRENT_VERSION)"
    echo "   ✅ APT 저장소가 활성화되어 있습니다."
    echo ""

    # 버전 비교 (dpkg --compare-versions 사용)
    CANDIDATE=$(apt-cache policy cursor 2>/dev/null | awk '/Candidate:/{print $2}')

    if [ -z "$CANDIDATE" ] || [ "$CANDIDATE" = "(none)" ]; then
        echo "   ✓ 이미 최신 버전입니다."
        exit 0
    fi

    if dpkg --compare-versions "$CURRENT_VERSION" ge "$CANDIDATE" 2>/dev/null; then
        echo "   ✓ 이미 최신 버전입니다. ($CURRENT_VERSION)"
        exit 0
    fi

    # 구버전: 업그레이드 제안
    echo "   ⬆️  새 버전 사용 가능: $CURRENT_VERSION → $CANDIDATE"
    echo ""

    # held 패키지 확인
    if apt-mark showhold 2>/dev/null | grep -q '^cursor$'; then
        echo "   ⚠️  cursor 패키지가 hold 상태입니다."
        echo "   수동 해제 후 업그레이드하세요:"
        echo "     sudo apt-mark unhold cursor"
        echo "     sudo apt update && sudo apt upgrade cursor"
        exit 0
    fi

    if is_noninteractive; then
        # 비대화형: cursor-only 자동 업그레이드
        echo "   자동 업그레이드 진행 중..."
        run_as_root apt-get update -qq 2>/dev/null || true
        if run_as_root apt-get install --only-upgrade -y cursor 2>&1 | tee -a "$INSTALL_LOG"; then
            INSTALLED_VERSION=$(dpkg-query -W -f='${Version}' cursor 2>/dev/null | head -1 | tr -d '[:space:]')
            echo ""
            echo "   ✓ 업그레이드 완료: $INSTALLED_VERSION"
        else
            echo ""
            echo "   ⚠️  자동 업그레이드 실패"
            echo "   수동 업그레이드: sudo apt update && sudo apt upgrade cursor"
        fi
    else
        # 대화형: 사용자에게 선택
        read -p "   지금 업그레이드할까요? (Y/n): " -n 1 -r
        echo
        if [[ ! $REPLY =~ ^[Nn]$ ]]; then
            echo "   업그레이드 진행 중..."
            run_as_root apt-get update -qq 2>/dev/null || true
            if run_as_root apt-get install --only-upgrade -y cursor 2>&1 | tee -a "$INSTALL_LOG"; then
                INSTALLED_VERSION=$(dpkg-query -W -f='${Version}' cursor 2>/dev/null | head -1 | tr -d '[:space:]')
                echo ""
                echo "   ✓ 업그레이드 완료: $INSTALLED_VERSION"
            else
                echo ""
                echo "   ⚠️  업그레이드 실패"
                echo "   수동 업그레이드: sudo apt update && sudo apt upgrade cursor"
            fi
        else
            echo "   💡 수동 업그레이드: sudo apt update && sudo apt upgrade cursor"
        fi
    fi
    exit 0
fi

# ──────────────────────────────────────────────
# [Case C] 설치됨(dpkg) + APT 경로 비정상 → 재설치
# ──────────────────────────────────────────────

if [ "$IS_DEB_INSTALLED" = true ]; then
    echo "ℹ️  Cursor AI가 설치되어 있습니다. (버전: $CURRENT_VERSION)"
    echo "   ⚠️  APT 저장소가 등록되지 않은 상태입니다."
    echo "   자동 업데이트를 활성화하려면 최신 .deb로 재설치가 필요합니다."
    echo ""

    # 옵트아웃 플래그 확인
    if [ "${CURSOR_NO_REINSTALL:-false}" = "true" ]; then
        echo "   CURSOR_NO_REINSTALL 설정됨 → 재설치 스킵"
        exit 0
    fi

    # Cursor 실행 중 체크 (정확한 프로세스명 매칭)
    if pgrep -x cursor > /dev/null 2>&1; then
        echo "   ❌ Cursor가 실행 중입니다."
        echo "   Cursor를 종료한 후 다시 실행해주세요."
        exit 1
    fi

    if is_noninteractive; then
        # 비대화형(Tauri): 자동 재설치 진행
        echo "   자동 재설치를 진행합니다. (설정은 유지됩니다)"
        echo ""
    else
        # 대화형: 사용자 선택
        echo "   재설치하면 설정과 확장은 유지되며, 패키지만 교체됩니다."
        read -p "   최신 버전으로 재설치할까요? (Y/n): " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Nn]$ ]]; then
            echo "   설치를 건너뜁니다."
            exit 0
        fi
    fi

    # 안전한 재설치 순서: 다운로드 성공 → 제거 → 설치
    echo "[1/3] Cursor AI 다운로드 중..."
    if ! download_deb; then
        show_manual_install_guide
        exit 1
    fi

    echo ""
    echo "[2/3] 기존 패키지 제거 중 (설정은 유지됩니다)..."
    { run_as_root apt-get remove -y -qq cursor >/dev/null 2>&1; } || true
    { run_as_root dpkg --configure -a >/dev/null 2>&1; } || true
    echo "   ✓ 기존 패키지 제거 완료"

    echo ""
    echo "[3/3] Cursor AI 설치 중..."
    if ! install_deb; then
        show_manual_install_guide
        exit 1
    fi

    # 설치 후 검증으로 이동 (아래로 fall through)
fi

# ──────────────────────────────────────────────
# [Edge] command -v cursor 있지만 dpkg에 없음 (비-dpkg 설치)
# ──────────────────────────────────────────────

if [ "$IS_OTHER_INSTALLED" = true ]; then
    CURSOR_PATH=$(command -v cursor 2>/dev/null || echo "")
    echo "ℹ️  Cursor가 감지되었지만 APT 패키지로 설치되지 않았습니다."
    echo "   경로: $CURSOR_PATH"
    echo "   (AppImage 또는 수동 설치로 보입니다)"
    echo ""
    echo "   .deb 패키지로 전환하면 APT 자동 업데이트를 사용할 수 있습니다."
    echo ""

    if is_noninteractive; then
        echo "   비대화형 모드: APT 관리 대상이 아니므로 스킵합니다."
        echo "   .deb로 전환하려면 터미널에서 직접 실행하세요:"
        echo "     $SCRIPT_DIR/01_install_cursor.sh"
        exit 1
    else
        read -p "   .deb 패키지로 전환 설치할까요? (Y/n): " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Nn]$ ]]; then
            echo "   설치를 건너뜁니다."
            exit 0
        fi
    fi
    # Y 선택 시 아래 Case A 설치로 fall through
fi

# ──────────────────────────────────────────────
# [Case A] 미설치 → 다운로드 + 설치
# ──────────────────────────────────────────────

# Case C에서 이미 설치 완료한 경우 스킵
if [ -z "$INSTALLED_VERSION" ]; then
    echo ""
    echo "[1/3] Cursor AI 다운로드 중..."
    if ! download_deb; then
        show_manual_install_guide
        exit 1
    fi

    echo ""
    echo "[2/3] dpkg 상태 정리..."
    { run_as_root dpkg --configure -a >/dev/null 2>&1; } || true
    echo "   ✓ 완료"

    echo ""
    echo "[3/3] Cursor AI 설치 중..."
    if ! install_deb; then
        show_manual_install_guide
        exit 1
    fi
fi

# ──────────────────────────────────────────────
# 설치 후 검증 (Case A, C 공통)
# ──────────────────────────────────────────────

echo ""
echo "[검증] APT 저장소 자동 등록 확인..."

REPO_OK=true
KEY_OK=true

if [ -f /etc/apt/sources.list.d/cursor.sources ]; then
    echo "   ✓ 저장소 파일 생성됨: /etc/apt/sources.list.d/cursor.sources"

    # 저장소 파일 내용 검증
    if grep -q "downloads.cursor.com/aptrepo" /etc/apt/sources.list.d/cursor.sources 2>/dev/null; then
        echo "   ✓ 저장소 URL 확인됨"
    else
        echo "   ⚠️  저장소 URL이 예상과 다릅니다"
        REPO_OK=false
    fi
else
    echo "   ⚠️  저장소 파일이 생성되지 않았습니다"
    REPO_OK=false
fi

if [ -f /usr/share/keyrings/anysphere.gpg ]; then
    echo "   ✓ GPG 키 등록됨: /usr/share/keyrings/anysphere.gpg"

    # GPG 키 유효성 확인 (gpg가 설치된 경우에만)
    if command -v gpg >/dev/null 2>&1; then
        if gpg --show-keys /usr/share/keyrings/anysphere.gpg >/dev/null 2>&1; then
            echo "   ✓ GPG 키 유효성 확인됨"
        else
            echo "   ⚠️  GPG 키를 읽을 수 없습니다"
            KEY_OK=false
        fi
    else
        echo "   ℹ️  gpg 명령이 없어 키 유효성 검증은 스킵합니다"
    fi

    # Signed-By 경로가 실제 존재하는지 확인
    if [ -f /etc/apt/sources.list.d/cursor.sources ]; then
        SIGNED_BY_PATH=$(grep -oP 'Signed-By:\s*\K[^\s]+' /etc/apt/sources.list.d/cursor.sources 2>/dev/null || echo "")
        if [ -n "$SIGNED_BY_PATH" ] && [ ! -f "$SIGNED_BY_PATH" ]; then
            echo "   ⚠️  Signed-By 경로의 키 파일이 없습니다: $SIGNED_BY_PATH"
            KEY_OK=false
        fi
    fi
else
    echo "   ⚠️  GPG 키 파일이 생성되지 않았습니다"
    KEY_OK=false
fi

# APT 캐시 업데이트 (한 번만 실행, 결과로 GPG 이슈 검사)
echo ""
echo "   APT 캐시 업데이트 중..."
APT_UPDATE_OUTPUT=$(run_as_root apt-get update 2>&1 || true)

if echo "$APT_UPDATE_OUTPUT" | grep -qE "NO_PUBKEY|EXPKEYSIG|GPG error"; then
    echo "   ⚠️  APT 업데이트 중 GPG 경고 발생"
    echo "   자동 업데이트(apt upgrade cursor)가 작동하지 않을 수 있습니다."
    REPO_OK=false
fi

if apt-cache policy cursor 2>/dev/null | grep -q "downloads.cursor.com/aptrepo"; then
    echo "   ✓ APT 저장소 활성화됨"
else
    echo "   ⚠️  APT 저장소가 정상 등록되지 않았습니다."
    echo "   수동 업데이트가 필요할 수 있습니다."
    REPO_OK=false
fi

# 데스크톱 데이터베이스 업데이트 (도크에 아이콘 표시)
if command -v update-desktop-database &> /dev/null; then
    run_as_root update-desktop-database /usr/share/applications/ 2>/dev/null || true
fi

# 설치 로그 보관 정책: CI/자동화 모드에서만 삭제, 수동 실행은 유지
if [ "${CI:-false}" = "true" ] || [ "${NONINTERACTIVE:-false}" = "true" ]; then
    rm -f "$INSTALL_LOG" 2>/dev/null || true
else
    if [ -f "$INSTALL_LOG" ]; then
        echo ""
        echo "   설치 로그 보관: $INSTALL_LOG"
    fi
fi

# ──────────────────────────────────────────────
# 최종 결과 출력
# ──────────────────────────────────────────────

echo ""
if [ "$REPO_OK" = true ] && [ "$KEY_OK" = true ]; then
    echo "┌────────────────────────────────────────────────────┐"
    echo "│  ✅ Cursor AI 설치 완료!                            │"
    echo "│                                                    │"
    echo "│  버전: $INSTALLED_VERSION"
    echo "│                                                    │"
    echo "│  실행: cursor                                      │"
    echo "│  또는: 앱 메뉴에서 'Cursor' 검색                    │"
    echo "│                                                    │"
    echo "│  📌 업데이트 방법:                                  │"
    echo "│     - IDE: Help → Check for Updates               │"
    echo "│     - APT: sudo apt update && sudo apt upgrade cursor │"
    echo "└────────────────────────────────────────────────────┘"
else
    echo "┌────────────────────────────────────────────────────┐"
    echo "│  ⚠️  Cursor AI 설치 완료 (일부 경고 있음)            │"
    echo "│                                                    │"
    echo "│  버전: $INSTALLED_VERSION"
    echo "│                                                    │"
    echo "│  실행: cursor                                      │"
    echo "│  또는: 앱 메뉴에서 'Cursor' 검색                    │"
    echo "│                                                    │"
    echo "│  ⚠️  자동 업데이트 확인 필요:                        │"
    echo "│     APT 저장소 또는 GPG 키 등록에 문제가 있습니다.    │"
    echo "│     IDE 내장 업데이트를 사용하거나,                  │"
    echo "│     .deb 파일을 직접 다운로드하여 설치하세요.         │"
    echo "│                                                    │"
    echo "│  📌 수동 업데이트:                                  │"
    echo "│     - IDE: Help → Check for Updates               │"
    echo "│     - 직접: https://cursor.com/download           │"
    echo "└────────────────────────────────────────────────────┘"
fi
echo ""
