#!/bin/bash
#
# 99_uninstall.sh
# Flameshot 삭제 스크립트
#
# 사용법:
#   ./99_uninstall.sh          # 기본 삭제 (설정 파일 유지)
#   ./99_uninstall.sh --purge  # 완전 삭제 (설정 파일도 삭제)
#

set -e

# root로 실행 중인지 확인
if [ "$EUID" -ne 0 ]; then
    echo "❌ Uninstall must be run as root"
    exit 1
fi

# --purge 옵션 확인
PURGE_MODE=false
if [[ "$1" == "--purge" ]]; then
    PURGE_MODE=true
fi

# 환경 변수 설정 (비대화형 모드)
export DEBIAN_FRONTEND=noninteractive
export APT_LISTCHANGES_FRONTEND=none

# PATH 설정 (rustup 등 사용자 설치 도구를 위해)
export PATH="$HOME/.cargo/bin:$PATH"

# sudo 공통 라이브러리 로드 (run_as_root 헬퍼 사용을 위해)
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../../lib/sudo.sh"

# 실제 사용자 홈 디렉토리 (root로 실행되므로 SUDO_USER 사용)
if [[ -n "$SUDO_USER" ]]; then
    USER_HOME=$(getent passwd "$SUDO_USER" | cut -d: -f6)
else
    USER_HOME="$HOME"
fi

echo "=========================================="
if $PURGE_MODE; then
    echo "  Flameshot 완전 삭제 (--purge)"
else
    echo "  Flameshot 삭제"
fi
echo "=========================================="
echo ""

# ============================================
# [1/6] 실행 중인 Flameshot 종료
# ============================================
echo "[1/6] 실행 중인 Flameshot 종료..."
pkill flameshot 2>/dev/null || true
echo "   ✓ 완료"

# ============================================
# [2/6] Autostart 파일 제거 (항상)
# ============================================
echo "[2/6] Autostart 설정 제거..."
AUTOSTART_FILE="$USER_HOME/.config/autostart/flameshot.desktop"
if [[ -f "$AUTOSTART_FILE" ]]; then
    rm -f "$AUTOSTART_FILE"
    echo "   ✓ 제거됨: $AUTOSTART_FILE"
else
    echo "   ✓ 이미 없음"
fi

# ============================================
# [3/6] 설정 파일 처리 (--purge 시에만 삭제)
# ============================================
echo "[3/6] 설정 파일 처리..."
FLAMESHOT_CONFIG_DIR="$USER_HOME/.config/flameshot"
if $PURGE_MODE; then
    if [[ -d "$FLAMESHOT_CONFIG_DIR" ]]; then
        rm -rf "$FLAMESHOT_CONFIG_DIR"
        echo "   ✓ 설정 디렉토리 삭제됨: $FLAMESHOT_CONFIG_DIR"
    else
        echo "   ✓ 설정 디렉토리 없음"
    fi
else
    echo "   ✓ 설정 파일 유지 (--purge 옵션으로 삭제 가능)"
fi

# ============================================
# [4/6] 단축키 설정 복원 (SUDO_USER 권한으로 실행)
# ============================================
echo "[4/6] GNOME 기본 스크린샷 단축키 복원..."

# gsettings는 사용자 권한 + DISPLAY/DBUS 환경변수가 필요
if [[ -n "$SUDO_USER" ]]; then
    # 사용자의 DBUS 세션 버스 주소 찾기
    USER_UID=$(id -u "$SUDO_USER")
    DBUS_ADDR="unix:path=/run/user/$USER_UID/bus"
    
    # 환경변수를 전달하면서 gsettings 실행
    run_gsettings() {
        sudo -u "$SUDO_USER" XDG_RUNTIME_DIR="/run/user/$USER_UID" DBUS_SESSION_BUS_ADDRESS="$DBUS_ADDR" gsettings "$@" 2>/dev/null || true
    }
    
    # Flameshot 커스텀 단축키 제거
    run_gsettings set org.gnome.settings-daemon.plugins.media-keys custom-keybindings "[]"
    
    # GNOME 기본 스크린샷 단축키 복원 (트리거 방식: 빈 값 → 원래 값)
    run_gsettings set org.gnome.shell.keybindings show-screenshot-ui "['']"
    sleep 0.2
    run_gsettings set org.gnome.shell.keybindings show-screenshot-ui "['Print']"
    
    echo "   ✓ GNOME 기본 스크린샷 단축키 복원됨"
else
    echo "   ⚠️  SUDO_USER 없음 - 수동으로 단축키 복원 필요"
fi

# ============================================
# [5/6] gsd-media-keys 재시작 (단축키 즉시 적용)
# ============================================
echo "[5/6] 단축키 엔진 재시작 중..."
if [[ -n "$SUDO_USER" ]]; then
    USER_UID=$(id -u "$SUDO_USER")
    pkill -u "$USER_UID" -f gsd-media-keys 2>/dev/null || true
    sleep 0.5
    # gnome-session이 자동 재시작하지 않는 환경이 있으므로 수동 시작
    if ! pgrep -u "$USER_UID" -f gsd-media-keys > /dev/null 2>&1; then
        sudo -u "$SUDO_USER" DISPLAY=:1 XDG_RUNTIME_DIR="/run/user/$USER_UID" \
            nohup /usr/libexec/gsd-media-keys > /dev/null 2>&1 &
        sleep 0.5
    fi
    echo "   ✓ gsd-media-keys 재시작됨 (즉시 적용)"
else
    pkill -f gsd-media-keys 2>/dev/null || true
    sleep 0.5
    if ! pgrep -f gsd-media-keys > /dev/null 2>&1; then
        nohup /usr/libexec/gsd-media-keys > /dev/null 2>&1 &
        sleep 0.5
    fi
    echo "   ✓ gsd-media-keys 재시작됨"
fi

# ============================================
# [6/6] 패키지 제거
# ============================================
echo "[6/6] Flameshot 패키지 제거..."
run_as_root apt remove -y flameshot
echo ""

echo "✅ Flameshot 삭제 완료!"
if ! $PURGE_MODE; then
    echo ""
    echo "ℹ️  설정 파일이 유지되었습니다: $FLAMESHOT_CONFIG_DIR"
    echo "   완전히 삭제하려면: ./99_uninstall.sh --purge"
fi
echo ""
