#!/bin/bash
#
# 01_setup_repository.sh
# Docker 공식 APT 저장소 설정 (Docker Desktop용)
#
# 사용법: ./01_setup_repository.sh
# 필요한 설정: SUDO_PASSWORD (config.local.env)
# 참조: https://docs.docker.com/desktop/setup/install/linux/ubuntu/
#

set -euo pipefail

# 색상 정의
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# WSL 환경 감지 함수
is_wsl() {
    # 방법 1: /proc/version 파일 확인
    if [ -f /proc/version ]; then
        if grep -qi "microsoft\|wsl" /proc/version; then
            return 0
        fi
    fi
    
    # 방법 2: /proc/sys/kernel/osrelease 파일 확인
    if [ -f /proc/sys/kernel/osrelease ]; then
        if grep -qi "microsoft\|wsl" /proc/sys/kernel/osrelease; then
            return 0
        fi
    fi
    
    # 방법 3: 환경 변수 확인 (WSL2에서 설정됨)
    if [ -n "${WSL_DISTRO_NAME:-}" ] || [ -n "${WSL_INTEROP:-}" ]; then
        return 0
    fi
    
    return 1
}

# WSL 환경 확인 - Docker Desktop은 WSL에서 지원 안 함 (exit 1)
if is_wsl; then
    echo ""
    echo "┌────────────────────────────────────────────────────────┐"
    echo "│  ❌ WSL 환경 감지됨                                    │"
    echo "│                                                        │"
    echo "│  Docker Desktop for Linux는 WSL 환경에서 지원되지      │"
    echo "│  않습니다.                                             │"
    echo "│                                                        │"
    echo "│  대안 1: Windows Docker Desktop 사용                   │"
    echo "│    https://www.docker.com/products/docker-desktop/     │"
    echo "│                                                        │"
    echo "│  대안 2: docker-engine 토픽 사용 (CLI만, 무료)         │"
    echo "│    WSL 환경에서는 Docker Engine 설치를 권장합니다.     │"
    echo "│    부트캠프에서 'docker-engine' 토픽을 선택하세요.     │"
    echo "└────────────────────────────────────────────────────────┘"
    echo ""
    exit 1
fi

# sudo 공통 라이브러리 로드
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../../lib/sudo.sh"

# sudo 캐시 확인 (Tauri 앱 환경에서 필수)
if ! ensure_sudo_cache; then
    echo -e "${RED}❌ Sudo cache expired or not found${NC}"
    echo "Please verify your password in the password screen first."
    exit 1
fi

# 공통 모듈 로드 및 실행
COMMON_MODULE="$SCRIPT_DIR/../docker-common/setup_repository.sh"

if [ ! -f "$COMMON_MODULE" ]; then
    echo -e "${RED}❌ 공통 모듈을 찾을 수 없습니다: $COMMON_MODULE${NC}"
    exit 1
fi

# 공통 모듈의 함수 로드
source "$COMMON_MODULE"

# Docker 저장소 설정 실행
setup_docker_repository
