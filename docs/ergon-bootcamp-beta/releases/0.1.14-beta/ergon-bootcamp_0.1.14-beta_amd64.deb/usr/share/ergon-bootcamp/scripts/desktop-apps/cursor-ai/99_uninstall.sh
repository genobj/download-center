#!/bin/bash
#
# 99_uninstall.sh
# Cursor AI 삭제 스크립트 (APT 저장소 방식)
#
# 사용법: ./99_uninstall.sh
#

set -e

# 환경 변수 설정 (비대화형 모드)
export DEBIAN_FRONTEND=noninteractive
export APT_LISTCHANGES_FRONTEND=none

# 설정 (두 가지 형식 지원)
# 저장소 파일 경로
CURSOR_SOURCES_PATH="/etc/apt/sources.list.d/cursor.sources"
CURSOR_LIST_PATH="/etc/apt/sources.list.d/cursor.list"

# GPG 키 경로
CURSOR_GPG_AUTO="/usr/share/keyrings/anysphere.gpg"
CURSOR_GPG_MANUAL="/etc/apt/keyrings/cursor.gpg"

# Pinning
CURSOR_PIN_PATH="/etc/apt/preferences.d/cursor"

# sudo로 실행될 때 실제 사용자 홈 디렉토리 찾기
if [ -n "$SUDO_USER" ]; then
    REAL_HOME=$(getent passwd "$SUDO_USER" | cut -d: -f6)
else
    REAL_HOME="$HOME"
fi

# PATH 설정
export PATH="$REAL_HOME/.cargo/bin:$PATH"

# sudo 공통 라이브러리 로드
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../../lib/sudo.sh"

# sudo 캐시 확인 (Tauri 앱 환경에서 필수)
if ! ensure_sudo_cache; then
    echo -e "${RED}❌ Sudo cache expired or not found${NC}"
    echo "Please verify your password in the password screen first."
    exit 1
fi

echo "=========================================="
echo "  Cursor AI 삭제"
echo "=========================================="
echo ""

STEP=1

# Cursor 패키지가 설치되어 있는지 확인
if dpkg -l | grep -q "^ii  cursor "; then
    echo "[$STEP/5] Cursor AI 패키지 완전 제거 중..."
    run_as_root apt-get purge -y cursor || true
    echo "   ✓ 패키지 및 설정 파일 제거 완료"
    echo ""
    STEP=$((STEP + 1))
    
    echo "[$STEP/5] 불필요한 의존성 패키지 정리 중..."
    run_as_root apt-get autoremove -y || true
    echo "   ✓ 의존성 정리 완료"
    echo ""
    STEP=$((STEP + 1))
else
    echo "ℹ️  Cursor AI 패키지가 설치되어 있지 않습니다."
    echo ""
fi

# APT 저장소 파일 제거
echo "[$STEP/5] APT 저장소 파일 제거 중..."
REPO_REMOVED=false

# DEB822 형식 (Cursor 자동 등록)
if [ -f "$CURSOR_SOURCES_PATH" ]; then
    run_as_root rm -f "$CURSOR_SOURCES_PATH"
    echo "   ✓ 저장소 파일 제거: $CURSOR_SOURCES_PATH"
    REPO_REMOVED=true
fi

# 전통 형식 (수동 등록)
if [ -f "$CURSOR_LIST_PATH" ]; then
    run_as_root rm -f "$CURSOR_LIST_PATH"
    echo "   ✓ 저장소 파일 제거: $CURSOR_LIST_PATH"
    REPO_REMOVED=true
fi

if [ "$REPO_REMOVED" = false ]; then
    echo "   ℹ️  저장소 파일 없음 (이미 제거됨)"
fi
echo ""
STEP=$((STEP + 1))

# GPG 키 파일 제거
echo "[$STEP/5] GPG 키 파일 제거 중..."
GPG_REMOVED=false

# Cursor 자동 등록 키
if [ -f "$CURSOR_GPG_AUTO" ]; then
    run_as_root rm -f "$CURSOR_GPG_AUTO"
    echo "   ✓ GPG 키 제거: $CURSOR_GPG_AUTO"
    GPG_REMOVED=true
fi

# 수동 등록 키
if [ -f "$CURSOR_GPG_MANUAL" ]; then
    run_as_root rm -f "$CURSOR_GPG_MANUAL"
    echo "   ✓ GPG 키 제거: $CURSOR_GPG_MANUAL"
    GPG_REMOVED=true
fi

# 기타 cursor 관련 키 (패턴 매칭)
for gpg_file in /etc/apt/keyrings/cursor*.gpg /usr/share/keyrings/cursor*.gpg; do
    if [ -f "$gpg_file" ]; then
        run_as_root rm -f "$gpg_file"
        echo "   ✓ GPG 키 제거: $gpg_file"
        GPG_REMOVED=true
    fi
done

if [ "$GPG_REMOVED" = false ]; then
    echo "   ℹ️  GPG 키 파일 없음 (이미 제거됨)"
fi
echo ""
STEP=$((STEP + 1))

# APT Pinning 파일 제거
echo "[$STEP/5] APT Pinning 파일 제거 중..."
if [ -f "$CURSOR_PIN_PATH" ]; then
    run_as_root rm -f "$CURSOR_PIN_PATH"
    echo "   ✓ Pinning 파일 제거: $CURSOR_PIN_PATH"
else
    echo "   ℹ️  Pinning 파일 없음 (이미 제거됨)"
fi
echo ""

# 사용자 디렉토리의 cursor 관련 파일 제거 (선택적)
echo "[추가] 사용자 데이터 정리 중..."
CLEANED=false

if [ -d "$REAL_HOME/.local/share/cursor" ]; then
    rm -rf "$REAL_HOME/.local/share/cursor"
    echo "   ✓ 사용자 데이터 제거: ~/.local/share/cursor"
    CLEANED=true
fi

if [ -d "$REAL_HOME/.config/cursor" ]; then
    rm -rf "$REAL_HOME/.config/cursor"
    echo "   ✓ 설정 파일 제거: ~/.config/cursor"
    CLEANED=true
fi

if [ -d "$REAL_HOME/Applications/cursor" ]; then
    rm -rf "$REAL_HOME/Applications/cursor"
    echo "   ✓ Applications 디렉토리 정리"
    CLEANED=true
fi

# 데스크톱 파일 제거 (선택적)
if [ -f "$REAL_HOME/.local/share/applications/cursor.desktop" ]; then
    rm -f "$REAL_HOME/.local/share/applications/cursor.desktop"
    echo "   ✓ 데스크톱 파일 제거"
    CLEANED=true
fi

if [ "$CLEANED" = false ]; then
    echo "   ℹ️  정리할 사용자 데이터 없음"
fi
echo ""

# 데스크톱 데이터베이스 업데이트
if command -v update-desktop-database &> /dev/null; then
    update-desktop-database "$REAL_HOME/.local/share/applications/" 2>/dev/null || true
fi

echo "┌────────────────────────────────────────────────────┐"
echo "│  ✅ Cursor AI 삭제 완료!                            │"
echo "│                                                    │"
echo "│  제거된 항목:                                       │"
echo "│  - cursor 패키지 (apt purge)                        │"
echo "│  - APT 저장소 파일                                  │"
echo "│  - GPG 키 파일                                      │"
echo "│  - APT Pinning 파일                                 │"
echo "│  - 사용자 데이터 및 설정                             │"
echo "│                                                    │"
echo "│  💡 참고:                                          │"
echo "│  - 모든 Cursor 관련 파일이 정리되었습니다            │"
echo "│  - 재설치: ./01_install_cursor.sh                     │"
echo "└────────────────────────────────────────────────────┘"
echo ""
