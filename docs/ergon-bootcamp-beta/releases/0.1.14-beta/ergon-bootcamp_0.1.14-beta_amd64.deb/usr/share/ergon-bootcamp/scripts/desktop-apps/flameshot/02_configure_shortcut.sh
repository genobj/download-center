#!/bin/bash
#
# 02_configure_shortcut.sh
# Flameshot 키보드 단축키 설정
#
# 기능:
#   - X11/Wayland 모두: gsettings로 단축키 자동 설정
#   - GNOME 기본 스크린샷 단축키 해제
#
# 사용법: ./02_configure_shortcut.sh
#

set -e

echo "=========================================="
echo "  Flameshot 단축키 설정"
echo "=========================================="

# Pictures 폴더 확인/생성
PICTURES_DIR="$HOME/Pictures/Screenshots"
mkdir -p "$PICTURES_DIR"
echo "📁 스크린샷 저장 위치: $PICTURES_DIR"
echo ""

# ============================================
# 세션 타입 확인
# ============================================
SESSION_TYPE="${XDG_SESSION_TYPE:-unknown}"
echo "📺 세션 타입: $SESSION_TYPE"

# Wayland 세션 감지
IS_WAYLAND=false
if [[ "$SESSION_TYPE" == "wayland" ]]; then
    IS_WAYLAND=true
    echo "   ℹ️  Wayland 환경 - xdg-desktop-portal 기반 캡처 사용"
fi
echo ""

# ============================================
# [1/3] 기존 GNOME 스크린샷 단축키 제거
# ============================================
echo "[1/3] 기존 GNOME 스크린샷 단축키 제거 중..."

# GNOME Shell 스크린샷 키 비활성화
gsettings set org.gnome.shell.keybindings screenshot "[]" 2>/dev/null || true
gsettings set org.gnome.shell.keybindings screenshot-window "[]" 2>/dev/null || true
gsettings set org.gnome.shell.keybindings show-screenshot-ui "[]" 2>/dev/null || true

# GNOME Settings Daemon 스크린샷 키 비활성화 (media-keys 6개 항목)
gsettings set org.gnome.settings-daemon.plugins.media-keys screenshot "" 2>/dev/null || true
gsettings set org.gnome.settings-daemon.plugins.media-keys screenshot-clip "" 2>/dev/null || true
gsettings set org.gnome.settings-daemon.plugins.media-keys window-screenshot "" 2>/dev/null || true
gsettings set org.gnome.settings-daemon.plugins.media-keys window-screenshot-clip "" 2>/dev/null || true
gsettings set org.gnome.settings-daemon.plugins.media-keys area-screenshot "" 2>/dev/null || true
gsettings set org.gnome.settings-daemon.plugins.media-keys area-screenshot-clip "" 2>/dev/null || true

echo "   ✓ 기존 GNOME 스크린샷 단축키 제거됨"

# ============================================
# [2/3] Flameshot 단축키 설정 (X11/Wayland 공통)
# ============================================
echo "[2/3] Flameshot 단축키 설정 중..."

# 키바인딩 경로 정의
FLAMESHOT_PATH="/org/gnome/settings-daemon/plugins/media-keys/custom-keybindings/flameshot/"
FLAMESHOT_FULL_PATH="/org/gnome/settings-daemon/plugins/media-keys/custom-keybindings/flameshot-full/"

# 커스텀 키바인딩 목록 설정
gsettings set org.gnome.settings-daemon.plugins.media-keys custom-keybindings "['$FLAMESHOT_PATH', '$FLAMESHOT_FULL_PATH']"

# Flameshot GUI (Print Screen)
gsettings set org.gnome.settings-daemon.plugins.media-keys.custom-keybinding:$FLAMESHOT_PATH name "Flameshot"
gsettings set org.gnome.settings-daemon.plugins.media-keys.custom-keybinding:$FLAMESHOT_PATH command "flameshot gui --clipboard --path $PICTURES_DIR"
# 트리거 방식: 빈 값 → 원래 값 (로그아웃 없이 즉시 적용)
gsettings set org.gnome.settings-daemon.plugins.media-keys.custom-keybinding:$FLAMESHOT_PATH binding "''"
sleep 0.2
gsettings set org.gnome.settings-daemon.plugins.media-keys.custom-keybinding:$FLAMESHOT_PATH binding "Print"

echo "   ✓ Print Screen → Flameshot GUI"

# Flameshot Full Screen (Ctrl+Print Screen)
gsettings set org.gnome.settings-daemon.plugins.media-keys.custom-keybinding:$FLAMESHOT_FULL_PATH name "Flameshot Full Screen"
gsettings set org.gnome.settings-daemon.plugins.media-keys.custom-keybinding:$FLAMESHOT_FULL_PATH command "flameshot full --clipboard --path $PICTURES_DIR"
# 트리거 방식: 빈 값 → 원래 값 (로그아웃 없이 즉시 적용)
gsettings set org.gnome.settings-daemon.plugins.media-keys.custom-keybinding:$FLAMESHOT_FULL_PATH binding "''"
sleep 0.2
gsettings set org.gnome.settings-daemon.plugins.media-keys.custom-keybinding:$FLAMESHOT_FULL_PATH binding "<Control>Print"

echo "   ✓ Ctrl+Print Screen → 전체화면 캡처"

# ============================================
# [3/4] gsd-media-keys 재시작 (custom keybinding 즉시 적용)
# ============================================
echo "[3/4] 단축키 엔진 재시작 중..."
pkill -f gsd-media-keys 2>/dev/null || true
sleep 0.5
# gnome-session이 자동 재시작하지 않는 환경이 있으므로 수동 시작
if ! pgrep -f gsd-media-keys > /dev/null 2>&1; then
    nohup /usr/libexec/gsd-media-keys > /dev/null 2>&1 &
    sleep 0.5
fi
echo "   ✓ gsd-media-keys 재시작됨"

# ============================================
# [4/4] 설정 확인
# ============================================
echo "[4/4] 설정 확인 중..."

echo ""
echo "✅ Flameshot 단축키 설정 완료!"
echo ""
echo "┌─────────────────────────────────────────┐"
echo "│  설정된 단축키                          │"
echo "├─────────────────────────────────────────┤"
echo "│  Print Screen      → 영역 선택 캡처    │"
echo "│  Ctrl+Print Screen → 전체화면 캡처     │"
echo "└─────────────────────────────────────────┘"
echo ""
echo "📁 저장 위치: $PICTURES_DIR"
echo ""

# Wayland 환경 추가 안내
if $IS_WAYLAND; then
    echo "┌─────────────────────────────────────────────────────────────┐"
    echo "│  ℹ️  Wayland 환경 안내                                      │"
    echo "├─────────────────────────────────────────────────────────────┤"
    echo "│  • 최초 캡처 시 권한/화면 선택 팝업이 뜰 수 있습니다.       │"
    echo "│    (정상 동작입니다 - xdg-desktop-portal 기반)              │"
    echo "│  • 화면 선택 팝업에서 캡처할 화면/영역을 선택하세요.        │"
    echo "└─────────────────────────────────────────────────────────────┘"
    echo ""
fi
