#!/bin/bash
#
# 02_verify_setup.sh
# Portainer CE 설치 검증
#
# 사용법: ./02_verify_setup.sh
#
# 검증 항목:
#   1. Portainer 컨테이너 존재 여부
#   2. 컨테이너 실행 상태
#   3. 이미지 태그 확인
#   4. 포트 바인딩 확인 (127.0.0.1:9443)
#   5. 볼륨 확인 (portainer_data)
#   6. 웹 UI 응답 확인 (curl ready 체크)
#

set -euo pipefail

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

log_pass() { echo -e "${GREEN}[PASS]${NC} $*"; }
log_fail() { echo -e "${RED}[FAIL]${NC} $*"; }
log_warn() { echo -e "${YELLOW}[WARN]${NC} $*"; }
log_info() { echo -e "${GREEN}[INFO]${NC} $*"; }

PORTAINER_NAME="portainer"
PORTAINER_VOLUME="portainer_data"

echo ""
echo "=========================================="
echo "  Portainer CE 설치 검증"
echo "=========================================="
echo ""

VERIFICATION_PASSED=true

# ──────────────────────────────────────────────
# 1단계: 컨테이너 존재 여부
# ──────────────────────────────────────────────

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo " 1단계: Portainer 컨테이너 존재 확인"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

CONTAINER_ID=$(docker ps -aq -f "name=^${PORTAINER_NAME}$" 2>/dev/null || echo "")

if [ -n "$CONTAINER_ID" ]; then
    log_pass "Portainer 컨테이너 존재함 (ID: ${CONTAINER_ID:0:12})"
else
    log_fail "Portainer 컨테이너가 존재하지 않음"
    log_info "   설치 스크립트를 다시 실행하세요."
    exit 1
fi

echo ""

# ──────────────────────────────────────────────
# 2단계: 컨테이너 실행 상태
# ──────────────────────────────────────────────

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo " 2단계: 컨테이너 실행 상태 확인"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

CONTAINER_STATUS=$(docker inspect --format '{{.State.Status}}' "$PORTAINER_NAME" 2>/dev/null || echo "unknown")

if [ "$CONTAINER_STATUS" = "running" ]; then
    UPTIME=$(docker inspect --format '{{.State.StartedAt}}' "$PORTAINER_NAME" 2>/dev/null || echo "")
    log_pass "컨테이너 실행 중"
    log_info "   시작 시간: $UPTIME"
else
    log_fail "컨테이너가 실행 중이 아님 (상태: $CONTAINER_STATUS)"
    log_info "   시작 명령: docker start $PORTAINER_NAME"
    VERIFICATION_PASSED=false
fi

echo ""

# ──────────────────────────────────────────────
# 3단계: 이미지 태그 확인
# ──────────────────────────────────────────────

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo " 3단계: 이미지 태그 확인"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

CONTAINER_IMAGE=$(docker inspect --format '{{.Config.Image}}' "$PORTAINER_NAME" 2>/dev/null || echo "unknown")

if [[ "$CONTAINER_IMAGE" == *"portainer-ce"* ]]; then
    log_pass "Portainer CE 이미지 확인: $CONTAINER_IMAGE"
else
    log_warn "예상과 다른 이미지: $CONTAINER_IMAGE"
    VERIFICATION_PASSED=false
fi

echo ""

# ──────────────────────────────────────────────
# 4단계: 포트 바인딩 확인
# ──────────────────────────────────────────────

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo " 4단계: 포트 바인딩 확인"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

PORT_BINDING=$(docker inspect --format '{{range $p, $conf := .NetworkSettings.Ports}}{{range $conf}}{{.HostIp}}:{{.HostPort}}->{{$p}} {{end}}{{end}}' "$PORTAINER_NAME" 2>/dev/null || echo "")

if [[ "$PORT_BINDING" == *"127.0.0.1:9443"* ]]; then
    log_pass "포트 바인딩 정상: $PORT_BINDING"
    log_info "   로컬 전용 (외부 접근 불가)"
elif [[ "$PORT_BINDING" == *"9443"* ]]; then
    log_warn "포트 9443이 바인딩되었지만 127.0.0.1이 아닐 수 있음"
    log_info "   바인딩: $PORT_BINDING"
    log_info "   보안을 위해 127.0.0.1로 재설정을 권장합니다."
else
    log_fail "포트 9443이 바인딩되지 않음"
    VERIFICATION_PASSED=false
fi

echo ""

# ──────────────────────────────────────────────
# 5단계: 볼륨 확인
# ──────────────────────────────────────────────

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo " 5단계: 데이터 볼륨 확인"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

if docker volume inspect "$PORTAINER_VOLUME" > /dev/null 2>&1; then
    VOLUME_MOUNT=$(docker volume inspect --format '{{.Mountpoint}}' "$PORTAINER_VOLUME" 2>/dev/null || echo "")
    log_pass "데이터 볼륨 존재: $PORTAINER_VOLUME"
    log_info "   마운트 포인트: $VOLUME_MOUNT"
else
    log_warn "데이터 볼륨이 존재하지 않음: $PORTAINER_VOLUME"
    VERIFICATION_PASSED=false
fi

echo ""

# ──────────────────────────────────────────────
# 6단계: 웹 UI 응답 확인
# ──────────────────────────────────────────────

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo " 6단계: 웹 UI 응답 확인"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

if [ "$CONTAINER_STATUS" = "running" ]; then
    READY=false
    for i in $(seq 1 8); do
        HTTP_CODE=$(curl -sk -o /dev/null -w '%{http_code}' https://127.0.0.1:9443 2>/dev/null || echo "000")
        if [ "$HTTP_CODE" != "000" ]; then
            READY=true
            break
        fi
        sleep 2
    done

    if [ "$READY" = true ]; then
        log_pass "웹 UI 응답 확인 (HTTP $HTTP_CODE)"
        log_info "   접속: https://localhost:9443"
    else
        log_warn "웹 UI가 아직 응답하지 않음"
        log_info "   잠시 후 https://localhost:9443 에 접속해보세요."
    fi
else
    log_info "컨테이너 미실행으로 웹 UI 테스트 스킵"
fi

echo ""

# ──────────────────────────────────────────────
# 최종 결과
# ──────────────────────────────────────────────

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo " 검증 결과"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

if [ "$VERIFICATION_PASSED" = true ]; then
    log_info "✅ Portainer CE 설치 검증 완료!"
    echo ""
    echo "┌────────────────────────────────────────────────────┐"
    echo "│  ✅ Portainer CE 검증 완료!                         │"
    echo "│                                                    │"
    echo "│  접속: https://localhost:9443                      │"
    echo "│                                                    │"
    echo "│  ⚠️  인증서 경고가 표시되면 예외로 진행하세요.        │"
    echo "│  💡 처음 접속 시 관리자 계정을 생성하세요.            │"
    echo "└────────────────────────────────────────────────────┘"
else
    log_warn "⚠️  일부 검증 항목에서 경고가 발생했습니다."
    log_info "Portainer 컨테이너는 존재하지만, 추가 설정이 필요할 수 있습니다."
fi

echo ""
