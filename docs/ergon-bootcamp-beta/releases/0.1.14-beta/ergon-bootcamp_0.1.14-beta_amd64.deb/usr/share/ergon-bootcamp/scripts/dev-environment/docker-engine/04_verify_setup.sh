#!/bin/bash
#
# 04_verify_setup.sh
# Docker Engine 설치 검증
#
# 사용법: ./04_verify_setup.sh
#
# 4단계 검증:
#   1. docker --version (필수, exit 1)
#   2. docker compose version (WARN + 진단)
#   3. docker info (WARN, WSL에서 실패 가능)
#   4. docker run hello-world (INFO, 네트워크 문제)
#

set -euo pipefail

# 색상 정의
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# 로그 함수
log_info() {
    echo -e "${GREEN}[INFO]${NC} $*"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $*"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $*"
}

log_pass() {
    echo -e "${GREEN}[PASS]${NC} $*"
}

log_fail() {
    echo -e "${RED}[FAIL]${NC} $*"
}

# 패키지 설치 확인
is_pkg_installed() {
    dpkg-query -W -f='${Status}' "$1" 2>/dev/null | grep -q "install ok installed"
}

echo ""
echo "=========================================="
echo "  Docker Engine 설치 검증"
echo "=========================================="
echo ""

VERIFICATION_PASSED=true

# 1단계: docker --version (필수)
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo " 1단계: Docker CLI 설치 확인"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

if command -v docker >/dev/null 2>&1; then
    DOCKER_VERSION=$(docker --version 2>/dev/null || echo "버전 확인 실패")
    log_pass "Docker CLI 설치됨"
    log_info "   $DOCKER_VERSION"
else
    log_fail "Docker CLI가 설치되지 않음"
    log_error "설치 스크립트를 다시 실행하세요."
    exit 1
fi

echo ""

# 2단계: docker compose version (WARN)
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo " 2단계: Docker Compose 플러그인 확인"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

if docker compose version >/dev/null 2>&1; then
    COMPOSE_VERSION=$(docker compose version 2>/dev/null || echo "버전 확인 실패")
    log_pass "Docker Compose 플러그인 설치됨"
    log_info "   $COMPOSE_VERSION"
else
    log_warn "Docker Compose 플러그인이 설치되지 않음"
    
    # dpkg-query로 진단
    if is_pkg_installed "docker-compose-plugin"; then
        log_info "   패키지는 설치되어 있으나 동작하지 않음"
        log_info "   Docker 서비스 재시작 후 다시 확인하세요"
    else
        log_info "   패키지 설치 필요: sudo apt-get install docker-compose-plugin"
    fi
    
    VERIFICATION_PASSED=false
fi

echo ""

# 3단계: docker info (WARN, WSL에서 실패 가능)
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo " 3단계: Docker 데몬 연결 확인"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

if docker info >/dev/null 2>&1; then
    log_pass "Docker 데몬 연결 성공"
    
    # 추가 정보 표시
    DOCKER_ROOT=$(docker info 2>/dev/null | grep "Docker Root Dir" | awk '{print $4}' || echo "확인 불가")
    STORAGE_DRIVER=$(docker info 2>/dev/null | grep "Storage Driver" | awk '{print $3}' || echo "확인 불가")
    
    log_info "   Docker Root Dir: $DOCKER_ROOT"
    log_info "   Storage Driver: $STORAGE_DRIVER"
else
    log_warn "Docker 데몬에 연결할 수 없음"
    
    # 원인 진단
    if [ ! -S /var/run/docker.sock ]; then
        log_info "   Docker 소켓이 존재하지 않음 (/var/run/docker.sock)"
        log_info "   Docker 서비스가 실행 중인지 확인하세요:"
        log_info "     sudo systemctl status docker"
        log_info "     또는: sudo service docker status"
    elif ! groups | grep -q docker && [ "$EUID" -ne 0 ]; then
        log_info "   현재 사용자가 docker 그룹에 속하지 않음"
        log_info "   로그아웃 후 재로그인하거나 'newgrp docker' 실행"
    else
        log_info "   WSL 환경에서는 dockerd가 수동 실행이 필요할 수 있음:"
        log_info "     sudo dockerd &"
    fi
    
    VERIFICATION_PASSED=false
fi

echo ""

# 4단계: docker run hello-world (INFO, 네트워크 문제)
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo " 4단계: 컨테이너 실행 테스트"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# docker info가 성공한 경우에만 실행
if docker info >/dev/null 2>&1; then
    log_info "hello-world 컨테이너 실행 중..."
    
    if docker run --rm hello-world >/dev/null 2>&1; then
        log_pass "컨테이너 실행 성공"
        log_info "   Docker가 정상적으로 동작합니다!"
    else
        log_info "hello-world 컨테이너 실행 실패"
        log_info "   네트워크 문제이거나 이미지 다운로드 실패"
        log_info "   프록시 설정을 확인하거나 나중에 다시 시도하세요"
        # 이 단계 실패는 치명적이지 않음
    fi
else
    log_info "Docker 데몬 미연결로 테스트 스킵"
fi

echo ""

# 5단계: Docker context 설정
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo " 5단계: Docker Context 설정"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# Docker Engine용 context (default)로 설정
CURRENT_CONTEXT=$(docker context show 2>/dev/null || echo "unknown")

if [ "$CURRENT_CONTEXT" != "default" ]; then
    log_info "Docker context를 'default'로 설정 중..."
    if docker context use default >/dev/null 2>&1; then
        log_pass "Docker context가 'default'로 설정됨"
    else
        log_warn "Docker context 설정 실패"
        log_info "   수동으로 실행하세요: docker context use default"
    fi
else
    log_pass "Docker context가 이미 'default'로 설정됨"
fi

echo ""

# 최종 결과
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo " 검증 결과"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

if [ "$VERIFICATION_PASSED" = true ]; then
    log_info "✅ Docker Engine 설치 검증 완료!"
else
    log_warn "⚠️  일부 검증 항목에서 경고가 발생했습니다."
    log_info "Docker CLI는 설치되었지만, 추가 설정이 필요할 수 있습니다."
fi

echo ""

# Docker Desktop 공존 여부 확인 및 안내
if is_pkg_installed "docker-desktop"; then
    echo "┌────────────────────────────────────────────────────────────────┐"
    echo "│  ℹ️  Docker Desktop과 Docker Engine이 함께 설치되어 있습니다  │"
    echo "│                                                                │"
    echo "│  현재 Docker Engine (default context)을 사용하도록 설정됨     │"
    echo "│                                                                │"
    echo "│  Docker 전환 방법:                                             │"
    echo "│    Engine 사용:  docker context use default                    │"
    echo "│    Desktop 사용: docker context use desktop-linux              │"
    echo "│                                                                │"
    echo "│  현재 context 확인: docker context ls                          │"
    echo "│                                                                │"
    echo "│  참고: 두 Docker는 독립적으로 동작하며, 컨테이너/이미지가      │"
    echo "│        각각 별도로 관리됩니다.                                 │"
    echo "└────────────────────────────────────────────────────────────────┘"
    echo ""
fi
