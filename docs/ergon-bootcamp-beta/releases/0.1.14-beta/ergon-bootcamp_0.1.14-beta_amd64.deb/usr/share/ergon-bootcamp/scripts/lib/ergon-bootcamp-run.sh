#!/bin/bash
#
# ergon-bootcamp-run.sh
# Ergon Boot Camp 스크립트 실행 래퍼
# 보안: 경로 검증 및 allowlist 기반 실행
#
# 이 스크립트는 /usr/local/sbin/ergon-bootcamp-run에 설치됩니다.
# sudoers 파일에서 이 래퍼만 NOPASSWD로 허용하여 보안을 강화합니다.

set -euo pipefail

# --self-test 옵션 처리
if [[ "${1:-}" == "--self-test" ]]; then
    echo "Wrapper script is working correctly"
    exit 0
fi

# 스크립트 경로 확인
if [[ $# -lt 1 ]]; then
    echo "Error: Script path is required" >&2
    echo "Usage: $0 <script_path> [args...]" >&2
    exit 1
fi

SCRIPT_PATH="$1"
shift  # 나머지 인자는 스크립트에 전달

# 1. realpath로 경로 정규화 (심볼릭 링크 해결 및 절대 경로 변환)
if ! NORMALIZED_PATH=$(realpath "$SCRIPT_PATH" 2>/dev/null); then
    echo "Error: Failed to resolve script path: $SCRIPT_PATH" >&2
    exit 1
fi

# 2. boot-camp/scripts/ 하위인지 검증
if [[ ! "$NORMALIZED_PATH" =~ /boot-camp/scripts/ ]]; then
    echo "Error: Script must be in boot-camp/scripts/ directory" >&2
    echo "Normalized path: $NORMALIZED_PATH" >&2
    exit 1
fi

# 3. 확장자 .sh 검증
if [[ ! "$NORMALIZED_PATH" =~ \.sh$ ]]; then
    echo "Error: Only .sh scripts are allowed" >&2
    exit 1
fi

# 4. 파일 존재 및 실행 가능 여부 확인
if [[ ! -f "$NORMALIZED_PATH" ]]; then
    echo "Error: Script not found: $NORMALIZED_PATH" >&2
    exit 1
fi

if [[ ! -x "$NORMALIZED_PATH" ]]; then
    echo "Error: Script is not executable: $NORMALIZED_PATH" >&2
    exit 1
fi

# 5. 스크립트 실행
exec bash "$NORMALIZED_PATH" "$@"

