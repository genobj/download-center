#!/bin/bash
#
# 01_install_portainer.sh
# Portainer CE 컨테이너 배포 (Docker 볼륨 + docker run, 로컬 전용)
#
# 사용법: ./01_install_portainer.sh
# 필요한 설정: SUDO_PASSWORD (config.local.env)
#
# 참고: Docker Engine이 설치 및 실행 중이어야 합니다.
#       포트는 127.0.0.1:9443에만 바인딩됩니다 (외부 접근 불가).
#
# 보안 주의: Portainer는 Docker socket을 통해 호스트 Docker를 제어합니다.
#           사실상 호스트 루트급 권한을 가지므로 신뢰된 환경에서만 사용하세요.
#

set -e

PORTAINER_IMAGE="portainer/portainer-ce:lts"
PORTAINER_NAME="portainer"
PORTAINER_VOLUME="portainer_data"
PORTAINER_PORT="127.0.0.1:9443:9443"

# sudo 공통 라이브러리 로드
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../../lib/sudo.sh"

# ──────────────────────────────────────────────
# 헬퍼 함수
# ──────────────────────────────────────────────

# 비대화형 모드 판별
is_noninteractive() {
    [ "${CI:-false}" = "true" ] || [ "${NONINTERACTIVE:-false}" = "true" ] || { ! [ -t 0 ] || ! [ -t 1 ]; }
}

# Docker 명령 실행 (그룹 권한 fallback 포함)
# Docker Engine 설치 직후 재로그인 전에도 동작하도록 3단계 fallback
docker_cmd() {
    if docker info > /dev/null 2>&1; then
        docker "$@"
    elif sg docker -c "docker info" > /dev/null 2>&1; then
        sg docker -c "docker $*"
    else
        run_as_root docker "$@"
    fi
}

# 기존 컨테이너 구성이 기대값과 일치하는지 확인
is_config_matching() {
    local image port volume_data volume_sock
    image=$(docker inspect --format '{{.Config.Image}}' "$PORTAINER_NAME" 2>/dev/null || echo "")
    port=$(docker inspect --format '{{range $p, $conf := .NetworkSettings.Ports}}{{range $conf}}{{.HostIp}}:{{.HostPort}}{{end}}{{end}}' "$PORTAINER_NAME" 2>/dev/null || echo "")
    volume_data=$(docker inspect --format '{{range .Mounts}}{{if eq .Destination "/data"}}{{.Name}}{{end}}{{end}}' "$PORTAINER_NAME" 2>/dev/null || echo "")
    volume_sock=$(docker inspect --format '{{range .Mounts}}{{if eq .Destination "/var/run/docker.sock"}}{{.Source}}{{end}}{{end}}' "$PORTAINER_NAME" 2>/dev/null || echo "")

    [[ "$image" == *"portainer-ce"* ]] && \
    [[ "$port" == *"127.0.0.1"* ]] && \
    [ "$volume_data" = "$PORTAINER_VOLUME" ] && \
    [ "$volume_sock" = "/var/run/docker.sock" ]
}

# ──────────────────────────────────────────────
# sudo 캐시 확인
# ──────────────────────────────────────────────

if ! ensure_sudo_cache; then
    echo -e "${RED}❌ Sudo cache expired or not found${NC}"
    echo "Please verify your password in the password screen first."
    exit 1
fi

echo "=========================================="
echo "  Portainer CE 설치"
echo "=========================================="

# ──────────────────────────────────────────────
# Docker 데몬 실행 확인
# ──────────────────────────────────────────────

echo ""
echo "[1/4] Docker 데몬 확인 중..."

if ! docker_cmd info > /dev/null 2>&1; then
    echo "   ❌ Docker 데몬에 연결할 수 없습니다."
    echo ""
    echo "   Docker Engine이 설치 및 실행 중이어야 합니다."
    echo "   1. Docker Engine 설치: 부트캠프에서 'Docker Engine' 토픽 실행"
    echo "   2. Docker 서비스 시작: sudo systemctl start docker"
    exit 1
fi

echo "   ✓ Docker 데몬 연결 확인"

# ──────────────────────────────────────────────
# 기존 Portainer 컨테이너 확인
# ──────────────────────────────────────────────

echo ""
echo "[2/4] 기존 Portainer 확인 중..."

EXISTING_ID=$(docker_cmd ps -aq -f "name=^${PORTAINER_NAME}$" 2>/dev/null || echo "")

if [ -n "$EXISTING_ID" ]; then
    EXISTING_STATUS=$(docker_cmd inspect --format '{{.State.Status}}' "$PORTAINER_NAME" 2>/dev/null || echo "unknown")
    EXISTING_IMAGE=$(docker_cmd inspect --format '{{.Config.Image}}' "$PORTAINER_NAME" 2>/dev/null || echo "unknown")

    echo "   ℹ️  기존 Portainer 컨테이너 발견"
    echo "   상태: $EXISTING_STATUS | 이미지: $EXISTING_IMAGE"

    if is_config_matching; then
        if [ "$EXISTING_STATUS" = "running" ]; then
            echo "   ✓ 구성이 정상이고 실행 중입니다. 추가 작업 없음."
            echo ""
            echo "┌────────────────────────────────────────────────────┐"
            echo "│  ✅ Portainer CE가 이미 실행 중입니다!              │"
            echo "│                                                    │"
            echo "│  접속: https://localhost:9443                      │"
            echo "└────────────────────────────────────────────────────┘"
            exit 0
        else
            echo "   컨테이너가 중지 상태입니다. 시작합니다..."
            docker_cmd start "$PORTAINER_NAME" > /dev/null 2>&1
            echo "   ✓ Portainer 시작됨"
            # 아래 검증 단계로 진행
            SKIP_DEPLOY=true
        fi
    else
        echo "   ⚠️  구성이 기대값과 다릅니다. 재생성합니다."

        if ! is_noninteractive; then
            read -p "   기존 컨테이너를 재생성할까요? (데이터는 유지됩니다) (Y/n): " -n 1 -r
            echo
            if [[ $REPLY =~ ^[Nn]$ ]]; then
                echo "   설치를 건너뜁니다."
                exit 0
            fi
        fi

        echo "   기존 컨테이너 제거 중..."
        docker_cmd stop "$PORTAINER_NAME" > /dev/null 2>&1 || true
        docker_cmd rm "$PORTAINER_NAME" > /dev/null 2>&1 || true
        echo "   ✓ 기존 컨테이너 제거됨"
    fi
fi

# ──────────────────────────────────────────────
# 포트 충돌 확인 + 볼륨 생성 + 컨테이너 배포
# ──────────────────────────────────────────────

if [ "${SKIP_DEPLOY:-false}" != "true" ]; then
    echo ""
    echo "[3/4] Portainer CE 배포 중..."

    # 포트 충돌 확인
    if ss -Htlpn 'sport = :9443' 2>/dev/null | grep -q .; then
        echo "   ⚠️  포트 9443이 이미 사용 중입니다."
        echo "   다른 서비스가 9443 포트를 사용하고 있는지 확인하세요:"
        echo "     ss -tlnp | grep 9443"
        exit 1
    fi

    # Docker 볼륨 생성 (이미 존재하면 무시)
    docker_cmd volume create "$PORTAINER_VOLUME" > /dev/null 2>&1 || true
    echo "   ✓ Docker 볼륨 준비: $PORTAINER_VOLUME"

    # Portainer 컨테이너 배포
    echo "   Portainer 이미지 다운로드 및 배포 중..."
    if docker_cmd run -d \
        -p "$PORTAINER_PORT" \
        --name "$PORTAINER_NAME" \
        --restart=always \
        -v /var/run/docker.sock:/var/run/docker.sock \
        -v "${PORTAINER_VOLUME}:/data" \
        "$PORTAINER_IMAGE" > /dev/null 2>&1; then
        echo "   ✓ 컨테이너 배포 완료"
    else
        echo "   ❌ 컨테이너 배포 실패"
        echo "   로그 확인: docker logs $PORTAINER_NAME"
        exit 1
    fi
else
    echo ""
    echo "[3/4] 컨테이너 이미 시작됨 (배포 스킵)"
fi

# ──────────────────────────────────────────────
# 서비스 준비 확인
# ──────────────────────────────────────────────

echo ""
echo "[4/4] 서비스 준비 확인 중..."

READY=false
for i in $(seq 1 15); do
    if docker_cmd ps -q -f "name=^${PORTAINER_NAME}$" -f "status=running" 2>/dev/null | grep -q .; then
        HTTP_CODE=$(curl -sk -o /dev/null -w '%{http_code}' https://127.0.0.1:9443 2>/dev/null || echo "000")
        if [ "$HTTP_CODE" != "000" ]; then
            READY=true
            break
        fi
    fi
    sleep 2
done

if [ "$READY" = true ]; then
    echo "   ✓ Portainer 서비스 준비 완료 (HTTP $HTTP_CODE)"
else
    echo "   ⚠️  서비스가 아직 준비되지 않았을 수 있습니다."
    echo "   잠시 후 https://localhost:9443 에 접속해보세요."
fi

# ──────────────────────────────────────────────
# 최종 결과
# ──────────────────────────────────────────────

echo ""
echo "┌────────────────────────────────────────────────────┐"
echo "│  ✅ Portainer CE 설치 완료!                         │"
echo "│                                                    │"
echo "│  접속: https://localhost:9443                      │"
echo "│                                                    │"
echo "│  💡 처음 접속 시 관리자 계정을 생성하세요.            │"
echo "│                                                    │"
echo "│  ⚠️  브라우저에서 인증서 경고가 표시될 수 있습니다.    │"
echo "│     로컬 개발 환경이므로 예외로 진행하세요.           │"
echo "│                                                    │"
echo "│  🔒 보안 안내:                                      │"
echo "│     Portainer는 Docker socket을 통해 호스트         │"
echo "│     Docker를 제어합니다.                            │"
echo "│     신뢰된 환경에서만 사용하세요.                    │"
echo "└────────────────────────────────────────────────────┘"
echo ""
