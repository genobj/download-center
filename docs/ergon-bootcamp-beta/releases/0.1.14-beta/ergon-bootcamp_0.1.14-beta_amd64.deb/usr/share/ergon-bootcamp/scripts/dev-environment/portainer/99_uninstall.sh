#!/bin/bash
#
# 99_uninstall.sh
# Portainer CE 삭제
#
# 사용법: ./99_uninstall.sh [OPTIONS]
#
# 옵션:
#   --purge-data    Portainer 데이터 볼륨 삭제 (사용자 설정/계정 포함)
#   --remove-image  Portainer Docker 이미지 삭제
#

set -euo pipefail

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

log_info() { echo -e "${GREEN}[INFO]${NC} $*"; }
log_warn() { echo -e "${YELLOW}[WARN]${NC} $*"; }

PORTAINER_NAME="portainer"
PORTAINER_VOLUME="portainer_data"
PORTAINER_IMAGE="portainer/portainer-ce"

PURGE_DATA=false
REMOVE_IMAGE=false

for arg in "$@"; do
    case $arg in
        --purge-data)  PURGE_DATA=true ;;
        --remove-image) REMOVE_IMAGE=true ;;
    esac
done

# sudo 공통 라이브러리 로드
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../../lib/sudo.sh"

if ! ensure_sudo_cache; then
    echo -e "${RED}❌ Sudo cache expired or not found${NC}"
    echo "Please verify your password in the password screen first."
    exit 1
fi

echo ""
echo "=========================================="
echo "  Portainer CE 삭제"
echo "=========================================="
echo ""

log_info "옵션:"
log_info "   데이터 삭제: $PURGE_DATA"
log_info "   이미지 삭제: $REMOVE_IMAGE"
echo ""

# 1. 컨테이너 중지 및 삭제
log_info "Portainer 컨테이너 중지 및 삭제 중..."

if docker ps -aq -f "name=^${PORTAINER_NAME}$" 2>/dev/null | grep -q .; then
    docker stop "$PORTAINER_NAME" 2>/dev/null || true
    docker rm "$PORTAINER_NAME" 2>/dev/null || true
    log_info "   ✓ 컨테이너 삭제됨"
else
    log_info "   ℹ️  Portainer 컨테이너가 존재하지 않음"
fi

echo ""

# 2. 데이터 볼륨 삭제 (옵션)
if [ "$PURGE_DATA" = true ]; then
    log_info "Portainer 데이터 볼륨 삭제 중..."
    if docker volume inspect "$PORTAINER_VOLUME" > /dev/null 2>&1; then
        docker volume rm "$PORTAINER_VOLUME" 2>/dev/null || true
        log_info "   ✓ 데이터 볼륨 삭제됨: $PORTAINER_VOLUME"
    else
        log_info "   ℹ️  데이터 볼륨이 존재하지 않음"
    fi
else
    log_info "데이터 볼륨 보존됨 (삭제하려면 --purge-data 옵션 사용)"
    log_info "   $PORTAINER_VOLUME"
fi

echo ""

# 3. 이미지 삭제 (옵션)
if [ "$REMOVE_IMAGE" = true ]; then
    log_info "Portainer 이미지 삭제 중..."
    IMAGES=$(docker images -q "$PORTAINER_IMAGE" 2>/dev/null || echo "")
    if [ -n "$IMAGES" ]; then
        docker rmi $IMAGES 2>/dev/null || true
        log_info "   ✓ 이미지 삭제됨"
    else
        log_info "   ℹ️  Portainer 이미지가 존재하지 않음"
    fi
else
    log_info "이미지 보존됨 (삭제하려면 --remove-image 옵션 사용)"
fi

echo ""
log_info "✅ Portainer CE 삭제 완료!"
echo ""

if [ "$PURGE_DATA" = false ]; then
    log_info "재설치 시 기존 설정과 계정을 다시 사용할 수 있습니다."
fi

echo ""
