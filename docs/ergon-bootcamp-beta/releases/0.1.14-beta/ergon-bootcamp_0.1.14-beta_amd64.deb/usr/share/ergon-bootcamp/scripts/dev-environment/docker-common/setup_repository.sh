#!/bin/bash
#
# setup_repository.sh
# Docker 공식 APT 저장소 설정 (공통 모듈)
#
# 사용법: source setup_repository.sh && setup_docker_repository
# 또는:  ./setup_repository.sh (직접 실행)
#
# 정책:
#   - new-style sources 형식 사용 (docker.sources + docker.asc)
#   - 멱등성: GPG 키 검증 + sources 4개 라인 정규식 검사
#   - legacy 파일 정리 (정확한 파일명만)
#   - apt-get update는 변경 시에만 수행
#
# 참조: https://docs.docker.com/engine/install/ubuntu/
#

set -euo pipefail

# 색상 정의
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# 경로 정의
DOCKER_GPG_URL="https://download.docker.com/linux/ubuntu/gpg"
DOCKER_REPO_URL="https://download.docker.com/linux/ubuntu"
KEYRING_DIR="/etc/apt/keyrings"
KEYRING_FILE="$KEYRING_DIR/docker.asc"
SOURCES_FILE="/etc/apt/sources.list.d/docker.sources"

# Legacy 파일 경로 (정확한 파일명만)
LEGACY_LIST="/etc/apt/sources.list.d/docker.list"
LEGACY_GPG="/etc/apt/keyrings/docker.gpg"
LEGACY_TRUSTED_GPG="/etc/apt/trusted.gpg.d/docker.gpg"

# 플래그
REPO_CHANGED=false

# 로그 함수
log_info() {
    echo -e "${GREEN}[INFO]${NC} $*"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $*"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $*"
}

# 패키지 설치 확인
is_pkg_installed() {
    dpkg-query -W -f='${Status}' "$1" 2>/dev/null | grep -q "install ok installed"
}

# GPG 키 유효성 검증
is_gpg_key_valid() {
    local keyfile="$1"
    
    if [ ! -f "$keyfile" ]; then
        return 1
    fi
    
    # gpg --show-keys로 파싱 가능 여부 확인
    if gpg --show-keys "$keyfile" >/dev/null 2>&1; then
        return 0
    fi
    
    return 1
}

# sources 파일 유효성 검증 (4개 라인 정규식)
is_sources_valid() {
    local sourcefile="$1"
    local codename="$2"
    
    if [ ! -f "$sourcefile" ]; then
        return 1
    fi
    
    # 4개 라인 정규식 검사
    if grep -Eq "^URIs:\s*https://download.docker.com/linux/ubuntu" "$sourcefile" && \
       grep -Eq "^Suites:\s*$codename" "$sourcefile" && \
       grep -Eq "^Components:\s*stable" "$sourcefile" && \
       grep -Eq "^Signed-By:\s*/etc/apt/keyrings/docker.asc" "$sourcefile"; then
        return 0
    fi
    
    return 1
}

# OS 코드네임 확인
get_ubuntu_codename() {
    if [ -f /etc/os-release ]; then
        # shellcheck source=/dev/null
        . /etc/os-release
        echo "${UBUNTU_CODENAME:-$VERSION_CODENAME}"
    else
        log_error "/etc/os-release 파일을 찾을 수 없습니다"
        return 1
    fi
}

# Ubuntu 배포판 확인
check_ubuntu_distro() {
    if [ -f /etc/os-release ]; then
        # shellcheck source=/dev/null
        . /etc/os-release
        if [ "${ID:-}" != "ubuntu" ]; then
            log_warn "Ubuntu가 아닌 배포판 감지됨: ${ID:-unknown}"
            log_warn "이 스크립트는 Ubuntu용으로 작성되었습니다."
            log_warn "다른 배포판에서는 정상 동작하지 않을 수 있습니다."
            echo ""
        fi
    fi
}

# Legacy 파일 정리
cleanup_legacy_files() {
    log_info "Legacy 파일 확인 중..."
    
    # docker.list 제거
    if [ -f "$LEGACY_LIST" ]; then
        log_info "   → Legacy 파일 제거: $LEGACY_LIST"
        run_as_root rm -f "$LEGACY_LIST"
        REPO_CHANGED=true
    fi
    
    # docker.gpg 제거 (keyrings 디렉토리)
    if [ -f "$LEGACY_GPG" ]; then
        log_info "   → Legacy 파일 제거: $LEGACY_GPG"
        run_as_root rm -f "$LEGACY_GPG"
        REPO_CHANGED=true
    fi
    
    # trusted.gpg.d/docker.gpg는 경고만 (시스템에서 사용 중일 수 있음)
    if [ -f "$LEGACY_TRUSTED_GPG" ]; then
        log_warn "   → Legacy 파일 발견 (수동 확인 필요): $LEGACY_TRUSTED_GPG"
        log_warn "      이 파일은 다른 소프트웨어에서 사용 중일 수 있어 자동 제거하지 않습니다."
    fi
}

# 필수 의존성 설치
install_dependencies() {
    log_info "필수 의존성 확인 중..."
    
    local deps_to_install=()
    
    for pkg in ca-certificates curl gnupg; do
        if ! is_pkg_installed "$pkg"; then
            deps_to_install+=("$pkg")
        fi
    done
    
    if [ ${#deps_to_install[@]} -gt 0 ]; then
        log_info "   → 설치 필요: ${deps_to_install[*]}"
        run_as_root apt-get update -qq
        run_as_root apt-get install -y "${deps_to_install[@]}"
    else
        log_info "   ✓ 모든 의존성이 이미 설치됨"
    fi
}

# GPG 키 설정
setup_gpg_key() {
    local codename="$1"
    
    log_info "Docker GPG 키 설정 중..."
    
    # 키링 디렉토리 생성
    if [ ! -d "$KEYRING_DIR" ]; then
        run_as_root install -m 0755 -d "$KEYRING_DIR"
    fi
    
    # 기존 키 유효성 검사
    if is_gpg_key_valid "$KEYRING_FILE"; then
        log_info "   ✓ 유효한 GPG 키가 이미 존재함: $KEYRING_FILE"
        return 0
    fi
    
    # 키 다운로드 및 저장
    log_info "   → GPG 키 다운로드 중..."
    
    if ! curl -fsSL "$DOCKER_GPG_URL" | sudo tee "$KEYRING_FILE" > /dev/null 2>&1; then
        log_error "GPG 키 다운로드 실패"
        log_error "네트워크 연결 또는 프록시 설정을 확인하세요."
        log_error "내부망 환경인 경우, 방화벽에서 $DOCKER_GPG_URL 접근을 허용해야 합니다."
        return 1
    fi
    
    run_as_root chmod a+r "$KEYRING_FILE"
    
    # 다운로드한 키 검증
    if ! is_gpg_key_valid "$KEYRING_FILE"; then
        log_error "다운로드한 GPG 키가 유효하지 않습니다"
        run_as_root rm -f "$KEYRING_FILE"
        return 1
    fi
    
    log_info "   ✓ GPG 키 저장됨: $KEYRING_FILE"
    REPO_CHANGED=true
}

# sources 파일 설정
setup_sources_file() {
    local codename="$1"
    local arch
    arch=$(dpkg --print-architecture)
    
    log_info "Docker APT 저장소 설정 중..."
    
    # 기존 sources 유효성 검사
    if is_sources_valid "$SOURCES_FILE" "$codename"; then
        log_info "   ✓ 유효한 sources 파일이 이미 존재함: $SOURCES_FILE"
        return 0
    fi
    
    # new-style sources 파일 생성
    log_info "   → sources 파일 생성 중..."
    
    cat << EOF | sudo tee "$SOURCES_FILE" > /dev/null
Types: deb
URIs: $DOCKER_REPO_URL
Suites: $codename
Components: stable
Architectures: $arch
Signed-By: $KEYRING_FILE
EOF

    log_info "   ✓ sources 파일 저장됨: $SOURCES_FILE"
    REPO_CHANGED=true
}

# apt-get update 수행 (변경 시에만)
update_apt_cache() {
    if [ "$REPO_CHANGED" = true ]; then
        log_info "패키지 목록 업데이트 중..."
        if ! run_as_root apt-get update -qq; then
            log_error "apt-get update 실패"
            log_error "저장소 설정을 확인하세요: $SOURCES_FILE"
            return 1
        fi
        log_info "   ✓ 패키지 목록 업데이트 완료"
    else
        log_info "저장소 변경 없음 - apt-get update 스킵"
    fi
}

# 메인 함수
setup_docker_repository() {
    echo ""
    echo "=========================================="
    echo "  Docker APT 저장소 설정 (공통 모듈)"
    echo "=========================================="
    echo ""
    
    # Ubuntu 배포판 확인
    check_ubuntu_distro
    
    # 코드네임 확인
    local codename
    codename=$(get_ubuntu_codename)
    
    if [ -z "$codename" ]; then
        log_error "Ubuntu 코드네임을 확인할 수 없습니다"
        return 1
    fi
    
    log_info "Ubuntu 코드네임: $codename"
    echo ""
    
    # 1. 필수 의존성 설치
    install_dependencies
    echo ""
    
    # 2. Legacy 파일 정리
    cleanup_legacy_files
    echo ""
    
    # 3. GPG 키 설정
    if ! setup_gpg_key "$codename"; then
        return 1
    fi
    echo ""
    
    # 4. sources 파일 설정
    if ! setup_sources_file "$codename"; then
        return 1
    fi
    echo ""
    
    # 5. apt-get update
    if ! update_apt_cache; then
        return 1
    fi
    
    echo ""
    log_info "✅ Docker APT 저장소 설정 완료!"
    echo ""
    
    # REPO_CHANGED 플래그 export (호출자에서 사용 가능)
    export REPO_CHANGED
}

# 직접 실행 시 (source가 아닌 경우)
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    # sudo 공통 라이브러리 로드
    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    
    if [ -f "$SCRIPT_DIR/../lib/sudo.sh" ]; then
        # shellcheck source=/dev/null
        source "$SCRIPT_DIR/../lib/sudo.sh"
    elif [ -f "$SCRIPT_DIR/../../lib/sudo.sh" ]; then
        # shellcheck source=/dev/null
        source "$SCRIPT_DIR/../../lib/sudo.sh"
    else
        # run_as_root fallback
        run_as_root() {
            if [ "$EUID" -eq 0 ]; then
                "$@"
            else
                sudo "$@"
            fi
        }
    fi
    
    # sudo 캐시 확인
    if ! ensure_sudo_cache 2>/dev/null; then
        log_error "Sudo 권한이 필요합니다"
        exit 1
    fi
    
    setup_docker_repository
fi
