#!/bin/bash
#
# 03_configure_user.sh
# Docker 그룹에 사용자 추가
#
# 사용법: ./03_configure_user.sh [--user=USERNAME]
# 필요한 설정: SUDO_PASSWORD (config.local.env)
#
# 옵션:
#   --user=USERNAME   특정 사용자 지정 (기본: SUDO_USER 또는 현재 사용자)
#

set -euo pipefail

# 색상 정의
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# 로그 함수
log_info() {
    echo -e "${GREEN}[INFO]${NC} $*"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $*"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $*"
}

# 옵션 파싱
TARGET_USER=""

for arg in "$@"; do
    case $arg in
        --user=*)
            TARGET_USER="${arg#*=}"
            shift
            ;;
        *)
            ;;
    esac
done

# 타깃 유저 결정: --user 옵션 최우선 → SUDO_USER → whoami
if [ -z "$TARGET_USER" ]; then
    if [ -n "${SUDO_USER:-}" ]; then
        TARGET_USER="$SUDO_USER"
    else
        TARGET_USER="$(whoami)"
    fi
fi

# sudo 공통 라이브러리 로드
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../../lib/sudo.sh"

# sudo 캐시 확인
if ! ensure_sudo_cache; then
    echo -e "${RED}❌ Sudo cache expired or not found${NC}"
    echo "Please verify your password in the password screen first."
    exit 1
fi

echo ""
echo "=========================================="
echo "  Docker 사용자 그룹 설정"
echo "=========================================="
echo ""

# 1. 사용자 존재 확인
log_info "타깃 사용자: $TARGET_USER"

if ! id "$TARGET_USER" >/dev/null 2>&1; then
    log_error "사용자를 찾을 수 없습니다: $TARGET_USER"
    exit 1
fi

# 2. root 체크 (root에게 docker 그룹 추가는 의미 없음)
if [ "$TARGET_USER" = "root" ]; then
    log_error "root 사용자에게 docker 그룹 추가는 의미가 없습니다."
    log_error "일반 사용자를 지정하세요: --user=USERNAME"
    exit 1
fi

echo ""

# 3. docker 그룹 생성 (이미 존재하면 무시)
log_info "docker 그룹 확인 중..."

if ! getent group docker >/dev/null 2>&1; then
    log_info "   → docker 그룹 생성 중..."
    # AD/LDAP 환경에서 실패할 수 있으므로 || true
    if run_as_root groupadd docker 2>/dev/null; then
        log_info "   ✓ docker 그룹 생성됨"
    else
        log_warn "   docker 그룹 생성 실패 (이미 존재하거나 AD/LDAP 환경일 수 있음)"
    fi
else
    log_info "   ✓ docker 그룹이 이미 존재함"
fi

echo ""

# 4. 사용자를 docker 그룹에 추가
log_info "사용자를 docker 그룹에 추가 중..."

# 이미 그룹에 있는지 확인
if id -nG "$TARGET_USER" | grep -qw docker; then
    log_info "   ✓ $TARGET_USER 사용자가 이미 docker 그룹에 속해 있음"
else
    if run_as_root usermod -aG docker "$TARGET_USER"; then
        log_info "   ✓ $TARGET_USER 사용자를 docker 그룹에 추가함"
    else
        log_error "   ❌ 사용자 그룹 추가 실패"
        log_error "   수동으로 실행하세요: sudo usermod -aG docker $TARGET_USER"
        exit 1
    fi
fi

echo ""

# 5. 보안 주의 문구 출력
echo "┌────────────────────────────────────────────────────────────────┐"
echo "│  ⚠️  보안 주의사항                                             │"
echo "│                                                                │"
echo "│  docker 그룹은 사실상 root 권한과 동급입니다 (권한 상승 가능). │"
echo "│  필요한 사용자만 추가하세요.                                   │"
echo "│  보안이 중요한 환경에서는 rootless Docker를 검토하세요.        │"
echo "│                                                                │"
echo "│  참조: https://docs.docker.com/engine/security/rootless/       │"
echo "└────────────────────────────────────────────────────────────────┘"
echo ""

# 6. 적용 안내
log_info "그룹 변경을 적용하려면 다음 중 하나를 수행하세요:"
echo ""
echo "   방법 1: 로그아웃 후 재로그인"
echo "   방법 2: 현재 세션에서 즉시 적용 (새 셸 시작)"
echo "           newgrp docker"
echo ""

log_info "✅ 사용자 그룹 설정 완료!"
echo ""
