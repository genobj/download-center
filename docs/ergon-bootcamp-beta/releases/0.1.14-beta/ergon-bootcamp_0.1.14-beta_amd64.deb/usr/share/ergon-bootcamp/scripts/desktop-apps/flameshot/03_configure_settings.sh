#!/bin/bash
#
# 03_configure_settings.sh
# Flameshot 기본 설정 + Autostart + 즉시 시작
#
# 기능:
#   - 설정 파일 생성 (~/.config/flameshot/flameshot.ini) - 없을 때만
#   - Autostart 설정 (~/.config/autostart/flameshot.desktop)
#   - 저장 경로 디렉토리 생성
#   - 즉시 Flameshot 시작
#
# 사용법: ./03_configure_settings.sh
#

set -e

echo "=========================================="
echo "  Flameshot 기본 설정"
echo "=========================================="
echo ""

# ============================================
# 경로 설정
# ============================================
FLAMESHOT_CONFIG_DIR="$HOME/.config/flameshot"
FLAMESHOT_CONFIG_FILE="$FLAMESHOT_CONFIG_DIR/flameshot.ini"
AUTOSTART_DIR="$HOME/.config/autostart"
AUTOSTART_FILE="$AUTOSTART_DIR/flameshot.desktop"
SCREENSHOTS_DIR="$HOME/Pictures/Screenshots"

# ============================================
# GNOME 환경 감지
# ============================================
is_gnome_environment() {
    if [[ "${XDG_CURRENT_DESKTOP:-}" == *"GNOME"* ]] || [[ "${DESKTOP_SESSION:-}" == *"gnome"* ]]; then
        return 0
    fi
    return 1
}

IS_GNOME=false
if is_gnome_environment; then
    IS_GNOME=true
fi

# Wayland 세션 감지
IS_WAYLAND=false
if [[ "${XDG_SESSION_TYPE:-}" == "wayland" ]]; then
    IS_WAYLAND=true
fi

# ============================================
# [1/4] 스크린샷 저장 디렉토리 생성
# ============================================
echo "[1/4] 스크린샷 저장 디렉토리 확인 중..."
if [[ ! -d "$SCREENSHOTS_DIR" ]]; then
    mkdir -p "$SCREENSHOTS_DIR"
    echo "   ✓ 디렉토리 생성: $SCREENSHOTS_DIR"
else
    echo "   ✓ 디렉토리 존재: $SCREENSHOTS_DIR"
fi

# ============================================
# [2/4] Flameshot 설정 파일 생성 (없을 때만)
# ============================================
echo "[2/4] Flameshot 설정 파일 확인 중..."

mkdir -p "$FLAMESHOT_CONFIG_DIR"

if [[ ! -f "$FLAMESHOT_CONFIG_FILE" ]]; then
    # $HOME을 실제 경로로 치환하여 저장
    cat > "$FLAMESHOT_CONFIG_FILE" << EOF
[General]
savePath=${SCREENSHOTS_DIR}
showDesktopNotification=true
disabledTrayIcon=false
filenamePattern=%F_%H-%M
EOF
    echo "   ✓ 설정 파일 생성: $FLAMESHOT_CONFIG_FILE"
else
    echo "   ✓ 기존 설정 파일 유지: $FLAMESHOT_CONFIG_FILE"
fi

# ============================================
# [3/4] Autostart 설정
# ============================================
echo "[3/4] Autostart 설정 중..."

mkdir -p "$AUTOSTART_DIR"

# Autostart 파일 생성/갱신 (idempotent - 항상 최신 상태로)
cat > "$AUTOSTART_FILE" << 'EOF'
[Desktop Entry]
Name=Flameshot
Comment=Flameshot screenshot tool
Exec=sh -c "pgrep flameshot || flameshot"
Type=Application
X-GNOME-Autostart-enabled=true
NoDisplay=false
EOF

echo "   ✓ Autostart 설정 완료: $AUTOSTART_FILE"

# ============================================
# [4/4] Flameshot 즉시 시작
# ============================================
echo "[4/4] Flameshot 시작 중..."

if pgrep flameshot > /dev/null 2>&1; then
    echo "   ✓ Flameshot이 이미 실행 중입니다."
else
    nohup flameshot > /dev/null 2>&1 &
    sleep 1
    if pgrep flameshot > /dev/null 2>&1; then
        echo "   ✓ Flameshot이 백그라운드에서 시작되었습니다."
    else
        echo "   ⚠️  Flameshot 시작 실패 - 수동으로 실행해주세요: flameshot"
    fi
fi

# ============================================
# 완료 메시지
# ============================================
echo ""
echo "✅ Flameshot 기본 설정 완료!"
echo ""
echo "┌────────────────────────────────────────────────────────────────┐"
echo "│  📋 설정 완료 안내                                             │"
echo "├────────────────────────────────────────────────────────────────┤"
echo "│  • Flameshot이 백그라운드에서 실행되었습니다.                   │"
echo "│    지금 바로 PrtSc로 캡처 가능합니다.                          │"
echo "│  • Flameshot은 트레이 앱이라 실행해도 창이 안 뜰 수 있습니다.   │"
echo "│    (정상입니다)                                                │"
if $IS_WAYLAND && $IS_GNOME; then
echo "│  • GNOME Wayland는 최초 캡처 시 권한/화면 선택 팝업이 뜰 수    │"
echo "│    있습니다. (정상입니다)                                      │"
fi
echo "│  • 다음 로그인부터 자동 시작됩니다.                             │"
if $IS_GNOME; then
echo "│  • 트레이 아이콘이 안 보이면 로그아웃 후 재로그인하세요.        │"
fi
echo "└────────────────────────────────────────────────────────────────┘"
echo ""
echo "📁 스크린샷 저장 위치: $SCREENSHOTS_DIR"
echo ""
