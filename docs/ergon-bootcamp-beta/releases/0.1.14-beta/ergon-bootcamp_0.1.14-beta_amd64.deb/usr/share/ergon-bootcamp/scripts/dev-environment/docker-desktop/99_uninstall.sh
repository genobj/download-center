#!/bin/bash
#
# 99_uninstall.sh
# Docker Desktop 삭제 스크립트
#

set -e

# 색상 정의
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

log_info() {
    echo -e "${GREEN}[INFO]${NC} $*"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $*"
}

# 패키지 설치 확인 함수
is_pkg_installed() {
    dpkg-query -W -f='${Status}' "$1" 2>/dev/null | grep -q "install ok installed"
}

# root로 실행 중인지 확인
if [ "$EUID" -ne 0 ]; then
    echo "❌ Uninstall must be run as root"
    exit 1
fi

# 환경 변수 설정 (비대화형 모드)
export DEBIAN_FRONTEND=noninteractive
export APT_LISTCHANGES_FRONTEND=none

# PATH 설정 (rustup 등 사용자 설치 도구를 위해)
export PATH="$HOME/.cargo/bin:$PATH"

# sudo 공통 라이브러리 로드 (run_as_root 헬퍼 사용을 위해)
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../../lib/sudo.sh"

echo "=========================================="
echo "  Docker Desktop 삭제"
echo "=========================================="
echo ""

# Docker Engine 설치 여부 확인
DOCKER_ENGINE_INSTALLED=false
if is_pkg_installed "docker-ce"; then
    DOCKER_ENGINE_INSTALLED=true
fi

# 1. Docker Desktop 패키지 제거
log_info "Docker Desktop 패키지 제거 중..."
sudo apt remove -y docker-desktop
log_info "   ✓ 패키지 제거됨"
echo ""

# 2. Docker context 정리
log_info "Docker context 정리 중..."

if [ "$DOCKER_ENGINE_INSTALLED" = true ]; then
    # Docker Engine이 있으면 default context로 전환
    if command -v docker >/dev/null 2>&1; then
        # SUDO_USER로 docker 명령 실행 (context는 사용자별 설정)
        if [ -n "${SUDO_USER:-}" ]; then
            su - "$SUDO_USER" -c "docker context use default" 2>/dev/null || true
            log_info "   → Docker context를 'default'로 전환 (Docker Engine 사용)"
        fi
    fi
    
    # desktop-linux context 제거
    if [ -n "${SUDO_USER:-}" ]; then
        su - "$SUDO_USER" -c "docker context rm desktop-linux" 2>/dev/null || true
        log_info "   → 'desktop-linux' context 제거됨"
    fi
else
    log_info "   → Docker Engine이 설치되어 있지 않음"
    log_info "   → docker 명령어를 사용하려면 Docker Engine 설치가 필요합니다"
fi

echo ""
log_info "✅ Docker Desktop 삭제 완료!"
echo ""

if [ "$DOCKER_ENGINE_INSTALLED" = true ]; then
    echo "┌────────────────────────────────────────────────────────────────┐"
    echo "│  ℹ️  Docker Engine이 설치되어 있습니다                         │"
    echo "│                                                                │"
    echo "│  Docker Engine을 계속 사용할 수 있습니다.                      │"
    echo "│  현재 context: default (/var/run/docker.sock)                  │"
    echo "└────────────────────────────────────────────────────────────────┘"
    echo ""
fi
