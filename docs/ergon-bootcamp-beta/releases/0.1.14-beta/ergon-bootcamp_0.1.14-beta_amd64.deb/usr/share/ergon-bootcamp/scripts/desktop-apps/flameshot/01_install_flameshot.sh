#!/bin/bash
#
# 01_install_flameshot.sh
# Flameshot 화면 캡처 프로그램 설치
#
# 사용법: ./01_install_flameshot.sh
# 필요한 설정: SUDO_PASSWORD (config.local.env)
#

set -e

# sudo 공통 라이브러리 로드
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../../lib/sudo.sh"

# sudo 캐시 확인 (Tauri 앱 환경에서 필수)
if ! ensure_sudo_cache; then
    echo -e "${RED}❌ Sudo cache expired or not found${NC}"
    echo "Please verify your password in the password screen first."
    exit 1
fi

# ============================================
# GNOME 환경 감지
# ============================================
is_gnome_environment() {
    # XDG_CURRENT_DESKTOP 또는 DESKTOP_SESSION에 GNOME 포함 여부 확인
    if [[ "${XDG_CURRENT_DESKTOP:-}" == *"GNOME"* ]] || [[ "${DESKTOP_SESSION:-}" == *"gnome"* ]]; then
        return 0
    fi
    return 1
}

IS_GNOME=false
if is_gnome_environment; then
    IS_GNOME=true
fi

echo "=========================================="
echo "  Flameshot 설치"
echo "=========================================="

if $IS_GNOME; then
    echo "🖥️  GNOME 환경 감지됨 - AppIndicator 확장도 함께 설치합니다."
fi
echo ""

# 이미 설치되어 있는지 확인
if command -v flameshot &> /dev/null; then
    echo "⚠️  Flameshot이 이미 설치되어 있습니다."
    flameshot --version
    
    # GNOME 환경이면 AppIndicator 확장 설치 확인/진행
    if $IS_GNOME; then
        if ! dpkg -l | grep -q gnome-shell-extension-appindicator; then
            echo ""
            echo "[추가] GNOME AppIndicator 확장 설치 중..."
            run_as_root apt install -y gnome-shell-extension-appindicator
            # 확장 활성화 시도 (실패 허용)
            gnome-extensions enable ubuntu-appindicators@ubuntu.com 2>/dev/null || true
            echo "   ✓ AppIndicator 확장 설치 완료"
        fi
    fi
    exit 0
fi

# 패키지 목록 업데이트
echo "[1/3] 패키지 목록 업데이트 중..."
run_as_root apt update

# Flameshot 설치
echo "[2/3] Flameshot 설치 중..."
run_as_root apt install -y flameshot

# GNOME 환경: AppIndicator 확장 설치
if $IS_GNOME; then
    echo "[3/3] GNOME AppIndicator 확장 설치 중..."
    run_as_root apt install -y gnome-shell-extension-appindicator
    
    # 확장 활성화 시도 (실패 허용 - 재로그인 필요할 수 있음)
    gnome-extensions enable ubuntu-appindicators@ubuntu.com 2>/dev/null || true
    echo "   ✓ AppIndicator 확장 설치 완료"
else
    echo "[3/3] 설치 확인 중..."
fi

echo ""
echo "✅ Flameshot 설치 완료!"
flameshot --version
echo ""
echo "📝 주요 기능:"
echo "   - 전체 화면, 선택 영역, 활성 창 캡처"
echo "   - 실시간 편집: 모자이크, 강조, 텍스트, 화살표"
echo "   - 클립보드 복사, 파일 저장, URL 업로드"
echo ""
echo "┌────────────────────────────────────────────────────────────────┐"
echo "│  💡 Flameshot 안내                                             │"
echo "├────────────────────────────────────────────────────────────────┤"
echo "│  • Flameshot은 트레이 앱입니다. 실행해도 창이 안 뜰 수 있습니다.│"
echo "│  • 다음 로그인부터 자동 시작됩니다.                             │"
echo "│  • 화면 캡처: 터미널에서 flameshot gui 또는 Print Screen 키    │"
if $IS_GNOME; then
echo "│  • 트레이 아이콘이 안 보이면 로그아웃 후 재로그인하세요.        │"
fi
echo "└────────────────────────────────────────────────────────────────┘"
echo ""


