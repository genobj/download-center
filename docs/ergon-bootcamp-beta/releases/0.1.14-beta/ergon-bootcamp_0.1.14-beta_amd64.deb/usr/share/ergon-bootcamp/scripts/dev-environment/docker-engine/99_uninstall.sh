#!/bin/bash
#
# 99_uninstall.sh
# Docker Engine 삭제
#
# 사용법: ./99_uninstall.sh [OPTIONS]
#
# 옵션:
#   --purge-data    Docker 데이터 삭제 (/var/lib/docker, /var/lib/containerd)
#   --remove-repo   APT 저장소 제거 (Docker Desktop과 공유됨에 주의)
#   --user=USERNAME 특정 사용자의 docker 그룹 제거 (기본: SUDO_USER 또는 현재 사용자)
#

set -euo pipefail

# 색상 정의
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# 로그 함수
log_info() {
    echo -e "${GREEN}[INFO]${NC} $*"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $*"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $*"
}

# 옵션 파싱
PURGE_DATA=false
REMOVE_REPO=false
TARGET_USER=""

for arg in "$@"; do
    case $arg in
        --purge-data)
            PURGE_DATA=true
            shift
            ;;
        --remove-repo)
            REMOVE_REPO=true
            shift
            ;;
        --user=*)
            TARGET_USER="${arg#*=}"
            shift
            ;;
        *)
            ;;
    esac
done

# 타깃 유저 결정
if [ -z "$TARGET_USER" ]; then
    if [ -n "${SUDO_USER:-}" ]; then
        TARGET_USER="$SUDO_USER"
    else
        TARGET_USER="$(whoami)"
    fi
fi

# sudo 공통 라이브러리 로드
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../../lib/sudo.sh"

# sudo 캐시 확인
if ! ensure_sudo_cache; then
    echo -e "${RED}❌ Sudo cache expired or not found${NC}"
    echo "Please verify your password in the password screen first."
    exit 1
fi

echo ""
echo "=========================================="
echo "  Docker Engine 삭제"
echo "=========================================="
echo ""

log_info "옵션:"
log_info "   데이터 삭제: $PURGE_DATA"
log_info "   저장소 제거: $REMOVE_REPO"
log_info "   타깃 사용자: $TARGET_USER"
echo ""

# 1. Docker 서비스 중지
log_info "Docker 서비스 중지 중..."

if command -v systemctl >/dev/null 2>&1; then
    run_as_root systemctl stop docker.socket 2>/dev/null || true
    run_as_root systemctl stop docker 2>/dev/null || true
    run_as_root systemctl stop containerd 2>/dev/null || true
elif command -v service >/dev/null 2>&1; then
    run_as_root service docker stop 2>/dev/null || true
fi

log_info "   ✓ 서비스 중지됨"
echo ""

# 2. 패키지 제거
log_info "Docker 패키지 제거 중..."

# 패키지 설치 확인 함수
is_pkg_installed() {
    dpkg-query -W -f='${Status}' "$1" 2>/dev/null | grep -q "install ok installed"
}

# Docker Desktop 설치 여부 확인
DOCKER_DESKTOP_INSTALLED=false
if is_pkg_installed "docker-desktop"; then
    DOCKER_DESKTOP_INSTALLED=true
    log_warn "Docker Desktop이 설치되어 있습니다."
    log_warn "공유 패키지(docker-ce-cli 등)는 유지됩니다."
    echo ""
fi

if [ "$DOCKER_DESKTOP_INSTALLED" = true ]; then
    # Docker Desktop이 설치되어 있으면 docker-ce만 삭제 (공유 패키지 유지)
    DOCKER_PACKAGES=(
        "docker-ce"
        "docker-ce-rootless-extras"
    )
    log_info "   → Docker Engine 전용 패키지만 제거"
else
    # Docker Desktop이 없으면 전체 삭제
    DOCKER_PACKAGES=(
        "docker-ce"
        "docker-ce-cli"
        "containerd.io"
        "docker-buildx-plugin"
        "docker-compose-plugin"
        "docker-ce-rootless-extras"
    )
    log_info "   → 전체 Docker 패키지 제거"
fi

run_as_root apt-get purge -y "${DOCKER_PACKAGES[@]}" 2>/dev/null || true

# Docker Desktop이 없을 때만 autoremove 실행 (의존성 정리)
if [ "$DOCKER_DESKTOP_INSTALLED" = false ]; then
    run_as_root apt-get autoremove -y 2>/dev/null || true
fi

log_info "   ✓ 패키지 제거됨"
echo ""

# 2-1. Docker context 정리
log_info "Docker context 정리 중..."

if [ "$DOCKER_DESKTOP_INSTALLED" = true ]; then
    # Docker Desktop이 있으면 desktop-linux context로 전환
    if command -v docker >/dev/null 2>&1; then
        docker context use desktop-linux 2>/dev/null || true
        log_info "   → Docker context를 'desktop-linux'로 전환"
    fi
else
    # Docker Desktop이 없으면 default context 유지 (정리 불필요)
    log_info "   → 정리 불필요"
fi

echo ""

# 3. 데이터 삭제 (옵션)
if [ "$PURGE_DATA" = true ]; then
    log_info "Docker 데이터 삭제 중..."
    
    run_as_root rm -rf /var/lib/docker
    run_as_root rm -rf /var/lib/containerd
    run_as_root rm -rf /etc/docker
    
    log_info "   ✓ 데이터 삭제됨"
else
    log_info "Docker 데이터 보존됨 (삭제하려면 --purge-data 옵션 사용)"
    log_info "   /var/lib/docker"
    log_info "   /var/lib/containerd"
fi

echo ""

# 4. 저장소 제거 (옵션)
if [ "$REMOVE_REPO" = true ]; then
    echo "┌────────────────────────────────────────────────────────────────┐"
    echo "│  ⚠️  주의: 저장소 제거                                         │"
    echo "│                                                                │"
    echo "│  Docker Desktop과 Docker Engine은 같은 저장소를 공유합니다.   │"
    echo "│  저장소를 제거하면 Docker Desktop 재설치 시 다시 설정해야     │"
    echo "│  합니다.                                                       │"
    echo "└────────────────────────────────────────────────────────────────┘"
    echo ""
    
    log_info "APT 저장소 제거 중..."
    
    # new-style sources 파일
    run_as_root rm -f /etc/apt/sources.list.d/docker.sources
    
    # legacy sources 파일
    run_as_root rm -f /etc/apt/sources.list.d/docker.list
    
    # GPG 키
    run_as_root rm -f /etc/apt/keyrings/docker.asc
    run_as_root rm -f /etc/apt/keyrings/docker.gpg
    
    run_as_root apt-get update -qq 2>/dev/null || true
    
    log_info "   ✓ 저장소 제거됨"
else
    log_info "APT 저장소 보존됨 (제거하려면 --remove-repo 옵션 사용)"
fi

echo ""

# 5. 사용자 그룹 제거
if [ "$TARGET_USER" = "root" ]; then
    log_info "root 사용자 - 그룹 제거 스킵"
else
    log_info "docker 그룹에서 사용자 제거 중..."
    
    if id -nG "$TARGET_USER" 2>/dev/null | grep -qw docker; then
        if run_as_root gpasswd -d "$TARGET_USER" docker 2>/dev/null; then
            log_info "   ✓ $TARGET_USER 사용자를 docker 그룹에서 제거함"
        else
            log_warn "   그룹 제거 실패 (수동으로 확인하세요)"
        fi
    else
        log_info "   $TARGET_USER 사용자가 docker 그룹에 속하지 않음"
    fi
fi

echo ""
log_info "✅ Docker Engine 삭제 완료!"
echo ""

if [ "$PURGE_DATA" = false ]; then
    log_info "재설치 시 기존 데이터를 사용할 수 있습니다."
fi

echo ""
