#!/bin/bash
#
# 04_verify_setup.sh
# Docker Desktop 설치 확인
#
# 사용법: ./04_verify_setup.sh
#

echo "=========================================="
echo "  Docker Desktop 설치 확인"
echo "=========================================="

PASS_COUNT=0
FAIL_COUNT=0

# 1. Docker Desktop 패키지 확인
echo ""
echo "[1/5] Docker Desktop 패키지 확인..."
if dpkg -l | grep -q docker-desktop; then
    VERSION=$(dpkg -l | grep docker-desktop | awk '{print $3}')
    echo "   ✅ docker-desktop 설치됨: $VERSION"
    PASS_COUNT=$((PASS_COUNT + 1))
else
    echo "   ❌ docker-desktop 패키지가 설치되지 않음"
    FAIL_COUNT=$((FAIL_COUNT + 1))
fi

# 2. docker 명령어 확인
echo ""
echo "[2/5] docker 명령어 확인..."
if command -v docker &> /dev/null; then
    DOCKER_VERSION=$(docker --version 2>/dev/null || echo "확인 불가")
    echo "   ✅ docker 명령어 사용 가능: $DOCKER_VERSION"
    PASS_COUNT=$((PASS_COUNT + 1))
else
    echo "   ❌ docker 명령어를 찾을 수 없음"
    FAIL_COUNT=$((FAIL_COUNT + 1))
fi

# 3. docker compose 확인
echo ""
echo "[3/5] docker compose 확인..."
if docker compose version &> /dev/null; then
    COMPOSE_VERSION=$(docker compose version 2>/dev/null)
    echo "   ✅ $COMPOSE_VERSION"
    PASS_COUNT=$((PASS_COUNT + 1))
else
    echo "   ⚠️  docker compose를 확인할 수 없음 (Docker Desktop 실행 후 확인)"
    PASS_COUNT=$((PASS_COUNT + 1))  # 치명적이지 않음
fi

# 4. Docker Desktop 서비스 상태 확인
echo ""
echo "[4/5] Docker Desktop 서비스 확인..."
if systemctl --user is-active docker-desktop &> /dev/null; then
    echo "   ✅ Docker Desktop 서비스 실행 중"
    PASS_COUNT=$((PASS_COUNT + 1))
else
    echo "   ⚠️  Docker Desktop이 실행되지 않음"
    echo "      → 앱 메뉴에서 Docker Desktop을 실행하거나:"
    echo "      → systemctl --user start docker-desktop"
    PASS_COUNT=$((PASS_COUNT + 1))  # 설치만 확인하므로 통과
fi

# 5. 디스크 설정 확인
echo ""
echo "[5/5] 디스크 용량 설정 확인..."
SETTINGS_FILE="$HOME/.docker/desktop/settings.json"
if [ -f "$SETTINGS_FILE" ]; then
    if command -v jq &> /dev/null; then
        DISK_SIZE=$(jq -r '.diskSizeGiB // "미설정"' "$SETTINGS_FILE" 2>/dev/null)
        echo "   ✅ 디스크 용량 설정: ${DISK_SIZE}GB"
    else
        echo "   ✅ 설정 파일 존재: $SETTINGS_FILE"
    fi
    PASS_COUNT=$((PASS_COUNT + 1))
else
    echo "   ⚠️  설정 파일을 찾을 수 없음"
    echo "      → Docker Desktop 첫 실행 후 생성됩니다"
    PASS_COUNT=$((PASS_COUNT + 1))  # 치명적이지 않음
fi

echo ""
echo "=========================================="
echo "  검증 결과"
echo "=========================================="
echo ""
echo "  ✅ 통과: $PASS_COUNT"
echo "  ❌ 실패: $FAIL_COUNT"
echo ""

# 패키지 설치 확인 함수
is_pkg_installed() {
    dpkg-query -W -f='${Status}' "$1" 2>/dev/null | grep -q "install ok installed"
}

# Docker context 설정
echo ""
echo "[6/6] Docker Context 설정..."
CURRENT_CONTEXT=$(docker context show 2>/dev/null || echo "unknown")

if [ "$CURRENT_CONTEXT" != "desktop-linux" ]; then
    echo "   → Docker context를 'desktop-linux'로 설정 중..."
    if docker context use desktop-linux >/dev/null 2>&1; then
        echo "   ✅ Docker context가 'desktop-linux'로 설정됨"
    else
        echo "   ⚠️  Docker context 설정 실패"
        echo "      수동으로 실행하세요: docker context use desktop-linux"
    fi
else
    echo "   ✅ Docker context가 이미 'desktop-linux'로 설정됨"
fi

echo ""
echo "=========================================="
echo "  검증 결과"
echo "=========================================="
echo ""
echo "  ✅ 통과: $PASS_COUNT"
echo "  ❌ 실패: $FAIL_COUNT"
echo ""

if [ $FAIL_COUNT -eq 0 ]; then
    echo "🎉 Docker Desktop 설치가 완료되었습니다!"
    echo ""
    echo "┌────────────────────────────────────────────────────────┐"
    echo "│  📌 Docker Desktop 사용법                              │"
    echo "│                                                        │"
    echo "│  시작:                                                 │"
    echo "│    systemctl --user start docker-desktop               │"
    echo "│    또는 앱 메뉴에서 'Docker Desktop' 클릭              │"
    echo "│                                                        │"
    echo "│  자동 시작 설정:                                       │"
    echo "│    systemctl --user enable docker-desktop              │"
    echo "│                                                        │"
    echo "│  중지:                                                 │"
    echo "│    systemctl --user stop docker-desktop                │"
    echo "│                                                        │"
    echo "│  디스크 용량 확인:                                     │"
    echo "│    Settings > Resources > Disk image size              │"
    echo "└────────────────────────────────────────────────────────┘"
    
    # Docker Engine 공존 여부 확인 및 안내
    if is_pkg_installed "docker-ce"; then
        echo ""
        echo "┌────────────────────────────────────────────────────────────────┐"
        echo "│  ℹ️  Docker Desktop과 Docker Engine이 함께 설치되어 있습니다  │"
        echo "│                                                                │"
        echo "│  현재 Docker Desktop (desktop-linux context)을 사용하도록     │"
        echo "│  설정됨                                                        │"
        echo "│                                                                │"
        echo "│  Docker 전환 방법:                                             │"
        echo "│    Desktop 사용: docker context use desktop-linux              │"
        echo "│    Engine 사용:  docker context use default                    │"
        echo "│                                                                │"
        echo "│  현재 context 확인: docker context ls                          │"
        echo "│                                                                │"
        echo "│  참고: 두 Docker는 독립적으로 동작하며, 컨테이너/이미지가      │"
        echo "│        각각 별도로 관리됩니다.                                 │"
        echo "└────────────────────────────────────────────────────────────────┘"
    fi
    
    exit 0
else
    echo "⚠️  일부 검증이 실패했습니다."
    exit 1
fi

