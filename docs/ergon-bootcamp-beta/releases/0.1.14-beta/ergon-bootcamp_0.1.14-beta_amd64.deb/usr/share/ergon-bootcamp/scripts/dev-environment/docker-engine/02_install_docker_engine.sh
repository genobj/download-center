#!/bin/bash
#
# 02_install_docker_engine.sh
# Docker Engine 패키지 설치
#
# 사용법: ./02_install_docker_engine.sh
# 필요한 설정: SUDO_PASSWORD (config.local.env)
# 참조: https://docs.docker.com/engine/install/ubuntu/
#

set -euo pipefail

# 색상 정의
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# 로그 함수
log_info() {
    echo -e "${GREEN}[INFO]${NC} $*"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $*"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $*"
}

# 패키지 설치 확인
is_pkg_installed() {
    dpkg-query -W -f='${Status}' "$1" 2>/dev/null | grep -q "install ok installed"
}

# systemd 사용 가능 여부 확인
has_systemd() {
    if command -v systemctl >/dev/null 2>&1 && systemctl --version >/dev/null 2>&1; then
        # systemctl이 실제로 동작하는지 확인 (WSL에서는 설치만 되어있을 수 있음)
        if systemctl is-system-running >/dev/null 2>&1 || \
           [ "$(systemctl is-system-running 2>/dev/null)" = "running" ] || \
           [ "$(systemctl is-system-running 2>/dev/null)" = "degraded" ]; then
            return 0
        fi
    fi
    return 1
}

# service 명령어 사용 가능 여부 확인
has_service_cmd() {
    command -v service >/dev/null 2>&1
}

# sudo 공통 라이브러리 로드
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../../lib/sudo.sh"

# sudo 캐시 확인
if ! ensure_sudo_cache; then
    echo -e "${RED}❌ Sudo cache expired or not found${NC}"
    echo "Please verify your password in the password screen first."
    exit 1
fi

echo ""
echo "=========================================="
echo "  Docker Engine 설치"
echo "=========================================="
echo ""

# 1. 충돌 패키지 정리 (보수적 접근)
log_info "충돌 패키지 확인 중..."

# 제거 대상 패키지 (containerd, runc는 Kubernetes 호환을 위해 유지)
CONFLICT_PACKAGES=("docker.io" "docker-doc" "docker-compose" "podman-docker")

for pkg in "${CONFLICT_PACKAGES[@]}"; do
    if is_pkg_installed "$pkg"; then
        log_info "   → 충돌 패키지 제거: $pkg"
        run_as_root apt-get remove -y "$pkg" || true
    fi
done

log_info "   ✓ 충돌 패키지 확인 완료"
echo ""

# 2. Docker Engine 패키지 설치
log_info "Docker Engine 패키지 설치 중..."

DOCKER_PACKAGES=(
    "docker-ce"
    "docker-ce-cli"
    "containerd.io"
    "docker-buildx-plugin"
    "docker-compose-plugin"
)

run_as_root apt-get install -y "${DOCKER_PACKAGES[@]}"

log_info "   ✓ Docker Engine 패키지 설치 완료"
echo ""

# 3. 서비스 시작 (시도 후 fallback)
log_info "Docker 서비스 시작 중..."

SERVICE_STARTED=false

# systemctl 먼저 시도
if has_systemd; then
    log_info "   → systemctl로 서비스 시작 시도..."
    if run_as_root systemctl start docker 2>/dev/null; then
        run_as_root systemctl enable docker 2>/dev/null || true
        SERVICE_STARTED=true
        log_info "   ✓ Docker 서비스 시작됨 (systemd)"
    fi
fi

# systemctl 실패 시 service로 fallback
if [ "$SERVICE_STARTED" = false ] && has_service_cmd; then
    log_info "   → service 명령어로 서비스 시작 시도..."
    if run_as_root service docker start 2>/dev/null; then
        SERVICE_STARTED=true
        log_info "   ✓ Docker 서비스 시작됨 (service)"
    fi
fi

# 둘 다 실패한 경우
if [ "$SERVICE_STARTED" = false ]; then
    log_warn "   Docker 서비스 자동 시작 실패"
    log_warn "   WSL 환경이거나 systemd가 비활성화되어 있을 수 있습니다."
    echo ""
    log_info "   수동 시작 방법:"
    log_info "     sudo dockerd &"
    log_info "   또는 WSL2에서 systemd 활성화:"
    log_info "     /etc/wsl.conf에 [boot] systemd=true 추가 후 WSL 재시작"
fi

echo ""

# 4. docker-compose v1 경고
if command -v docker-compose >/dev/null 2>&1; then
    log_warn "docker-compose v1이 감지되었습니다."
    log_warn "Docker Compose v2는 'docker compose' (하이픈 없음)로 실행합니다."
    log_warn "v1 명령어는 더 이상 업데이트되지 않습니다."
fi

echo ""
log_info "✅ Docker Engine 설치 완료!"
echo ""
